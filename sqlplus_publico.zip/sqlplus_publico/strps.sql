prompt Buffer Propagation:
prompt ============================================
select inst_id, 
       queue_name , 
       num_msgs , 
       EXPIRED_MSGS 
  from gv$buffered_queues
/
prompt Propagation receiver
prompt ============================================
select SRC_QUEUE_NAME,
       DST_QUEUE_NAME, 
       HIGH_WATER_MARK, 
       TOTAL_MSGS 
  from gv$propagation_receiver
/
prompt Propagation sender
prompt ============================================
select queue_name,
       dst_queue_name,
       high_water_mark,
       schedule_status,
       total_msgs,
       max_size
  from gv$propagation_sender
/