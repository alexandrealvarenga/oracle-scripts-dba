/* ASH_AAS_BLK.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Contagem de AAS (Average Active Sessions) por principais sessoes bloqueadoras em uma instancia
 * Utilizacao: @ash_aas_blk intervalo dt_inicial dt_final [evento] (intervalo em minutos, data no formato YYYYMMDDHH24MI)
 *             @ash_aas_blk intervalo last periodo_minutos [evento]
 * Obs.:       Parametros entre colchetes sao opcionais
 *             Como o script deve suportar 10g, nao e possivel mostrar a instancia da sessao bloqueadora
 *            
 * Exemplos: @ash_aas_blk 1 201404291000 201404291005 'enq: TX%'
 *           @ash_aas_blk 5 last 60 'enq: TX%'
 *           @ash_aas_blk 1 201404291000 201404291005
 *           @ash_aas_blk 5 last 60
 *
 * Baseado no script ash_graph_waits_histash.sql de Kyle Hailey, em https://github.com/khailey/ashmasters
 * Ref.: http://www.oraclerealworld.com/ash-masters/
 */

store set %temp%\sqlenv replace

set verify off echo off lines 180 pages 50 serveroutput on

set feed off
alter session set nls_timestamp_format='DD/MM/RR HH24:MI';
set feed on

define C_SMP_INT_ASH=1                  -- Intervalo de amostragem da view V$ACTIVE_SESSION_HISTORY (em segundos)
define C_SMP_INT_ASH_HIST=10            -- Intervalo de amostragem da view DBA_HIST_ACTIVE_SESS_HISTORY (em segundos)
define C_SMP_WIDTH=14                   -- Largura do display do sample time
define C_EVT_WIDTH=40                   -- Largura do display do evento
define C_PCT_FMT=990.00                 -- Formato do display das porcentagens
define C_NUM_TOP_EVT=10                 -- Numero de top events
define C_GRP_WIDTH=10                   -- Largura do grafico
define C_DT_INPUT_FMT=YYYYMMDDHH24MI    -- Formato de input de data
define C_AAS_FMT=9990.00                -- Formato de display do AAS
define C_TSTP_FMT=YYYYMMDDHH24MISSFF    -- Formato de conversao de timestamp para varchar

-- Define o valor default do quarto parametro, que eh opcional
set feed off term off
col p4 new_value 4
select null p4 from dual where  1=2;
select nvl('&4','%') p4 from dual;
set feed on term on

define p_smp_int=&1
define p_ini_date=&2
define p_end_date=&3
define p_event="&4"

variable smp_int number
variable smp_period number
variable ini_date varchar2(20)
variable end_date varchar2(20)
variable scan_history number
variable event_name varchar2(100)
variable ash_min_time varchar2(30)

set feed off
declare
    l_ash_min_time timestamp := null;
    l_cpu_count number := 0;
    l_smp_period_interval interval day to second;
begin
    :smp_int := &p_smp_int;
    :ini_date := upper('&p_ini_date');
    :event_name := '&p_event';
    
    if (:ini_date = 'LAST') then
        :ini_date := to_char((systimestamp - &p_end_date/60/24), '&C_DT_INPUT_FMT');
        :end_date := to_char(systimestamp, '&C_DT_INPUT_FMT');
    else
        :ini_date := '&p_ini_date';
        :end_date := '&p_end_date';
    end if;
    
    l_smp_period_interval := to_timestamp(:end_date, '&C_DT_INPUT_FMT') - to_timestamp(:ini_date, '&C_DT_INPUT_FMT');
    :smp_period := 24*60*extract(day from l_smp_period_interval) + 60*extract(hour from l_smp_period_interval) + extract(minute from l_smp_period_interval);
    
    if :smp_int > :smp_period then
        :smp_int := :smp_period;
        dbms_output.put_line('Sampling Interval - corrected: '||:smp_int);
    end if;
    
    -- Ajusta o horario de inicio caso o intervalo nao seja multiplo do periodo analisado
    if mod(:smp_period, :smp_int) <> 0 then
        :smp_period := ceil(:smp_period/:smp_int) * :smp_int; 
        :ini_date := to_char((to_date(:end_date, '&C_DT_INPUT_FMT') - :smp_period/60/24), '&C_DT_INPUT_FMT');
        
        dbms_output.put_line('Analyzed Period - corrected: '||to_date(:ini_date, '&C_DT_INPUT_FMT')
                        ||' - '||to_date(:end_date, '&C_DT_INPUT_FMT'));
    end if;
    
    select min(sample_time)
    into l_ash_min_time
    from v$active_session_history;
     -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
     -- Ref: http://optimizermagic.blogspot.com.br/2008/06/why-are-some-of-tables-in-my-query.html
    if (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') < l_ash_min_time) then
       :scan_history := 1;
    else
       :scan_history := 2;
    end if;
    :ash_min_time := to_char(l_ash_min_time, '&C_TSTP_FMT');
    
    select value
    into l_cpu_count
    from v$parameter
    where upper(name) = 'CPU_COUNT';
    
    dbms_output.put_line(chr(10)||'CPU Count: '||l_cpu_count
                       ||chr(10)||'AAS - Average Active Sessions');
end;
/
set feed on

col sample for a&C_SMP_WIDTH
col event for a&C_EVT_WIDTH
col aas for &C_AAS_FMT heading "Blocked|AAS"
col aas_sample for &C_AAS_FMT heading "AAS-Sample"
col graph for a&C_GRP_WIDTH
col pct for &C_PCT_FMT justify right heading "(%)"
col blocking_session heading "Blocking SID"
col blocking_session_serial# heading "Blocking Serial#"

break on sample skip page on aas_sample

-- Observacoes:
-- - O intervalo de amostragem da view v$active_session_history é diferente do intervalo
--   da view dba_hist_active_sess_history.
-- - A inline view t1 eh usada para gerar os intervalos de amostragem
-- - O outer join com a view t1, necessario para mostrar os periodos sem atividade, nao eh feito
--   nas queries internas para nao gerar contagem de eventos nulos
-- - E necessario ajustar manualmente a cardinalidade da inline view t1. 100 eh um valor suficiente
--   para que se evite nested loops no join com a inline view de events

with 
t1 as
(
    select /*+ OPT_ESTIMATE(TABLE, D, ROWS=100) */
           to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level, 'minute')*:smp_int dt, 
           to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level-1, 'minute')*:smp_int next_dt
    from dual d
    connect by level <= (:smp_period/:smp_int)
),
events as 
(
    select trunc(sample_time, 'MI') sample_time, nvl(event, 'ON CPU') event, blocking_session, blocking_session_serial#, sum(&C_SMP_INT_ASH) cnt
    from v$active_session_history h
    where (h.sample_time >= to_date(:ini_date, '&C_DT_INPUT_FMT') and h.sample_time < to_date(:end_date, '&C_DT_INPUT_FMT'))
      and h.blocking_session is not null
      and lower(event) like lower(:event_name)
    group by trunc(sample_time, 'MI'), nvl(event, 'ON CPU'), blocking_session, blocking_session_serial#
    union all
    select /*+ 
                NO_MERGE(C)
                NO_MERGE(S)
                NO_MERGE(D)
                LEADING(C S D)
                OPT_ESTIMATE(TABLE S ROWS=1000)
                OPT_ESTIMATE(TABLE D ROWS=50000)
                OPT_ESTIMATE(TABLE D.ASH ROWS=50000) 
                OPT_ESTIMATE(TABLE D.SN ROWS=1500) 
                OPT_ESTIMATE(TABLE D.EVT ROWS=1000)
                LEADING(D.SN D.ASH D.EVT)
                USE_HASH(D.SN D.ASH D.EVT)
           */
           trunc(sample_time, 'MI') sample_time, nvl(d.event, 'ON CPU') event, blocking_session, blocking_session_serial#, sum(&C_SMP_INT_ASH_HIST) cnt
    from dba_hist_wr_control c,
         dba_hist_snapshot s,
         dba_hist_active_sess_history d
    where 1 = :scan_history -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
      /* JOINS - INICIO */
      and s.dbid = c.dbid
      and d.snap_id = s.snap_id 
      and s.dbid = d.dbid 
      and s.instance_number = d.instance_number
      /* JOINS - FIM */
      and s.end_interval_time > (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') - c.snap_interval)     -- Considera snapshots adjacentes, pois o sample_time
      and s.begin_interval_time < (to_timestamp(:end_date, '&C_DT_INPUT_FMT') + c.snap_interval)   -- pode ser menor do que o begin_interval_time
      and (d.sample_time >= to_timestamp(:ini_date, '&C_DT_INPUT_FMT') and d.sample_time < to_timestamp(:end_date, '&C_DT_INPUT_FMT'))
      and d.sample_time < to_timestamp(:ash_min_time, '&C_TSTP_FMT')
      and d.blocking_session is not null
      and s.instance_number = sys_context('USERENV', 'INSTANCE')
      and s.dbid = (select dbid from v$database)
      and lower(event) like lower(:event_name)
    group by trunc(sample_time, 'MI'), nvl(event, 'ON CPU'), blocking_session, blocking_session_serial#
)
select sample, 
       aas_sample, 
       aas,
       (aas/decode(aas_sample, 0, 1, aas_sample)) * 100 pct,
       rpad('+', (aas/decode(aas_sample, 0, 1, aas_sample)) * &C_GRP_WIDTH, '+') graph,
       event,
       blocking_session,
       blocking_session_serial#           
from
(
    select sample,
           event,
           blocking_session,
           blocking_session_serial#,
           nvl(aas, 0) aas,
           sum(nvl(aas, 0)) over (partition by sample) aas_sample,
           rn
    from 
    (
        select t1.dt sample, 
               e.event,
               e.blocking_session,
               e.blocking_session_serial#,
               sum(cnt)/(60*:smp_int) aas,
               row_number() over (partition by t1.dt order by sum(cnt)/(60*:smp_int) desc) rn
        from t1
        left outer join events e on e.sample_time >= t1.dt and e.sample_time < t1.next_dt
        group by t1.dt, event, blocking_session, blocking_session_serial#
    )
)
where rn <= &C_NUM_TOP_EVT
order by sample, aas desc
/

undef 1 2 3 4
undef p_smp_int p_ini_date p_end_date p4
undef C_SMP_INT_ASH C_SMP_INT_ASH_HIST C_SMP_WIDTH C_EVT_WIDTH C_PCT_FMT C_NUM_TOP_EVT C_GRP_WIDTH C_DT_INPUT_FMT C_AAS_FMT C_TSTP_FMT
clear breaks
clear columns

@%temp%\sqlenv
prompt
