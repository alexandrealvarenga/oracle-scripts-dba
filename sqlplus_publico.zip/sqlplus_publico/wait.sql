set lines 500
col kill format a60
col "Evento" format a45
col "Classe" for a40
col "User" for a20
col "Sid" for 9999999999
col "OS Pid" for a10
col "Programa" for a40
col p1text for a20
col p2text for a20
col p3text for a20
col p1 for 999999999999999
col p2 for 999999999999999
col p3 for 999999999999999
select a.inst_id,
       substr(b.username,1,10)        "User",
       substr(a.sid,1,4)              "Sid",
       substr(c.spid,1,9)             "OS Pid",
       substr(a.event,1,40)           "Evento",
       substr(a.wait_class, 1, 40)    "Classe",
       a.seconds_in_wait              "Secs",
       substr(b.status,1,4)           "Status",
       b.logon_time                   "Start Session",
       substr(b.program,1,50)          "Programa",
       a.p1text,
       a.p1,
       a.p2text,
       a.p2,
       a.p3text,
       a.p3,
       'ALTER SYSTEM DISCONNECT SESSION ' || CHR(39) || a.SID ||','||b.SERIAL# || CHR(39) || ' IMMEDIATE;' kill
from gv$session_wait a, gv$session b, gv$process c
where a.event not in 
    ('SQL*Net message from client',
     'SQL*Net message to client',
     'LogMiner: wakeup event for builder',
     'LogMiner: client waiting for transaction',
     'jobq slave wait',
     'LogMiner: wakeup event for preparer',
     'LogMiner: reader waiting for more redo',
     'wait for unread message on broadcast channel',
     'Streams capture: waiting for archive log')
and a.sid = b.sid
and decode(nvl(c.background, 0), 0, ' ', 'B') <> 'B'
and c.addr=b.paddr (+)
and c.spid is not null
and a.inst_id = b.inst_id
and c.inst_id = b.inst_id
and a.wait_class <> 'Idle'
order by a.inst_id, "User", a.sid;