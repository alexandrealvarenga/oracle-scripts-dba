select *
from SYS.V_$STATNAME n
where class = 2
order by name;

select * from v$segstat;

select *
from SYS.DBA_HIST_SEG_STAT;

select begin_interval_time
from sys.dba_hist_snapshot
order by 1;

select dhsso.obj#,
 dhsso.owner,
 dhsso.object_type,
 dhsso.object_name,
 sum(dhss.db_block_changes_delta) db_block_changes,
 round(ratio_to_report(sum(dhss.db_block_changes_delta)) over (),2) * 100 pct
 from dba_hist_seg_stat dhss,
 dba_hist_seg_stat_obj dhsso,
 dba_hist_snapshot dhs
 where dhs.snap_id = dhss.snap_id
 and dhs.instance_number = dhss.instance_number
 and dhss.obj# = dhsso.obj#
 and dhss.dataobj# = dhsso.dataobj#
 and trunc(begin_interval_time) = TO_DATE ('30/03/2014', 'DD/MM/YYYY')
 group by dhsso.obj#,dhsso.owner,
 dhsso.object_type, dhsso.object_name
 order by db_block_changes desc

select owner, object_name, object_type, block_changes, pct
from (
SELECT   obj.owner, obj.object_name, obj.object_type,
         SUM (segstat.db_block_changes_delta) block_changes, 
         round(ratio_to_report(sum(segstat.db_block_changes_delta)) over (),2) * 100 pct
    FROM SYS.dba_hist_snapshot snap 
        JOIN SYS.dba_hist_seg_stat segstat
            ON snap.snap_id = segstat.snap_id and SNAP.INSTANCE_NUMBER = SEGSTAT.INSTANCE_NUMBER and SNAP.DBID = SEGSTAT.DBID
        JOIN SYS.dba_hist_seg_stat_obj obj
            ON obj.obj# = segstat.obj# AND obj.dataobj# = segstat.dataobj#
   WHERE TRUNC (snap.begin_interval_time) = TO_DATE ('30/03/2014', 'DD/MM/YYYY')
GROUP BY obj.owner, obj.object_name, obj.object_type
ORDER BY block_changes DESC)
where block_changes > 0;

select SNAP.SNAP_ID, SQLST.PARSING_SCHEMA_NAME, SQLST.EXECUTIONS_DELTA, sqlst.rows_processed_delta, dbms_lob.substr(SQLTXT.SQL_TEXT, 150, 1)
FROM SYS.dba_hist_snapshot snap
join sys.dba_hist_sqlstat sqlst on SNAP.SNAP_ID = SQLST.SNAP_ID and SNAP.INSTANCE_NUMBER = SQLST.INSTANCE_NUMBER and SNAP.DBID = SQLST.DBID
join SYS.DBA_HIST_SQLTEXT sqltxt on SQLST.SQL_ID = SQLTXT.SQL_ID
where TRUNC (snap.begin_interval_time) = TO_DATE ('30/03/2014', 'DD/MM/YYYY')
and SQLTXT.COMMAND_TYPE in (2, 6, 7, 189) -- insert, update, delete, merge
order by rows_processed_delta desc;


SELECT dhss.sql_id,
 DBMS_LOB.SUBSTR (dhst.sql_text,150, 1) sql_text,
 SUM (dhss.executions_delta) executions_delta,
 SUM (dhss.rows_processed_delta) rows_processed_delta
 FROM dba_hist_sqlstat dhss, dba_hist_snapshot dhs, dba_hist_sqltext dhst
 WHERE (REGEXP_INSTR(UPPER (dhst.sql_text),'.?'||UPPER(:P_OBJECT_NAME)) > 0)
 AND dhst.command_type IN (2, 6, 7, 189)
 AND dhss.snap_id = dhs.snap_id
 AND dhss.instance_Number = dhs.instance_number
 AND dhss.sql_id = dhst.sql_id
 AND TRUNC (dhs.begin_interval_time) =  TO_DATE ('30/03/2014', 'DD/MM/YYYY')
GROUP BY dhss.sql_id, DBMS_LOB.SUBSTR (dhst.sql_text, 150, 1)

select to_char(sysdate,'hh24:mi'), username, program , a.sid, a.serial#, b.name, c.value
from v$session a, v$statname b, v$sesstat c
where b.STATISTIC# =c.STATISTIC#
and c.sid=a.sid and b.name like 'redo size%'
and username is not null and username not in ('SYS', 'SYSTEM', 'DBSNMP')
order by value desc;