set echo off
--
--accept Owner char prompt 'Informe o Owner dos triggers ou tecle ENTER para todos: '
--
set linesize 5000 pagesize 0 space 0
set termout off feedback off verify off heading off
set trims on
set long 1500000
--
column titulo format a200
column trigger_body format a200
--
  SELECT 'create or replace trigger '||
         description
  FROM dba_triggers
  WHERE owner NOT IN ('SYS','SYSTEM')
  ORDER BY owner, trigger_name
/

  SELECT 'create or replace trigger '||owner||'.'||trigger_name titulo,
       trigger_body
  FROM dba_triggers
  WHERE owner NOT IN ('SYS','SYSTEM')
  ORDER BY owner, trigger_name
/

--
undef Owner
set pagesize 20 space 1
set termout on feedback on verify on heading on

