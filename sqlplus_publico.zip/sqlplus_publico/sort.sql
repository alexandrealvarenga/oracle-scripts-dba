-- https://metalink.oracle.com/metalink/plsql/f?p=130:14:11534851617457312018::::p14_database_id,p14_docid,p14_show_header,p14_show_help,p14_black_frame,p14_font:NOT,102339.1,1,1,1,helvetica

SELECT tablespace_name, extent_size, total_extents, used_extents,
         free_extents, max_used_size
      FROM v$sort_segment
/
break   on report
compute sum of mb on report
SELECT s.sid, s.logon_time, s.username, u.tablespace, u.contents, u.extents, (u.blocks * (select value from v$parameter where name = 'db_block_size'))/1024/1024 Mb
FROM   v$session s, v$sort_usage u
WHERE  s.saddr=u.session_addr
order  by s.logon_time, u.extents
/


