--set echo off
--
--accept Owner char prompt 'Informe o Owner das tabelas ou tecle ENTER para todas: '
--
set linesize 80 pagesize 0 space 0
set feedback off verify off heading off termout off
set long 150000
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000

--
column dum1 noprint
column dum2 noprint
column dum3 noprint
column dum4 noprint
--
  SELECT owner dum1, table_name dum2, 10 dum3, 1 dum4,
       'Create table  '|| owner || '.' || table_name||' ( '
  FROM dba_tables
  WHERE owner not in ('SYS','SYSTEM')
UNION
  SELECT c.owner, c.table_name, 20, column_id,
         '         '||
         DECODE( column_id, 1, ' ',',')||
         RPAD(column_name,31)
                  ||DECODE(data_type,
                    'CHAR', 'CHAR ('||data_length||')',
                    'VARCHAR', 'VARCHAR ('||data_length||')',
                    'VARCHAR2', 'VARCHAR2 ('||data_length||')',
                    'RAW', 'RAW ('||data_length||')',
                    'NUMBER','NUMBER '||
                            DECODE( nvl(data_precision,0),
                                    0 , ' ',
                                    '('||data_precision||','||data_scale||')'
                                  ),
                    'FLOAT','FLOAT '||
                            DECODE( nvl(data_precision,0),
                                    0 , ' ',
                                    '('||data_precision||','||data_scale||')'
                                  ),
                    'DATE', 'DATE',
                    'LONG', 'LONG',
                    'Error in script '||data_type||' not handled '
                      ||' length '||TO_CHAR(data_length)
                      ||' precision '||TO_CHAR(data_precision)
                      ||' scale '||TO_CHAR(data_scale) )
                  ||DECODE( nullable, 'Y', '         ', ' NOT NULL' )
  FROM dba_tab_columns c, dba_tables t
  WHERE c.owner NOT IN ('SYS','SYSTEM')
  AND   c.table_name = t.table_name
UNION
  SELECT owner, table_name, 30, 1,
         ' )   '||CHR(10)||
         '           pctfree  '||pct_free||CHR(10)||
         '           pctused  '||pct_used||CHR(10)||
         '           initrans '||ini_trans||CHR(10)||
         '           maxtrans '||max_trans||CHR(10)||
         '           tablespace '||tablespace_name||CHR(10)||
         ' Storage ('||CHR(10)||
         '           initial     '||initial_extent/1024 || ' K'||CHR(10)||
         '           next        '||next_extent/1024 || ' K'||CHR(10)||
         '           minextents  '||min_extents||CHR(10)||
         '           maxextents  '||max_extents||CHR(10)||
         '           pctincrease '|| '0'||CHR(10)||
         '  )'||CHR(10)||
         '; '
  FROM dba_tables
  WHERE owner NOT IN ('SYS','SYSTEM')
ORDER BY 1,2,3,4
/
--
undef Owner
set pagesize 20 space 1
set termout on feedback on verify on heading on
