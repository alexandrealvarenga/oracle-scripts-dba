col tablespace_name for a30
col status for a20

with
tbsp_size as
    (
        select t.tablespace_name, sum(df.bytes)/1024/1024 tam_mb
        from dba_tablespaces t
        join dba_data_files df on t.tablespace_name = df.tablespace_name
        where t.contents = 'UNDO'
        group by t.tablespace_name
    ),
undo_ext as
    (
        select ue.tablespace_name, ue.status, sum(ue.blocks) * (select value from v$parameter where name = 'db_block_size')/1024/1024 tam_mb 
        from dba_undo_extents ue
        group by ue.tablespace_name, ue.status
    )
select ts.tablespace_name, ue.status, ue.tam_mb, round(ue.tam_mb/ts.tam_mb, 2) * 100 perc
from tbsp_size ts
join undo_ext ue on ts.tablespace_name = ue.tablespace_name
order by ts.tablespace_name, ue.status;

prompt Active Undo Usage - 10g
prompt
col sid for 99999999
col serial# for 99999999
col username for a30
col segment_name for a30
col "Extent Count" for 99999999
col used_ublk for 99999999
col used_urec for 99999999
col program for a30

SELECT s.sid, s.serial#, s.username, u.segment_name, count(u.extent_id) "Extent Count", t.used_ublk, t.used_urec, s.program
FROM v$session s, v$transaction t, dba_undo_extents u
WHERE s.taddr = t.addr and u.segment_name = '_SYSSMU'||t.xidusn||'$' and u.status = 'ACTIVE'
GROUP BY s.sid, s.serial#, s.username, u.segment_name, t.used_ublk, t.used_urec, s.program
ORDER BY t.used_ublk desc, t.used_urec desc, s.sid, s.serial#, s.username, s.program;

prompt Active Undo Usage - 11g
prompt
SELECT s.sid, s.serial#, s.username, u.segment_name, count(u.extent_id) "Extent Count", t.used_ublk, t.used_urec, s.program
FROM v$session s, v$transaction t, dba_undo_extents u
WHERE s.taddr = t.addr and u.segment_name like '_SYSSMU'||t.xidusn||'_%$' and u.status = 'ACTIVE'
GROUP BY s.sid, s.serial#, s.username, u.segment_name, t.used_ublk, t.used_urec, s.program
ORDER BY t.used_ublk desc, t.used_urec desc, s.sid, s.serial#, s.username, s.program;

prompt Rollback Undo Usage - only works when executed by SYS
prompt
select b.name "UNDO Segment Name", b.inst# "Instance ID", b.status$ STATUS, a.ktuxesiz "UNDO Blocks", a.ktuxeusn, a.ktuxeslt xid_slot, a.ktuxesqn xid_seq
from x$ktuxe a, undo$ b
where a.ktuxesta = 'ACTIVE' and a.ktuxecfl like '%DEAD%' and a.ktuxeusn = b.us#;
