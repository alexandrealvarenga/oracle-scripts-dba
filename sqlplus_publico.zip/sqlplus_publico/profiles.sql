-------------------------------------------------------------------------------
--       Nome : profiles.sql
--      Autor : Lucas Pimentel Lellis (lucas.lellis@cgi.com)
-- Finalidade : Mostrar os SQL Profiles de um banco
-------------------------------------------------------------------------------

col name for a30
col category for a30
col signature for 99999999999999999999
col sql_text for a100 word_wrapped
col description for a100 word_wrapped
col status for a8
col created for a30
col last_modified for a30
col force_matching for a14
col task_exec_name for a30

select  name,
        category,
        signature,
        sql_text,
        created,
        last_modified,
        description,
        type,
        status,
        force_matching,
        task_id,
        task_exec_name,
        task_obj_id,
        task_fnd_id,
        task_rec_id
from dba_sql_profiles
where upper(sql_text) like upper(nvl('&sql_text', '%'))
order by last_modified, created, name;

clear columns
undef sql_text
