select start_time, end_time, status, elapsed_seconds, input_type, 
       input_bytes_per_sec/1024/1024 input_mb_per_sec, output_bytes_per_sec/1024/1024 output_mb_per_sec, 
       trunc(input_bytes/1024/1024) input_mb, trunc(output_bytes/1024/1024) output_mb 
from V$RMAN_BACKUP_JOB_DETAILS
where start_time >= sysdate-28 and input_type in ('DB FULL','DB INCR') order by start_time ;
