set serveroutput on size 1000000
declare

BEGIN
FOR i IN (
         select LOCAL_TRAN_ID,
           STATE,
    to_char(FAIL_TIME,'dd-mon-yyyy hh24:mi:ss')  FAIL_TIME,
    to_char(FORCE_TIME,'dd-mon-yyyy hh24:mi:ss') FORCE_TIME,
    to_char(RETRY_TIME,'dd-mon-yyyy hh24:mi:ss') RETRY_TIME,
           OS_USER,
           OS_TERMINAL,
           HOST,
           DB_USER
    from   dba_2pc_pending
    order  by 4
               )
LOOP
   IF i.STATE = 'forced rollback' or  i.STATE = 'forced commit' or  i.STATE = 'collecting' or  i.STATE ='committed' THEN
           EXECUTE IMMEDIATE 'BEGIN DBMS_TRANSACTION.PURGE_LOST_DB_ENTRY('''||I.LOCAL_TRAN_ID||''');END;';
        ELSIF i.STATE = 'prepared'  THEN
          EXECUTE IMMEDIATE 'BEGIN rollback force'''||I.LOCAL_TRAN_ID||''';END;';
          EXECUTE IMMEDIATE 'BEGIN DBMS_TRANSACTION.PURGE_LOST_DB_ENTRY('''||I.LOCAL_TRAN_ID||''');END;';
        END IF;
END LOOP;
END;
/
