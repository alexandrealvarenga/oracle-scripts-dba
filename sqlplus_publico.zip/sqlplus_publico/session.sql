col inst_id      format 9
col username     format a30
col client_identifier format a20
col osuser       format a20
col sid          format 999999
col spid         format a12
col " Idle Time" format a10
col "Tempo"      format a20
col acesso       format a20
col Login       format a20
col kill       format a60
col machine    format a30
col terminal   format a30
col schemaname   format a30
col program format a48
col sql_id for a20

break on inst_id skip page

set lines 500
set verify off
accept us prompt 'Usuario (ORACLE): '
accept os prompt 'Usuario (OS)    : '
accept pg prompt 'Programa        : '
select s.inst_id
,     s.username
,     client_identifier
,     sql_id
,     to_char(s.logon_time, 'dd/mm/yyyy hh24:mi:ss') as Login
,     s.status
,     s.OSUSER
,     p.spid
,     s.sid,s.serial#
,     lpad(trim(to_char(floor(((sysdate-s.logon_time)*86400)/(3600)), 900)) ||':'|| trim(to_char(floor((((sysdate-s.logon_time)*86400) - (floor(((sysdate-s.logon_time)*86400)/(3600))*3600))/60), 900)) ||':'||trim(to_char(mod((((sysdate-s.logon_time)*86400) - (floor(((sysdate-s.logon_time)*86400)/(3600))*3600)),60), 900)), 10, ' ') "Tempo"
,     to_char(sysdate - (s.last_call_et) / 86400,'dd/mm hh24:mi') acesso
,     lpad(trim(to_char(floor(s.last_call_et/(3600)),900)||':'||trim(to_char(floor((s.last_call_et - (floor(s.last_call_et/(3600))*3600))/60),900))||':'||trim(to_char(mod((s.last_call_et - (floor(s.last_call_et/(3600))*3600)),60),900))), 10, ' ') " Idle Time"
,     s.program
,     s.machine
,     s.terminal
,     s.schemaname
,     'ALTER SYSTEM DISCONNECT SESSION ' || CHR(39) || s.SID ||','||s.SERIAL# || CHR(39) || ' immediate;' kill
--,     'EXEC SARBOX_KILL_SESSION( ' || s.SID ||','||s.SERIAL# || ')' kill
from  gv$session s, gv$process p
where upper(s.username) like upper('&us')
and   upper(nvl(s.osuser, '%'))   like upper('%&os%')
and   upper(nvl(s.program, '%'))  like upper('%&pg%')
and   s.paddr = p.addr
and   s.inst_id = p.inst_id
order by s.inst_id, s.username, s.logon_time, s.program, s.status, sysdate-s.logon_time
/
--undef us
--undef os
--undef pg
cl    col
set verify on;

clear breaks