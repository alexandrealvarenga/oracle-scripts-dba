-- ref: http://www.comp.dit.ie/btierney/oracle11gdoc/server.111/b28321/strms_apmon.htm#i1007797

set verify off feed off head on

select apply_name "Apply Name"
from dba_apply
order by apply_name;

prompt

accept v_apply prompt 'Nome do apply: ' 

set verify off feed off head on

COLUMN APPLY_NAME HEADING 'Apply|Process|Name' FORMAT A20
COLUMN SOURCE_DATABASE HEADING 'Source|Database' FORMAT A15
COLUMN LOCAL_TRANSACTION_ID HEADING 'Local|Transaction|ID' FORMAT A20
COLUMN ERROR_NUMBER HEADING 'Error Number' FORMAT 99999999
COLUMN ERROR_MESSAGE HEADING 'Error Message' FORMAT A30
COLUMN MESSAGE_COUNT HEADING 'Messages in|Error|Transaction' FORMAT 99999999

SELECT APPLY_NAME, 
       SOURCE_DATABASE, 
       LOCAL_TRANSACTION_ID, 
       ERROR_NUMBER,
       ERROR_MESSAGE,
       MESSAGE_COUNT
  FROM DBA_APPLY_ERROR
where apply_name like upper('&v_apply');

