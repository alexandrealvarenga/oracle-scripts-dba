set serveroutput on size 1000000

declare

   procedure reeng_fk
      (  tbl_owner      in varchar2
      ,  tbl_name       in varchar2
      ) as
      v_virg         varchar2(1);
      v_maxcol       number;
      v_tname        varchar2(30);
      v_owner        varchar2(30);
      w_owner        varchar2(50);
      w_table        varchar2(50);
      w_pk           varchar2(50);
      w_p1           char;
      w_p2           char;
      p_fase         number;
   begin
      select   owner,   table_name, constraint_name
      into     w_owner, w_table,    w_pk
      from     dba_constraints
      where    owner           = tbl_owner
      and      table_name      = tbl_name
      and      constraint_type = 'P';
      w_p1 := 'N';
      p_fase := 1;
      if p_fase = 1 then
         for rcnd in (select owner
                     ,      table_name
                     ,      constraint_name
                     ,      r_constraint_name
                     ,      decode(delete_rule, 'CASCADE', ' ON DELETE CASCADE', '') dr
                     from   dba_constraints
                     where  constraint_type='R'
                     and    owner = w_owner
                     and    r_constraint_name = w_pk
                     order by table_name)
         loop
            if w_p1 = 'N' then
               w_p1 := 'S';
               dbms_output.put_line('--');
               dbms_output.put_line('-- DROP FOREIGN KEYS --');
               dbms_output.put_line('--');
            end if;
            dbms_output.put_line ('ALTER TABLE '||rcnd.owner||'.'||rcnd.table_name||' DROP CONSTRAINT '||rcnd.constraint_name||';');
         end loop;
      end if;

      w_p2 := 'N';
      p_fase := 2;
      if p_fase = 2 then
         for rcn in (select owner
                     ,      table_name
                     ,      constraint_name
                     ,      r_constraint_name
                     ,      decode(delete_rule, 'CASCADE', ' ON DELETE CASCADE', '') dr
                     from   dba_constraints
                     where  constraint_type='R'
                     and    owner = w_owner
                     and    r_constraint_name = w_pk
                     order by table_name)
         loop
            if w_p2 = 'N' then
               w_p2 := 'S';
               dbms_output.put_line('--');
               dbms_output.put_line('-- ADD FOREIGN KEYS --');
               dbms_output.put_line('--');
            end if;
            dbms_output.put_line ('ALTER TABLE '||rcn.owner||'.'||rcn.table_name||' ADD (');
            dbms_output.put_line ('CONSTRAINT '||rcn.constraint_name);
            dbms_output.put_line ('FOREIGN KEY (');
            v_virg:=',';
            for rcl in (select column_name
                        ,      position
                        from   dba_cons_columns cl
                        where  cl.constraint_name=rcn.constraint_name
                        and    cl.owner = rcn.owner
                        order  by position)
            loop
               select max(position)
               into   v_maxcol
               from   dba_cons_columns c
               where  c.constraint_name= rcn.constraint_name
               and    c.owner          = rcn.owner;
               if rcl.position = v_maxcol then
                  v_virg:='';
               end if;
               dbms_output.put_line (rcl.column_name||v_virg);
            end loop;
            select table_name, owner
            into   v_tname, v_owner
            from   dba_constraints c
            where  c.constraint_name=rcn.r_constraint_name
            and    c.owner          =rcn.owner;
            dbms_output.put_line(') REFERENCES '||v_owner||'.'||v_tname||' (');
            select max(position)
            into   v_maxcol
            from   dba_cons_columns c
            where  c.constraint_name=rcn.r_constraint_name
            and    owner            =rcn.owner;
            v_virg:=',';
            select max(position)
            into   v_maxcol
            from   dba_cons_columns c
            where  c.constraint_name=rcn.r_constraint_name
            and    c.owner          =rcn.owner;
            for rcr in (select column_name
                        ,      position
                        from   dba_cons_columns cl
                        where  rcn.r_constraint_name=cl.constraint_name
                        and    rcn.owner            =cl.owner
                        order  by position)
            loop
               if rcr.position=v_maxcol then
                  v_virg:='';
               end if;
               dbms_output.put_line (rcr.column_name||v_virg);
            end loop;
            dbms_output.put_line(')'||rcn.dr||');');
            dbms_output.put_line(' ');
         end loop;
      end if;
   exception
      when no_data_found then null;
   end reeng_fk;

begin

      reeng_fk('BDSGPD', 'ZYHACEST');
end;
/
