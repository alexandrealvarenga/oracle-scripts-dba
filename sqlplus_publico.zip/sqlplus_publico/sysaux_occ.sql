col occupant_name for a40;
col occupant_desc for a55;
col space_usage_mbytes for 999G999G999G999G990D00
SELECT occupant_name,occupant_desc,space_usage_kbytes/1024 space_usage_mbytes
FROM v$sysaux_occupants
order by space_usage_mbytes desc, occupant_name
/
