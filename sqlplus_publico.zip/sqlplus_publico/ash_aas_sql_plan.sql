/* ASH_AAS_SQL_PLAN.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Listagem dos principais SQLs Plans (em AAS) por evento e periodo
 * Utilizacao: @ash_aas_sql_plan intervalo dt_inicial dt_final [evento] (intervalo em minutos, data no formato YYYYMMDDHH24MI)
 *             @ash_aas_sql_plan intervalo last periodo_minutos [evento]
 * Obs.:       Parametros entre colchetes sao opcionais
 *
 * Exemplos: @ash_aas_sql_plan 1 201404291000 201404291005 'db file sequential read'
 *           @ash_aas_sql_plan 5 last 60 'db file%'
 *           @ash_aas_sql_plan 1 201404291000 201404291005
 *           @ash_aas_sql_plan 5 last 60
 *
 * Baseado no script ash_graph_waits_histash.sql de Kyle Hailey, em https://github.com/khailey/ashmasters
 * Ref.: http://www.oraclerealworld.com/ash-masters/
 */

store set %temp%\sqlenv replace

set verify off echo off lines 180 pages 9999 serveroutput on

set feed off
alter session set nls_timestamp_format='DD/MM/RR HH24:MI';
set feed on

define C_SMP_INT_ASH=1                  -- Intervalo de amostragem da view V$ACTIVE_SESSION_HISTORY (em segundos)
define C_SMP_INT_ASH_HIST=10            -- Intervalo de amostragem da view DBA_HIST_ACTIVE_SESS_HISTORY (em segundos)
define C_SMP_WIDTH=14                   -- Largura do display do sample time
define C_EVT_WIDTH=50                   -- Largura do display do evento
define C_SQLPLAN_FMT=99999999999999     -- Formato de display do SQL_PLAN_HASH_VALUE
define C_NUM_TOP_EVT=10                 -- Numero de top events
define C_PCT_FMT=9990.00                -- Formato de display da porcentagem
define C_AAS_FMT=9990.00                -- Formato de display de AAS
define C_DT_INPUT_FMT=YYYYMMDDHH24MI    -- Formato de input de data
define C_GRP_WIDTH=10                   -- Largura do grafico
define C_TSTP_FMT=YYYYMMDDHH24MISSFF    -- Formato de conversao de timestamp para varchar

-- Define o valor default do quarto parametro, que eh opcional
set feed off term off
col p4 new_value 4
select null p4 from dual where  1=2;
select nvl('&4','%') p4 from dual;
set feed on term on

define p_smp_int=&1
define p_ini_date=&2
define p_end_date=&3
define p_event="&4"

variable smp_int number
variable smp_period number
variable ini_date varchar2(20)
variable end_date varchar2(20)
variable scan_history number
variable event_name varchar2(100)
variable ash_min_time varchar2(30)

set feed off
declare
    l_ash_min_time timestamp := null;
    l_cpu_count number := 0;
    l_smp_period_interval interval day to second;
begin
    :smp_int := &p_smp_int;
    :ini_date := upper('&p_ini_date');
    :event_name := '&p_event';
    
    if (:ini_date = 'LAST') then
        :ini_date := to_char((systimestamp - &p_end_date/60/24), '&C_DT_INPUT_FMT');
        :end_date := to_char(systimestamp, '&C_DT_INPUT_FMT');
    else
        :ini_date := '&p_ini_date';
        :end_date := '&p_end_date';
    end if;

    l_smp_period_interval := to_timestamp(:end_date, '&C_DT_INPUT_FMT') - to_timestamp(:ini_date, '&C_DT_INPUT_FMT');
    :smp_period := 24*60*extract(day from l_smp_period_interval) + 60*extract(hour from l_smp_period_interval) + extract(minute from l_smp_period_interval);

    if :smp_int > :smp_period then
        :smp_int := :smp_period;
        dbms_output.put_line('Sampling Interval - corrected: '||:smp_int);
    end if;

    -- Ajusta o horario de inicio caso o intervalo nao seja multiplo do periodo analisado
    if mod(:smp_period, :smp_int) <> 0 then
        :smp_period := ceil(:smp_period/:smp_int) * :smp_int; 
        :ini_date := to_char((to_date(:end_date, '&C_DT_INPUT_FMT') - :smp_period/60/24), '&C_DT_INPUT_FMT');

        dbms_output.put_line('Analyzed Period - corrected: '||to_date(:ini_date, '&C_DT_INPUT_FMT')
                        ||' - '||to_date(:end_date, '&C_DT_INPUT_FMT'));
    end if;

    select min(sample_time)
    into l_ash_min_time
    from v$active_session_history;
     -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
     -- Ref: http://optimizermagic.blogspot.com.br/2008/06/why-are-some-of-tables-in-my-query.html
    if (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') < l_ash_min_time) then
       :scan_history := 1;
    else
       :scan_history := 2;
    end if;
    :ash_min_time := to_char(l_ash_min_time, '&C_TSTP_FMT');

    select value
    into l_cpu_count
    from v$parameter
    where upper(name) = 'CPU_COUNT';

    dbms_output.put_line(chr(10)||'CPU Count: '||l_cpu_count
                   ||chr(10)||'AAS - Average Active Sessions');
end;
/
set feed on

col sample for a&C_SMP_WIDTH
col event for a&C_EVT_WIDTH
col sql_plan_hash_value for &C_SQLPLAN_FMT
col aas for &C_AAS_FMT heading "AAS|Plan Value"
col aas_event for &C_AAS_FMT heading "AAS-Event"
col aas_sample for &C_AAS_FMT heading "AAS-Sample"
col graph for a&C_GRP_WIDTH
col pct for &C_PCT_FMT justify right heading "(%)"
col command for a40 trunc

break on sample skip page on aas_sample on sql_plan_hash_value on aas_sample on aas on pct on graph on command

with 
t1 as
(
    select /*+ OPT_ESTIMATE(TABLE, D, ROWS=100) */
           to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level, 'minute')*:smp_int dt, 
           to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level-1, 'minute')*:smp_int next_dt
    from dual d
    connect by level <= (:smp_period/:smp_int)
),
events as 
(
    select trunc(sample_time, 'MI') sample_time, nvl(event, 'ON CPU') event, sql_plan_hash_value, sql_opcode, sum(&C_SMP_INT_ASH) cnt
    from v$active_session_history h
    where (h.sample_time >= to_date(:ini_date, '&C_DT_INPUT_FMT') and h.sample_time < to_date(:end_date, '&C_DT_INPUT_FMT'))
      and session_type = 'FOREGROUND'
      and sql_plan_hash_value is not null
      and lower(nvl(event, 'ON CPU')) like lower(:event_name)
    group by trunc(sample_time, 'MI'), nvl(event, 'ON CPU'), sql_plan_hash_value, sql_opcode
    union all
    select /*+ 
                NO_MERGE(C)
                NO_MERGE(S)
                NO_MERGE(D)
                LEADING(C S D)
                OPT_ESTIMATE(TABLE S ROWS=1000)
                OPT_ESTIMATE(TABLE D ROWS=50000)
                OPT_ESTIMATE(TABLE D.ASH ROWS=50000) 
                OPT_ESTIMATE(TABLE D.SN ROWS=1500) 
                OPT_ESTIMATE(TABLE D.EVT ROWS=1000)
                LEADING(D.SN D.ASH D.EVT)
                USE_HASH(D.SN D.ASH D.EVT)
           */
           trunc(sample_time, 'MI') sample_time, nvl(d.event, 'ON CPU') event, sql_plan_hash_value, sql_opcode, sum(&C_SMP_INT_ASH_HIST) cnt
    from dba_hist_wr_control c,
         dba_hist_snapshot s,
         dba_hist_active_sess_history d
    where 1 = :scan_history -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
      /* JOINS - INICIO */
      and s.dbid = c.dbid
      and d.snap_id = s.snap_id 
      and s.dbid = d.dbid 
      and s.instance_number = d.instance_number
      /* JOINS - FIM */
      and s.end_interval_time > (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') - c.snap_interval)     -- Considera snapshots adjacentes, pois o sample_time
      and s.begin_interval_time < (to_timestamp(:end_date, '&C_DT_INPUT_FMT') + c.snap_interval)   -- pode ser menor do que o begin_interval_time
      and (d.sample_time >= to_date(:ini_date, '&C_DT_INPUT_FMT') and d.sample_time < to_date(:end_date, '&C_DT_INPUT_FMT'))
      and d.sample_time < to_timestamp(:ash_min_time, '&C_TSTP_FMT')
      and s.instance_number = sys_context('USERENV', 'INSTANCE')
      and s.dbid = (select dbid from v$database)
      and d.session_type = 'FOREGROUND'
      and d.sql_plan_hash_value is not null
      and lower(nvl(d.event, 'ON CPU')) like lower(:event_name)
    group by trunc(sample_time, 'MI'), nvl(d.event, 'ON CPU'), sql_plan_hash_value, sql_opcode
)
select sample,
       aas_sample,
       sql_plan_hash_value,
       nvl(a.name, 'N/A') command,
       aas,
       (aas/decode(aas_sample, 0, 1, aas_sample)) * 100 pct,
       rpad('+', (aas/decode(aas_sample, 0, 1, aas_sample)) * &C_GRP_WIDTH, '+') graph,
       aas_event,
       event
from (       
    select sample,
           event,
           sql_plan_hash_value,
           sql_opcode,
           aas_event,
           aas,
           aas_sample,
           dense_rank() over (partition by sample order by aas desc, sql_plan_hash_value) rn
    from
    (
        select sample,
               event,
               sql_plan_hash_value,
               sql_opcode,
               nvl(aas_event, 0) aas_event,
               sum(nvl(aas_event, 0)) over (partition by sample, sql_plan_hash_value) aas,
               sum(nvl(aas_event, 0)) over (partition by sample) aas_sample
        from
        (
            select t1.dt sample, 
                   e.event,
                   e.sql_plan_hash_value,
                   e.sql_opcode,
                   sum(cnt)/(60*:smp_int) aas_event
            from t1
            left outer join events e on e.sample_time >= t1.dt and e.sample_time < t1.next_dt
            group by t1.dt, event, e.sql_plan_hash_value, e.sql_opcode
        )
    )
) t
left outer join audit_actions a on a.action = t.sql_opcode
where rn <= &C_NUM_TOP_EVT
order by sample, aas desc, aas_event desc
/

undef 1 2 3 4
undef p_smp_int p_ini_date p_end_date p_event p4
undef C_SMP_INT_ASH C_SMP_INT_ASH_HIST C_EVT_WIDTH C_SQLPLAN_FMT C_NUM_TOP_EVT C_PCT_FMT C_DT_INPUT_FMT C_GRP_WIDTH C_TSTP_FMT C_SMP_WIDTH C_AAS_FMT
clear breaks
clear columns

@%temp%\sqlenv
prompt
