--
-- Autor: Lucas Pimentel Lellis
-- Descricao: Exibe as estatisticas de uma tabela e suas colunas
-- Data: 15/08/2014
-- Ref: http://www.toadworld.com/platforms/oracle/w/wiki/4899.script-to-report-table-statistics.aspx
--

COLUMN owner             format a30 wrap                 heading "Table|Owner"
COLUMN table_name        format a30 wrap                 heading "Table|Name"
COLUMN Tablespace_name   format a30 wrap                 heading "Tablespace|Name"
COLUMN num_rows          format 999G999G999G999          Heading "Number|Of|Rows"
COLUMN blocks            format 999G999G999G999          Heading "Number|Of|Blocks"
COLUMN empty_blocks      format 999G999G999G999          Heading "Number|Of|Empty|Blocks"
COLUMN avg_row_len       format 999G999G999G999          Heading "Average|Row|Length"
COLUMN sample_size       format 999G999G999G999          Heading "Sample|Size"
COLUMN last_analyzed     heading "Date|Last|Analyzed"
COLUMN stale_stats       format a5                       Heading "Stale|Stats"

set verify off

accept owner   prompt 'Owner: '
accept tabname prompt 'Table: '

SELECT   t.owner, t.table_name, s.stale_stats, t.tablespace_name, t.num_rows, t.blocks, t.empty_blocks,
         t.avg_row_len, t.sample_size, t.last_analyzed
    FROM dba_tables t
    JOIN dba_tab_statistics s on t.owner = s.owner and t.table_name = s.table_name
   WHERE t.owner LIKE upper('&OWNER')
     AND t.table_name LIKE upper('&TABNAME')
     AND s.partition_name is null
     AND s.subpartition_name is null
ORDER BY t.owner, t.table_name;

col data_type for a15

set serveroutput on format wrapped size 1000000 feed off
declare
    cursor c_col_stats is
        select s.column_name, 
               c.column_id,
               c.data_type, 
               s.num_distinct, 
               s.low_value, 
               s.high_value, 
               s.density, 
               s.num_nulls, 
               s.num_buckets,
               s.last_analyzed, 
               s.sample_size, 
               s.avg_col_len, 
               s.histogram
            from dba_tab_col_statistics s,
                 dba_tab_columns c
            where c.owner = s.owner
              and c.table_name = s.table_name
              and c.column_name = s.column_name
              and c.owner LIKE upper('&OWNER')
              AND c.table_name LIKE upper('&TABNAME')
        order by column_name;
    
    function cast_from_raw(p_val in raw, p_datatype in varchar2) return varchar2 is
	    cn     number;
	    cv     varchar2(32);
	    cd     date;
	    cnv    nvarchar2(32);
	    cr     rowid;
	    cc     char(32);
	    cbf    binary_float;
	    cbd    binary_double;
	begin
	    if (p_datatype = 'VARCHAR2') then
	        dbms_stats.convert_raw_value(p_val, cv);
	        return to_char(cv);
	    elsif (p_datatype = 'DATE') then
	        dbms_stats.convert_raw_value(p_val, cd);
	        return to_char(cd);
	    elsif (p_datatype = 'NUMBER') then
	        dbms_stats.convert_raw_value(p_val, cn);
	        return to_char(cn);
	    elsif (p_datatype = 'BINARY_FLOAT') then
	        dbms_stats.convert_raw_value(p_val, cbf);
	        return to_char(cbf);
	    elsif (p_datatype = 'BINARY_DOUBLE') then
	        dbms_stats.convert_raw_value(p_val, cbd);
	        return to_char(cbd);
	    elsif (p_datatype = 'NVARCHAR2') then
	        dbms_stats.convert_raw_value(p_val, cnv);
	        return to_char(cnv);
	    elsif (p_datatype = 'ROWID') then
	        dbms_stats.convert_raw_value(p_val, cr);
	        return to_char(cr);
	    elsif (p_datatype = 'CHAR') then
	        dbms_stats.convert_raw_value(p_val, cc);
	        return to_char(cc);
	    else
	        return 'UNKNOWN DATATYPE';
	    end if;
    exception
        when others then
            return null;
    end cast_from_raw;
    
begin
    for r_col_stat in c_col_stats loop
        dbms_output.put_line('Column Name..........: '||r_col_stat.column_name);
        dbms_output.put_line('Position.............: '||r_col_stat.column_id);
        dbms_output.put_line('Data Type............: '||r_col_stat.data_type);
        dbms_output.put_line('Distinct Values......: '||to_char(r_col_stat.num_distinct, 'fm999G999G999G999'));
        dbms_output.put_line('Low Value............: '||cast_from_raw(r_col_stat.low_value, r_col_stat.data_type));
        dbms_output.put_line('High Value...........: '||cast_from_raw(r_col_stat.high_value, r_col_stat.data_type));
        dbms_output.put_line('Density..............: '||r_col_stat.density);
        dbms_output.put_line('Number of Nulls......: '||to_char(r_col_stat.num_nulls, 'fm999G999G999G999'));
        dbms_output.put_line('Number of Buckets....: '||r_col_stat.num_buckets);
        dbms_output.put_line('Last Analyzed........: '||r_col_stat.last_analyzed);
        dbms_output.put_line('Sample Size..........: '||to_char(r_col_stat.sample_size, 'fm999G999G999G999'));
        dbms_output.put_line('Average Column Length: '||r_col_stat.avg_col_len);
        dbms_output.put_line('Histogram............: '||r_col_stat.histogram);
        dbms_output.new_line();
    end loop;
end;
/

undef owner tabname
clear columns
set feed on
