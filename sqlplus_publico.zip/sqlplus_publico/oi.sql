set verify off
set echo off
set heading off

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

col command format a80
accept ow prompt 'Informe o owner (parte) dos objetos : '
accept oo prompt 'Informe o tipo objeto               : '

spool %temp%\oi_&wdt..txt

select (case
       when o.object_type  = 'SYNONYM' then
            (case when o.owner = 'PUBLIC' then
               'DESC "'||o.object_name||'";'
             else
               'DESC '|| o.owner || '."' || o.object_name || '";'
             end)
       else
            'ALTER ' || decode(o.object_type, 'PACKAGE BODY', 'PACKAGE', o.object_type) || ' ' || o.owner || '."' || o.object_name || '" COMPILE' || decode(o.object_type, 'PACKAGE BODY', ' BODY','') || ';'
       end ) commamd
from   dba_objects o
where  o.status = 'INVALID'
and    o.owner NOT IN ('BDEXEELO','PJOWMA','PJOWCA','PCMRAIL','PJMRAIL','PCPWMM','PCPWMM86','PROC176','PROC712','PROC678', 'PCTOTALP', 'PCAMADPR', 'PJENGEMAN','BDENGEMAN')
and    upper(o.owner) like upper('%&ow%')
and    upper(o.object_type) like upper('%&oo%')
and    o.owner not in (select username from dba_users where account_status = 'LOCKED')
union
select 'ALTER INDEX '||OWNER||'.'||INDEX_NAME||' REBUILD;' FROM DBA_INDEXES WHERE STATUS = 'UNUSABLE' and owner <>'BDEXEELO'
and    upper(owner) like upper('%&%')
--union 
--SELECT 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' ENABLE CONSTRAINT '||CONSTRAINT_NAME||';'
--FROM    DBA_CONSTRAINTS WHERE STATUS = 'DISABLED' and    owner <>'BDEXEELO'
--and    upper(owner) like upper('%&ow%')
--ORDER  BY 1 DESC
/

prompt

@@revoke

spool off

prompt 
prompt @%temp%\oi_&wdt..txt
prompt 

--accept temp prompt ''

--@c:\temp\oi_&wdt..txt

undef ow
undef wdt
set verify on
set heading on
