store set %temp%\sqlenv.sql replace

set feed off echo off head on serveroutput on

accept v_owner prompt 'Owner: '
accept v_object_name prompt 'Nome: '
accept v_object_type prompt 'Tipo: '

exec dbms_application_info.set_client_info('2A2A2A414E53415554482A2A2A');
create or replace procedure recur_object(v_owner in varchar2,
	v_object_name varchar2,
	v_object_type varchar2,
	level number default 0) is
	cursor c_depen is
	select referenced_owner, referenced_name, referenced_type
	from sys.dba_dependencies
	where dba_dependencies.owner = v_owner
	and dba_dependencies.name = v_object_name
	and dba_dependencies.type = v_object_type;
begin
	if v_object_type='TABLE' then 
		dbms_output.put_line('Level: '||' '||level||' '||v_owner||'.'||v_object_name);
	end if;	
	for c_rec in c_depen loop
		recur_object(c_rec.referenced_owner,
		c_rec.referenced_name,
		c_rec.referenced_type,
		level + 1);
	end loop;
	exception
		when no_data_found then
		dbms_output.put_line('No record found for: ' || ' ' || v_owner || ' ' ||
		v_object_name || ' ' || v_object_type);
end;
/

alter session set nls_date_format='dd-mon-yyyy hh24:mi:ss';
set linesize 256
set trimspool on
set serveroutput on
exec dbms_output.enable(1000000);

exec recur_object(upper('&v_owner'), upper('&v_object_name'), upper('&v_object_type'));

drop procedure recur_object;

@%temp%\sqlenv.sql
