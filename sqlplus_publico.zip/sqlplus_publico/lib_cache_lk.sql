-------------------------------------------------------------------------------------------------------------------
-- Lista sess�es e objetos em espera por eventos de library cache lock, assim como as sess�es que estao bloqueando
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (27/03/2017)
-- Ref.: https://orainternals.wordpress.com/2009/06/02/library-cache-lock-and-library-cache-pin-waits/
--       http://www.hhutzler.de/blog/ges-locks-and-deadlocks/#Library_Cache_LocksPins_in_a_RAC_env
-- Obs.: Executar como SYSDBA
-------------------------------------------------------------------------------------------------------------------

col sid for 999999
col serial for 9999999
col pid for 999999999
col username for a30
col module for a20
col obj_owner for a30
col obj_name for a30
col lck_cnt for 999999 heading "lck|cnt"
col lock_mode for 9999 heading "lck|mode"
col state for a30
col event for a25
col wait_time for 999999 heading "wait|time"
col seconds_in_wait for 9999999 heading "seconds|in wait"
col sql_text for a50 word_wrapped

select  /*+
            qb_name(main)

            cardinality(lk@main 50)
            cardinality(@subq lk_sub@subq 50)
            cardinality(@SEL$2315DE6F S@SEL$2 50)
            cardinality(@SEL$2315DE6F E@SEL$2 50)
            cardinality(@SEL$2315DE6F X$KSUPR@SEL$6 50)
            cardinality(ob@main 50)
            cardinality(@SEL$2315DE6F X$KGLCURSOR_CHILD@SEL$4 50)
            cardinality(SES@MAIN 50)

            leading(lk_sub@subq lk@main ob@main ses@main X$KGLCURSOR_CHILD@SEL$4 S@SEL$2 X$KSUPR@SEL$6 E@SEL$2)

            no_swap_join_inputs(@SEL$2315DE6F X$KSUPR@SEL$6)
            no_swap_join_inputs(SES@MAIN)
            no_swap_join_inputs(@SEL$2315DE6F E@SEL$2)
        */
        distinct ses.ksusenum sid,
                 ses.ksuseser serial#,
                 prc.spid pid,
                 ses.ksuudlna username,
                 ses.ksuseunm machine,
                 ob.kglnaown obj_owner,
                 ob.kglnaobj obj_name,
                 lk.kgllkcnt lck_cnt,
                 lk.kgllkmod lock_mode,
                 lk.kgllkreq lock_req,
                 w.state,
                 w.event,
                 w.wait_time,
                 w.seconds_in_wait,
                 substr(sql.sql_text, 0, 100) sql_text
  from x$kgllk lk, x$kglob ob, x$ksuse ses, v$session_wait w, v$sql sql, v$process prc
 where lk.kgllkhdl in (select /*+ qb_name(subq) */ kgllkhdl from x$kgllk lk_sub where kgllkreq > 0)
   and ob.kglhdadr = lk.kgllkhdl
   and lk.kgllkuse = ses.addr
   and w.sid = ses.indx
   and ses.ksusesql = sql.address(+)
   and ses.ksusesqh = sql.hash_value(+)
   and ses.ksusepro = prc.addr
 order by obj_owner, obj_name, lck_cnt desc, seconds_in_wait desc
/

clear columns