/* SPLIT_PARTS_A.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Gera comandos de split partitions do ano seguinte para tabelas particionadas por ano.
 * Utilizacao: @split_parts_t empresa owner tabela tbsp
 *
 */


set verify off
col cmd for a200
set pages 9999
undef owner tab tbsp empresa

define empresa = &1
define owner = &2
define tab = &3
define tbsp = &4

with tab_part as
(
    select owner, table_name, partition_name, tablespace_name,
           add_months(trunc(sysdate, 'YEAR'), 12) data
    from (
        select table_owner owner, table_name, partition_name, tablespace_name,
            row_number() over (partition by table_owner, table_name, tablespace_name order by partition_position desc) rn
        from dba_tab_partitions
        where table_owner = upper('&&owner')
        and table_name = upper('&&tab')
        and partition_name like upper('&&empresa.%')
    ) where rn = 1
)
select
'alter table "'||owner||'"."'||table_name||'"'||chr(10)||
'split PARTITION '||partition_name||' at ('''||upper('&&empresa')||''', '||
    to_char(add_months(data, 12), 'YYYY')||')'||chr(10)||
'into (partition '||upper('&&empresa._')||to_char(data, 'YYYY')||chr(10)||
'TABLESPACE '||upper('&&tbsp')||', PARTITION '||partition_name||' TABLESPACE '||tablespace_name||');' cmd
from tab_part;

undef owner tab tbsp empresa 1 2 3 4
