declare
    NUM_MESES pls_integer := 60;

    data_part date := sysdate;
    str_part varchar2(150) := null;
begin
    for i in 1..NUM_MESES loop
        str_part := 'PARTITION P'||to_char(data_part, 'YYYYMM')||' VALUES LESS THAN (TO_DATE('''||to_char(add_months(data_part, 1), 'YYYYMM')||''',  ''YYYYMM''))';
        
        if (i <> num_meses) then
            str_part := str_part||',';
        end if;
        
        dbms_output.put_line(str_part);
        
        data_part := add_months(data_part, 1);
    end loop;
end;
/
