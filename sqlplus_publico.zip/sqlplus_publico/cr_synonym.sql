set echo off
--
--accept Owner char prompt 'Informe o Owner dos sinonimos ou tecle ENTER para todos: '
--
set linesize 100 pagesize 0 space 0
set termout off feedback off verify off heading off
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000

--
SELECT 'create ' || DECODE(owner, 'PUBLIC', owner, NULL) || ' synonym ' ||
       synonym_name || ' for ' || table_owner || '.' || table_name ||
       DECODE(db_link, '', '', '@' || db_link) || ';'
FROM dba_synonyms
WHERE table_owner NOT IN ('SYS', 'SYSTEM')
ORDER BY synonym_name
/
undef Owner
set linesize 80 pagesize 20 space 1
set termout on feedback on verify on heading on
