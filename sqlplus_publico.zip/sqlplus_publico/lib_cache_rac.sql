---------------------------------------------------------------------------------------------------------------------
-- Lista sess�es e objetos em espera por eventos de library cache em RAC, assim como as sess�es que estao bloqueando
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (27/03/2017)
-- Ref.: https://orainternals.wordpress.com/2009/06/02/library-cache-lock-and-library-cache-pin-waits/
--       http://www.hhutzler.de/blog/ges-locks-and-deadlocks/#Library_Cache_LocksPins_in_a_RAC_env
--       https://jonathanlewis.wordpress.com/2010/06/21/locks/
---------------------------------------------------------------------------------------------------------------------

col inst_id for 9999999
col handle for a16
col grant_level for a16 heading "grant|level"
col request_level for a16 heading "request|level"
col resource_name1 for a30
col resource_name2 for a30
col pid for 999999
col transaction_id0 for 999999999999999
col transaction_id1 for 999999999999999
col owner_node for 999999 heading "owner|node"
col blocked for 9999999
col blocker for 9999999
col state for a10
col program for a35
col sid for 999999
col serial# for 9999999
col sql_text for a50 word_wrapped

select  /*+
            qb_name(main)

            no_merge(@main enq@main)
            no_merge(@main prc@main)
            no_merge(@main ses@main)
            no_merge(@main sql@main)

            leading(@main enq@main prc@main ses@main sql@main)

            no_swap_join_inputs(@main enq@main)
            no_swap_join_inputs(@main prc@main)
            no_swap_join_inputs(@main ses@main)
            no_swap_join_inputs(@main sql@main)

            cardinality(@SEL$CF5359D5 S@SEL$9 1000)
        */
        enq.resource_name1,
        enq.resource_name2,
        case
            when enq.grant_level like 'KJUSERNL%' then 'no permissions'
            when enq.grant_level like 'KJUSERCR%' then 'concurrent read'
            when enq.grant_level like 'KJUSERCW%' then 'concurrent write'
            when enq.grant_level like 'KJUSERPR%' then 'protected read'
            when enq.grant_level like 'KJUSERPW%' then 'protected write'
            when enq.grant_level like 'KJUSEREX%' then 'exclusive access'
            else enq.grant_level
        end grant_level,
        case
            when enq.request_level like 'KJUSERNL%' then 'no permissions'
            when enq.request_level like 'KJUSERCR%' then 'concurrent read'
            when enq.request_level like 'KJUSERCW%' then 'concurrent write'
            when enq.request_level like 'KJUSERPR%' then 'protected read'
            when enq.request_level like 'KJUSERPW%' then 'protected write'
            when enq.request_level like 'KJUSEREX%' then 'exclusive access'
            else enq.request_level
        end request_level,
        enq.inst_id,
        enq.pid,
        prc.program,
        ses.sid,
        ses.serial#,
        substr(sql.sql_text, 0, 100) sql_text,
        enq.handle,
        enq.owner_node,
        enq.blocked,
        enq.blocker,
        enq.state,
        enq.transaction_id0,
        enq.transaction_id1
  from gv$ges_blocking_enqueue enq,
       gv$process prc,
       gv$session ses,
       gv$sql sql
  where enq.inst_id = prc.inst_id
    and enq.pid = prc.spid
    and ses.inst_id = prc.inst_id
    and ses.paddr = prc.addr
    and ses.inst_id = sql.inst_id(+)
    and ses.sql_address = sql.address(+)
    and ses.sql_hash_value = sql.hash_value(+)
  order by enq.resource_name1, enq.blocker desc, enq.inst_id;

clear columns
