--
-- Geovani Mazioli da Silva 
-- verifica informa��es do objeto, syn�nimo e view.
-- Data: 17/07/2008
--

col owner       for a15
col OBJECT_NAME for a30
col OBJECT_TYPE for a17
col CREATED     for a21
col LAST_DDL_TIME   for a21
col STATUS      for a10
col SYNONYM_NAME    for a30
col TABLE_OWNER for a15
col TABLE_NAME  for a30
col DB_LINK     for a30
col VIEW_NAME   for a30
col text        for a90

set verify off
set pagesize 50000

accept OBJ prompt 'Objeto: '
accept OWN prompt 'Owner: '

SELECT  owner,
    OBJECT_NAME, 
    OBJECT_TYPE,
    to_char (CREATED,'dd/mm/yyyy hh24:mm:ss') CREATED,
    to_char (LAST_DDL_TIME,'dd/mm/yyyy hh24:mm:ss') LAST_DDL_TIME,
    STATUS
FROM    dba_OBJECTS 
WHERE   OBJECT_NAME like upper('%&OBJ%')
  AND   OWNER LIKE upper('%&OWN%')
/

SELECT  owner,
    SYNONYM_NAME,
    TABLE_OWNER,
    TABLE_NAME,
    DB_LINK
FROM    dba_synonyms 
WHERE   synonym_name like upper('%&OBJ%')
    AND   OWNER LIKE upper('%&OWN%')
/

SELECT  owner,
    VIEW_NAME,
    text 
FROM    dba_views 
WHERE   view_name like upper('%&OBJ%')
    AND   OWNER LIKE upper('%&OWN%')
/

undef OBJ

set verify on
