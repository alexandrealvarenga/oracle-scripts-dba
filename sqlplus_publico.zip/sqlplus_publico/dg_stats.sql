COLUMN NAME FORMAT A24
COLUMN VALUE FORMAT A16     
COLUMN DATUM_TIME FORMAT A24
SELECT NAME, VALUE, DATUM_TIME FROM V$DATAGUARD_STATS;

col process for a20
col status for a20

select process, status
from v$managed_standby
order by process;