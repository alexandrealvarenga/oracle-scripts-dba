set verify off
column dummy noprint
column  pct_used format 990D9      heading "% EM USO"
column  name    format a24     	   heading "TABLESPACE NAME"
column  bytes   format 99999999D99 heading "ALOCADO (MB)"
column  used    format 99999999D99 heading "UTILIZADO (MB)"
column  free    format 99999999D99 heading "LIVRE (MB)"
column  filename    format a120     heading "DATAFILE"

break   on report
compute sum of bytes on report
compute sum of free on report
compute sum of used on report

accept tb char prompt   'Tablespace        : '
accept pt number prompt 'Percentual de uso : '

--
-- Verifica informacoes das tablespaces
--


select /*+ dynamic_sampling(11) parallel(4) */ * from 
(
select b.tablespace_name                                              name,
	b.tablespace_name                                              dummy,
	(sum(nvl(b.bytes,0))/count(distinct a.file_id||'.'||a.block_id ))/1048576      bytes,
	(sum(nvl(b.bytes,0))/count(distinct a.file_id||'.'||a.block_id ) -
	sum(nvl(a.bytes,0))/count(distinct b.file_id ))/1048576           used,
	(sum(nvl(a.bytes,0))/count(distinct b.file_id ))/1048576                       free,
	100 * ( (sum(nvl(b.bytes,0))/count( distinct a.file_id||'.'||a.block_id )) -
	        (sum(nvl(a.bytes, 0))/count( distinct b.file_id ) )) /
	(sum(nvl(b.bytes,0))/count( distinct a.file_id||'.'||a.block_id )) pct_used
from	sys.dba_free_space a,
	(select tablespace_name, bytes, file_id 
	from sys.dba_data_files 
	union 
		select tablespace_name, bytes, file_id 
		from sys.dba_temp_files) b
where b.tablespace_name = a.tablespace_name (+)
group by b.tablespace_name
order by b.tablespace_name
)
where name like upper('&TB')
--and name not like '%TEMP%'
and   pct_used >= nvl(&pt, 0)
/

--
-- Verifica informacoes do(s) datafiles
--

select	tablespace_name name,
	'ALTER DATABASE DATAFILE '||chr(39)||file_name||chr(39)||' resize    M;'  filename,
	bytes/1048576 bytes
from	dba_data_files
where	tablespace_name like upper('&TB')
order	by tablespace_name, file_name,
	file_id
/

undef TB
set verify on;

