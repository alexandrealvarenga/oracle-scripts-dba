COLUMN Percent   format 999.99    heading 'Percent|Of IO'
COLUMN ratio     format 999.999   heading 'Block|Read|Ratio'
COLUMN phyrds                     heading 'Physical | Reads'
COLUMN phywrts                    heading 'Physical | Writes'
COLUMN phyblkrd                   heading 'Physical|Block|Reads'
COLUMN name      format a50       heading 'File|Name'
SET feedback off verify off lines 132 pages 60
TTITLE left _date center 'File IO Statistics Report' skip 2

WITH total_io AS
     (SELECT SUM (phyrds + phywrts) sum_io
        FROM v$filestat)
SELECT   NAME, phyrds, phywrts, ((phyrds + phywrts) / c.sum_io) * 100 PERCENT,
         phyblkrd, (phyblkrd / GREATEST (phyrds, 1)) ratio
    FROM SYS.v_$filestat a, SYS.v_$dbfile b, total_io c
   WHERE a.file# = b.file#
ORDER BY a.file#
/
SET feedback on verify on lines 80 pages 22
CLEAR columns
TTITLE off

CLEAR COLUMNS
SET PAGES 58 NEWPAGE 0
SET LINES 400
COLUMN EFF        FORMAT A6            HEADING '% Eff'
COLUMN RW         FORMAT 9,999,999,999 HEADING 'Phys Block read/writes'
COLUMN TS         FORMAT A25           HEADING 'Tablespace name'
COLUMN filename   FORMAT a51           HEADING 'File Name'
TTITLE left _date center 'File IO Efficiency Report' skip 2
BREAK ON TS
SELECT   f.tablespace_name ts, f.file_name filename,
           v.phyblkrd
         + v.phyblkwrt rw,
         TO_CHAR (
            DECODE (
               v.phyblkrd,
               0, NULL,
               ROUND (
                    100
                  * (  v.phyrds
                     + v.phywrts
                    )
                  / (  v.phyblkrd
                     + v.phyblkwrt
                    ),
                  2
               )
            )
         ) eff
    FROM dba_data_files f, v$filestat v
   WHERE f.file_id = v.file#
ORDER BY 1, file#;

TTITLE left _date center 'Disk I/O''s by Datafile' skip 2
COLUMN name      FORMAT a46
COLUMN phyrds    FORMAT 999,999,999
COLUMN phywrts   FORMAT 999,999,999
COLUMN read_pct  FORMAT 999.99
COLUMN write_pct FORMAT 999.99
WITH totreadwrite AS
     (SELECT SUM (phyrds) phys_reads, SUM (phywrts) phys_wrts
        FROM v$filestat)
SELECT   NAME, phyrds, phyrds * 100 / trw.phys_reads read_pct, phywrts,
         phywrts * 100 / trw.phys_wrts write_pct
    FROM totreadwrite trw, v$datafile df, v$filestat fs
   WHERE df.file# = fs.file#
ORDER BY phyrds DESC;