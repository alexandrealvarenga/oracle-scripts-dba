/* segs_tbsp.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Listagem de segmentos de uma lista de tablespaces
 * Utilizacao: @segs_tbsp "'TABLESPACE_1', 'TABLESPACE_2', ..."
 *            
 * Exemplos: @segs_tbsp "'SYSTEM', 'SYSAUX'"
 *
 */


col tam_mb for 999G999G999G990D00
col owner for a30
col segment_type for a30
col segment_name for a30
col partition_name for a30
col subpartition_name for a30
col tablespace_name for a30

set verify off

select /*+ NO_MERGE(sg) NO_MERGE(tsp) NO_MERGE(isp) LEADING(sg) */
       sg.tablespace_name,
       sg.owner,
       sg.segment_type,
       sg.segment_name,
       case
            when sg.segment_type in ('TABLE PARTITION', 'INDEX PARTITION') then sg.partition_name
            when sg.segment_type = 'TABLE SUBPARTITION' then tsp.partition_name
            when sg.segment_type = 'INDEX SUBPARTITION' then isp.partition_name
            else null
       end partition_name,
       case
            when sg.segment_type in ('TABLE PARTITION', 'INDEX PARTITION') then null
            when sg.segment_type in ('TABLE SUBPARTITION', 'INDEX SUBPARTITION') then sg.partition_name
            else null
       end subpartition_name,
       sg.bytes/1024/1024 tam_mb
from dba_segments sg
left outer join dba_tab_subpartitions tsp
    on (sg.owner = tsp.table_owner and sg.segment_name = tsp.table_name and sg.partition_name = tsp.subpartition_name)
left outer join dba_ind_subpartitions isp
    on (sg.owner = isp.index_owner and sg.segment_name = isp.index_name and sg.partition_name = isp.subpartition_name)
where sg.tablespace_name in (&1)
order by sg.owner, sg.segment_type, sg.segment_name, partition_name, subpartition_name;

clear columns
