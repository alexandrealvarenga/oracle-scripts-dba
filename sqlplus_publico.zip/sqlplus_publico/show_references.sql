-----------------
set verify off
set serveroutput on
accept 1 char prompt 'Entre com parte do nome da owner: '
accept 2 char prompt 'Entre com parte do nome do objeto: '
-----------------


declare
   s_owner varchar2(30) := upper('&1');
   s_name  varchar2(30) := upper('&2');
   --
   subtype uid  is sys.user$.user#%type;
   subtype unam is sys.user$.name%type;
   subtype oid  is sys.obj$.obj#%type;
   subtype onam is sys.obj$.name%type;
   subtype otyp is sys.obj$.type#%type;
   subtype ostat is sys.obj$.status%type;
   --
   d_name onam;
   d_typ  otyp;
   d_oid  uid;
   d_onam unam;
   d_stat varchar2(30);
   d_rem_own unam;
   d_link varchar2(31);
   --
   cursor get_user ( own_id in uid, own_name in unam ) is
      select user# u_id, name u_name
      from sys.user$
      where (user# = own_id or own_id is null)
      and (name = own_name or own_name is null);
   --
   cursor get_obj (own_id in uid, obj_id in oid, obj_name in onam) is
      select obj# o_id, name o_name, type# o_type,
         /* decode(status, 0, 'N/A', 1, 'VALID', 'INVALID') status */
         decode(status, 0, null, 1, null, 'INVALID') status
      from sys.obj$
      where owner# = own_id
      and (obj# = obj_id or obj_id is null)
      and (name like obj_name or obj_name is null);
   --
   cursor get_dependencies (obj_id in oid) is
      select level, d_obj# d_id
      from sys.dependency$
      connect by prior d_obj# = p_obj#
      start with p_obj# = obj_id;
   --
   function object_type ( obj_typ in sys.obj$.type#%type ) return varchar2 is
      obj_desc varchar2(30) := null;
   begin
      if (obj_typ = 0) then
         obj_desc := 'NEXT OBJECT';
      elsif (obj_typ = 1) then
         obj_desc := 'INDEX';
      elsif (obj_typ = 2) then
         obj_desc := 'TABLE';
      elsif (obj_typ = 3) then
         obj_desc := 'CLUSTER';
      elsif (obj_typ = 4) then
         obj_desc := 'VIEW';
      elsif (obj_typ = 5) then
         obj_desc := 'SYNONYM';
      elsif (obj_typ = 6) then
         obj_desc := 'SEQUENCE';
      elsif (obj_typ = 7) then
         obj_desc := 'PROCEDURE';
      elsif (obj_typ = 8) then
         obj_desc := 'FUNCTION';
      elsif (obj_typ = 9) then
         obj_desc := 'PACKAGE';
      elsif (obj_typ = 10) then
         obj_desc := 'NON-EXISTENT';
      elsif (obj_typ = 11) then
         obj_desc := 'PACKAGE BODY';
      elsif (obj_typ = 12) then
         obj_desc := 'TRIGGER';
      else
         obj_desc := 'UNDEFINED';
      end if;
      return ( obj_desc );
   end;

begin
   for own_rec in get_user ( null, s_owner ) loop
      for obj_Rec in get_obj ( own_rec.u_id, null, s_name ) loop
         dbms_output.put_line('.' );
         dbms_output.put_line('.' ||
            rpad(object_type ( obj_rec.o_type ),12) || '  ' ||
            own_rec.u_name || '.' || obj_rec.o_name ||
            '            ' || obj_rec.status );
         for dpnd_rec in get_dependencies ( obj_rec.o_id ) loop
            --
            select name, owner#, type#, remoteowner,
               decode( linkname, null, null, '@' || linkname),
               /* decode(status, 0, 'N/A', 1, 'VALID', 'INVALID') */
               decode(status, 0, null, 1, null, 'INVALID')
            into d_name, d_oid, d_typ, d_rem_own, d_link, d_stat
            from sys.obj$
            where obj# = dpnd_rec.d_id;
            --
            select decode(d_link,null,name,d_rem_own)
            into d_onam
            from sys.user$
            where user# = d_oid;
            --
            dbms_output.put_line('.' || lpad(' ',dpnd_rec.level*3,' ') ||
               rpad(object_type ( d_typ ),12) || '  ' ||
               d_onam || '.' || d_name || ' ' || d_link || '      ' || d_stat );
         end loop;
      end loop;
   end loop;
end;
/


undef 1
undef 2
set verify on