set echo off
--
--accept Owner char prompt 'Informe o Owner dos indices ou tecle ENTER para todos: '
--
set linesize 80 pagesize 0 space 0
set termout off feedback off verify off heading off
set long 150000
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000
--
column dum1 noprint
column dum2 noprint
column dum3 noprint
column dum4 noprint
--
  SELECT owner dum1, index_name dum2, 10 dum3, 0 dum4,
       'create '||DECODE(uniqueness,'UNIQUE','UNIQUE','')||
       ' index '|| owner || '.' || index_name||' on '
  FROM dba_indexes
  WHERE owner NOT IN ('SYS','SYSTEM')
UNION
  SELECT owner, index_name, 20, 0,
         '  '||table_owner||'.'||table_name||' ('
  FROM dba_indexes
  WHERE owner NOT IN ('SYS','SYSTEM')
UNION
  SELECT index_owner, index_name, 30, column_position,
         '      '||DECODE(column_position,1,' ',',')||column_name
  FROM dba_ind_columns
  WHERE index_owner NOT IN ('SYS','SYSTEM')
UNION
  SELECT owner, index_name, 40, 99,
         '  )'||CHR(10)||
         '           pctfree  '||pct_free||CHR(10)||
         '           initrans '||ini_trans||CHR(10)||
         '           maxtrans '||max_trans||CHR(10)||
         '           tablespace '||tablespace_name||CHR(10)||
         '  storage ('||CHR(10)||
         '           initial     '||initial_extent/1024||' K'||CHR(10)||
         '           next        '||next_extent/1024||' K'||CHR(10)||
         '           minextents  '||min_extents||CHR(10)||
         '           maxextents  '||max_extents||CHR(10)||
         '           pctincrease '||'0'||CHR(10)||
         '  )'||CHR(10)||
         '; '
  FROM dba_indexes
  WHERE owner NOT IN ('SYS','SYSTEM')
ORDER BY 1,2,3,4
/
--
undef Owner
set pagesize 20 space 1
set termout on feedback on verify on heading on
