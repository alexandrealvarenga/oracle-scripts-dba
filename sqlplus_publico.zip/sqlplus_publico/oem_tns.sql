col target_name for a30
col property_name for a40
col property_value for a60
select tgt.target_name, prop.property_name, prop.property_value
from sysman.mgmt$target tgt
join sysman.mgmt$target_properties prop on tgt.target_guid = prop.target_guid
and tgt.target_type = 'oracle_database'
and tgt.target_name = 'qbandpo1.world_qbandpo11'
order by tgt.target_name, prop.property_value;


col target_name for a30
col property_name for a40
col property_value for a60
select tgt.target_name, prop.property_name, prop.property_value
from sysman.mgmt$target tgt
join sysman.mgmt$target_properties prop on tgt.target_guid = prop.target_guid
and tgt.target_type = 'oracle_pdb'
order by tgt.target_name, prop.property_value;

col target_name for a30
col property_name for a40
col property_value for a60
select tgt.target_name, prop.property_name, prop.property_value
from sysman.mgmt$target tgt
join sysman.mgmt$target_properties prop on tgt.target_guid = prop.target_guid
and tgt.target_type = 'rac_database'
and tgt.target_name = 'qbandpo1.world'
order by tgt.target_name, prop.property_value;

col target_name for a30
col property_name for a40
col property_value for a60
select tgt.target_name, prop.property_name, prop.property_value
from sysman.mgmt$target tgt
join sysman.mgmt$target_properties prop on tgt.target_guid = prop.target_guid
and tgt.target_type = 'oracle_pdb'
and tgt.target_name = 'cpband01.world_PBAND25'
order by tgt.target_name, prop.property_value;


col sid for a20
col machinename for a60
col port for a10
select
    upper(sid.property_value) sid,
    regexp_replace(mch.property_value, '\.[a-z0-9_]+\.local', '.edp.pt') machinename,
    prt.property_value port
from
    sysman.mgmt$target tgt
    join sysman.mgmt$target_properties sid on tgt.target_guid = sid.target_guid
    join sysman.mgmt$target_properties mch on tgt.target_guid = mch.target_guid
    join sysman.mgmt$target_properties prt on tgt.target_guid = prt.target_guid
where
    tgt.target_type = 'oracle_database'
    and sid.property_name = 'SID'
    and mch.property_name = 'MachineName'
    and prt.property_name = 'Port'
order by
    sid;

col tns_entry for a300
select
    sid||'=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST='||machinename||')(PORT='||port||')))(CONNECT_DATA=(SID='||sid||')(SERVER=DEDICATED)))' tns_entry
from
    (
        select
            upper(sid.property_value) sid,
            regexp_replace(
                mch.property_value,
                '\.[a-z0-9_]+\.local',
                '.edp.pt'
            ) machinename,
            prt.property_value port
        from
            sysman.mgmt$target tgt
            join sysman.mgmt$target_properties sid on tgt.target_guid = sid.target_guid
            join sysman.mgmt$target_properties mch on tgt.target_guid = mch.target_guid
            join sysman.mgmt$target_properties prt on tgt.target_guid = prt.target_guid
        where
            tgt.target_type = 'oracle_database'
            and sid.property_name = 'SID'
            and mch.property_name = 'MachineName'
            and prt.property_name = 'Port'
        order by
            sid
    );

col tns_entry for a300
select
    regexp_replace(srv, '\..+', '') || '=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=' || machinename || ')(PORT=' || port || ')))(CONNECT_DATA=(SERVICE_NAME=' || srv || ')(SERVER=DEDICATED)))' tns_entry
from
    (
        select
            upper(srv.property_value) srv,
            regexp_replace(
                mch.property_value,
                '\.[a-z0-9_]+\.local',
                '.edp.pt'
            ) machinename,
            prt.property_value port
        from
            sysman.mgmt$target tgt
            join sysman.mgmt$target_properties srv on tgt.target_guid = srv.target_guid
            join sysman.mgmt$target_properties mch on tgt.target_guid = mch.target_guid
            join sysman.mgmt$target_properties prt on tgt.target_guid = prt.target_guid
            join sysman.mgmt$target_properties rt on tgt.target_guid = rt.target_guid
        where
            tgt.target_type = 'oracle_pdb'
            and srv.property_name = 'ServiceName'
            and mch.property_name = 'MachineName'
            and prt.property_name = 'Port'
            and rt.property_name = 'IS_ROOT'
            and rt.property_value = 'NO'
        order by
            srv
    );
