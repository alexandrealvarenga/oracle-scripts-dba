set verify off

SELECT USERNAME, DESCRIPTION
FROM sarbox_user_description@orapvt001
where username in (
	select distinct owner
	from dba_segments
	where tablespace_name = upper('&1'))
order by 1;
