col table_owner for a15
col table_name for a23
col index_name for a30
col column_name for a20
col column_position for 999
set lines 120 verify off

select table_owner,table_name,index_name,column_name,column_position
from dba_ind_columns
where table_name = upper('&1')
or index_name like upper('&1')
order by decode(substr(index_name, 4, 2), 'IX', 2, 1), table_owner,table_name,index_name,column_position
/
