select distinct fail_time, state, 'execute dbms_transaction.purge_lost_db_entry ('||chr(39)||local_tran_id||chr(39)||')'||chr(10)||'commit;' cmd
from dba_2pc_pending
order by fail_time       
/
