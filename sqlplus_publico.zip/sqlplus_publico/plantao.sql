-- Verificar apontamento em plantao

set verify off echo off serveroutput on feed off
ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY HH24:MI:SS'; 

prompt Informar a data inicio dos apontamentos de Plant�o ABD
accept data prompt 'Data (ddmmyyyy): '


DECLARE
	v_data_fim_anterior date;
	
	CURSOR c_apont IS SELECT fun.nom_funcionario, apo.data_hora_inicio_apontamento, apo.data_hora_fim_apontamento, apo.dsc_atendimento
					  FROM pcansapu.apontamento apo, pcansexp.funcionario fun
	                  where apo.cod_seq_sobreaviso = 35
	                  AND apo.cod_seq_funcionario = fun.cod_seq_funcionario
	                  AND data_hora_inicio_apontamento >= trunc(to_date('&data','ddmmyyyy'))
	                  ORDER BY data_hora_inicio_apontamento;
BEGIN
	dbms_output.put_line(chr(13));
	
	for v_apont in c_apont loop
		-- Se for Sabado e Domingo, verifica o dia inteiro
		if ((to_char(v_apont.data_hora_inicio_apontamento, 'D') in (1, 7)) or (pcansexp.sf_feriado(v_apont.data_hora_inicio_apontamento, 2, 0) = 'S')) then
			if (v_data_fim_anterior <> v_apont.data_hora_inicio_apontamento) then
				dbms_output.put_line(v_data_fim_anterior||' - ' ||v_apont.data_hora_inicio_apontamento || ' - ' || v_apont.nom_funcionario);
			end if;
		-- Se for dia de semana, exclui o periodo de 8 a 17
		else
			if (v_data_fim_anterior <> v_apont.data_hora_inicio_apontamento)
			and ((v_data_fim_anterior < trunc(v_data_fim_anterior) + 8/24) or (v_apont.data_hora_inicio_apontamento > trunc(v_apont.data_hora_inicio_apontamento) + 17/24))
			then
				dbms_output.put_line(v_data_fim_anterior||' - ' ||v_apont.data_hora_inicio_apontamento || ' - ' || v_apont.nom_funcionario);
			end if;
		end if;
		
		if to_char(v_apont.data_hora_fim_apontamento, 'HH24:MI:SS') = '23:59:59' then
			v_data_fim_anterior := v_apont.data_hora_fim_apontamento + 1.0/(24*60*60);
		else
			v_data_fim_anterior := v_apont.data_hora_fim_apontamento;
		end if;
		
	end loop;
	
	dbms_output.put_line(chr(13));
END;
/

set feed on serveroutput off
