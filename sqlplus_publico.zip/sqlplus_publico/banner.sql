set serveroutput on feed off
DECLARE
	inst_name v$instance.instance_name%type;
BEGIN
	select instance_name
	into inst_name
	from v$instance;
	
	IF upper(substr(inst_name, 1, 1)) = 'P' OR
	   upper(inst_name) = 'EILP'            THEN
		dbms_output.put_line('####################################################################### ');
		dbms_output.put_line('###           _______  _______  _______  _______  ______   _  _  _  ### ');
		dbms_output.put_line('### |\     /|(  ___  )/ ___   )(  ___  )(  ____ )(  __  \ ( )( )( ) ### ');
		dbms_output.put_line('### | )   ( || (   ) |\/   )  || (   ) || (    )|| (  \  )| || || | ### ');
		dbms_output.put_line('### | (___) || (___) |    /   )| (___) || (____)|| |   ) || || || | ### ');
		dbms_output.put_line('### |  ___  ||  ___  |   /   / |  ___  ||     __)| |   | || || || | ### ');
		dbms_output.put_line('### | (   ) || (   ) |  /   /  | (   ) || (\ (   | |   ) |(_)(_)(_) ### ');
		dbms_output.put_line('### | )   ( || )   ( | /   (_/\| )   ( || ) \ \__| (__/  ) _  _  _  ### ');
		dbms_output.put_line('### |/     \||/     \|(_______/|/     \||/   \__/(______/ (_)(_)(_) ### ');
		dbms_output.put_line('###                                                                 ### ');
		dbms_output.put_line('###           _______  _______  _______    ______   _______         ### ');
		dbms_output.put_line('### |\     /|(  ____ \(  ____ )(  ____ \  (  ___ \ (  ____ \        ### ');
		dbms_output.put_line('### | )   ( || (    \/| (    )|| (    \/  | (   ) )| (    \/        ### ');
		dbms_output.put_line('### | (___) || (__    | (____)|| (__      | (__/ / | (__            ### ');
		dbms_output.put_line('### |  ___  ||  __)   |     __)|  __)     |  __ (  |  __)           ### ');
		dbms_output.put_line('### | (   ) || (      | (\ (   | (        | (  \ \ | (              ### ');
		dbms_output.put_line('### | )   ( || (____/\| ) \ \__| (____/\  | )___) )| (____/\        ### ');
		dbms_output.put_line('### |/     \|(_______/|/   \__/(_______/  |/ \___/ (_______/        ### ');
		dbms_output.put_line('###                                                                 ### ');
		dbms_output.put_line('###  ______   _______  _______  _______  _______  _        _______  ### ');
		dbms_output.put_line('### (  __  \ (  ____ )(  ___  )(  ____ \(  ___  )( (    /|(  ____ \ ### ');
		dbms_output.put_line('### | (  \  )| (    )|| (   ) || (    \/| (   ) ||  \  ( || (    \/ ### ');
		dbms_output.put_line('### | |   ) || (____)|| (___) || |      | |   | ||   \ | || (_____  ### ');
		dbms_output.put_line('### | |   | ||     __)|  ___  || | ____ | |   | || (\ \) |(_____  ) ### ');
		dbms_output.put_line('### | |   ) || (\ (   | (   ) || | \_  )| |   | || | \   |      ) | ### ');
		dbms_output.put_line('### | (__/  )| ) \ \__| )   ( || (___) || (___) || )  \  |/\____) | ### ');
		dbms_output.put_line('### (______/ |/   \__/|/     \|(_______)(_______)|/    )_)\_______) ### ');
		dbms_output.put_line('###                                                                 ### ');
		dbms_output.put_line('####################################################################### ');
	END IF;
END;
/
