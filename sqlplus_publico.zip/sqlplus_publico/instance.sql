promp ====================================================================================================
set feedback off
select instance_name, host_name from v$instance;
col name format a35
col value format a30
select name,value from v$parameter where name in
(
'log_checkpoint_interval',
'log_checkpoints_to_alert',
'log_checkpoint_timeout',
'log_buffer',
'db_writer_processes'
)
order by 1 ;
cl col
col      member   format a60
col      archived format a10
col      bytes    format 999G999G999G999
select   t1.group#
,        t1.thread#
,        t1.status
,        t2.member
,        bytes
,        t1.archived
from     v$log       t1
,        v$logfile   t2
where    t1.group# = t2.group#
order    by t1.group#;
cl col
col "Qtd SWT" format 999999999
select to_char(trunc(FIRST_TIME), 'dd/mm/yyyy') Data
,      count(*) "Qtd SWT"
from   v$loghist
where  first_time >= trunc(sysdate-30)
group  by trunc(FIRST_TIME)
order by trunc(FIRST_TIME);
promp ====================================================================================================
cl col
set feedback on
