set verify off

SELECT COUNT (*) FROM &1
/

set verify on
