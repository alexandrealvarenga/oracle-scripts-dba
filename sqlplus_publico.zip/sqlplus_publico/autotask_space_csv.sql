------------------------------------------------------------------------
-- Gera arquivo csv com os �ltimos resultado da SYS_AUTO_SPCADV
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (24/03/2017)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

accept l_dir default '%TEMP%' prompt 'Diret�rio de destino (default - %TEMP%): '

set long 2000000000 longchunksize 8192000 lines 32767 trimspool on feed off term off newpage none head off

col nome_arquivo new_val l_nome_arquivo noprint
select lower(sys_context('userenv','instance_name'))||'_space_'||to_char(sysdate, 'yyyymmddhh24miss') nome_arquivo
from dual;

col language new_val l_language noprint
col territory new_val l_territory noprint
col charset new_val l_charset noprint

-- DBMS_SPACE.ASA_RECOMMENDATIONS Fails With ORA-06502 (Doc ID 1380978.1)
begin
    for r_param in (select parameter, value from nls_database_parameters
                    where parameter in ( 'NLS_LANGUAGE', 'NLS_TERRITORY')) loop
        execute immediate 'alter session set '||r_param.parameter||'='''||r_param.value||'''';
    end loop;
end;
/

col csv for a32767

spool "&l_dir\&l_nome_arquivo..csv"

select '"Tablespace","Owner","Segmento","Tipo de Segmento","Parti��o","Alocado (MB)","Usado (MB)","Fragmentado (MB)","Fragmentado (%)"' header
from dual;

select '"'||tablespace_name||'","'||segment_owner||'","'||segment_name||'","'||segment_type||'","'||partition_name||'","'||
       allocated_mb||'","'||used_mb||'","'||reclaimable_mb||'","'||reclaimable_pct||'"' csv
from (
  select task_id, tablespace_name, segment_owner, segment_name, segment_type, partition_name,
         round(allocated_space/1024/1024, 0) allocated_mb, round(used_space/1024/1024, 0) used_mb,
         round(reclaimable_space/1024/1024, 0) reclaimable_mb, round(reclaimable_space*100/allocated_space, 0) reclaimable_pct,
         row_number() over (partition by tablespace_name, segment_owner, segment_name, segment_type, partition_name order by task_id desc) rn
  from table(dbms_space.asa_recommendations(all_runs => 'TRUE', show_manual => 'FALSE'))
  where recommendations like '%erform shrink%' or recommendations like 'Perform re-org%'
)
where rn = 1
and (reclaimable_mb > 50 or reclaimable_pct > 25)
order by reclaimable_mb desc, allocated_mb;

spool off

prompt
@%temp%\sqlenv
prompt
prompt host "&l_dir\&l_nome_arquivo..csv"
prompt

undef l_dir l_nome_arquivo
clear columns
