col inst_id 	for 9999 	hea INST
col situacao	for a5
col sid 	for 999999
col username 	for a15
col status	for a8
col min		for 999999	hea MIN
col osuser	for a20
col terminal	for a14
col program	for a31
col client_info	for a31

SELECT 
	S.inst_id,
	DECODE(request,0,'LOKER','_') "INFOR",
	S.sid,
	S.username, 
	S.status,
	S.SECONDS_IN_WAIT/60 as min,
	S.osuser,
	S.terminal, 
	S.program,
	S.client_info
FROM 
	GV$LOCK L, 
	GV$SESSION S
WHERE S.SID = L.SID 
--	and S.program='dllhost.exe'
	AND (id1, id2, L.type) IN 
	(
		SELECT id1, id2, type 
		FROM GV$LOCK 
		WHERE request>0
	)
ORDER BY min;
--id1, request;

clear column



--select o.owner, o.object_name, L.SESSION_ID, s.username, s.program, substr(q.sql_text,1,150)
--from v$locked_object l, dba_objects o, v$session s, v$sql q
--where 
--	l.object_id = o.object_id and 
--	l.session_id = s.sid and 
--	s.sql_address = q.address;

