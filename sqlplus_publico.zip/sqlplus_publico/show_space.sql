-- Baseado em http://www.oracle-base.com/dba/monitoring/show_space.sql
-- Uso: @show_space owner tabela particao tipo_segmento
--      tipo_segmento: t  (tabela)
--                     tp (particao de tabela)
--                     ts (subparticao de tabela)
--                     i  (indice)
--                     ip (indice de particao)
--                     is (indice de subparticao)
--                     c  (cluster)
--                     l  (lob)
--                     lp (particao de lob)
--                     ls (subparticao de lob)
-- Exemplos: @show_space hr emp p201204 p
--           @show_space hr dept '' t

define owner = '&1'
define segname = '&2'
define partname = '&3'
define parttype = '&4'

set serveroutput on verify off

DECLARE
  p_segname     VARCHAR2(30);
  p_owner       VARCHAR2(30);
  p_part_name   VARCHAR2(30);
  p_part_type   VARCHAR2(30);
  p_type        VARCHAR2(30);

  l_free_blks          NUMBER;
  l_total_blocks       NUMBER;
  l_total_bytes        NUMBER;
  l_unused_blocks      NUMBER;
  l_unused_bytes       NUMBER;
  l_lastusedextfileid  NUMBER;
  l_lastusedextblockid NUMBER;
  l_last_used_block    NUMBER;
  l_segment_space_mgmt VARCHAR2(255);
  l_unformatted_blocks NUMBER;
  l_unformatted_bytes  NUMBER;
  l_fs1_blocks         NUMBER;
  l_fs1_bytes          NUMBER;
  l_fs2_blocks         NUMBER;
  l_fs2_bytes          NUMBER;
  l_fs3_blocks         NUMBER;
  l_fs3_bytes          NUMBER;
  l_fs4_blocks         NUMBER;
  l_fs4_bytes          NUMBER;
  l_full_blocks        NUMBER;
  l_full_bytes         NUMBER;
  
  avg_frag number(5,2) := 0.0;
  total_mb number(20,2) := 0;
  
  PROCEDURE p(p_label IN VARCHAR2,
                p_num   IN NUMBER) IS
  BEGIN
        dbms_output.put_line(rpad(p_label, 40, '.') || to_char(p_num, 'fm999G999G999G990D00'));
  END;
  
BEGIN
  p_segname := upper('&segname');
  p_owner := upper('&owner');
  
  if '&partname' is null or '&partname' = '' then
    p_part_name := null;
  end if;
  p_part_name := upper('&partname');
  if upper('&parttype') = 'T' then
      p_type := 'TABLE';
  elsif upper('&parttype') = 'TP' then
      p_type := 'TABLE PARTITION';
  elsif upper('&parttype') = 'TS' then
      p_type := 'TABLE SUBPARTITION';
  elsif upper('&parttype') = 'I' then
      p_type := 'INDEX';
  elsif upper('&parttype') = 'IP' then
      p_type := 'INDEX PARTITION';
  elsif upper('&parttype') = 'IS' then
      p_type := 'INDEX SUBPARTITION';
  elsif upper('&parttype') = 'C' then
      p_type := 'CLUSTER';    
  elsif upper('&parttype') = 'L' then
      p_type := 'LOB';
  elsif upper('&parttype') = 'LP' then
      p_type := 'LOB PARTITION';
  elsif upper('&parttype') = 'LS' then
      p_type := 'LOB SUBPARTITION';                     
  end if;

  dbms_space.space_usage(
    p_owner, 
    p_segname, 
    p_type, 
    l_unformatted_blocks, 
    l_unformatted_bytes, 
    l_fs1_blocks, 
    l_fs1_bytes, 
    l_fs2_blocks, 
    l_fs2_bytes, 
    l_fs3_blocks, 
    l_fs3_bytes, 
    l_fs4_blocks,
    l_fs4_bytes, 
    l_full_blocks, 
    l_full_bytes, 
    p_part_name);
    
  dbms_space.unused_space(
    segment_owner => p_owner, 
    segment_name => p_segname, 
    segment_type => p_type, 
    total_blocks => l_total_blocks, 
    total_bytes => l_total_bytes,
    unused_blocks => l_unused_blocks, 
    unused_bytes => l_unused_bytes,
    last_used_extent_file_id => l_lastusedextfileid, 
    last_used_extent_block_id => l_lastusedextblockid,
    last_used_block => l_last_used_block, 
    partition_name=> p_part_name);
    
  avg_frag := (((l_fs1_blocks/l_total_blocks) * 0.25) +
               ((l_fs2_blocks/l_total_blocks) * 0.50) +
               ((l_fs3_blocks/l_total_blocks) * 0.75) +
                (l_fs4_blocks/l_total_blocks)) * 100;  
  total_mb := round(l_total_bytes / 1024 / 1024, 2);
 
  dbms_output.put_line('Owner: '||p_owner);
  dbms_output.put_line('Segment Name: '||p_segname);
  dbms_output.put_line('Segment Type: '||p_type);
  p('Unformatted Blocks ', l_unformatted_blocks);
  p('FS1 Blocks (0-25) ', l_fs1_blocks);
  p('FS2 Blocks (25-50) ', l_fs2_blocks);
  p('FS3 Blocks (50-75) ', l_fs3_blocks);
  p('FS4 Blocks (75-100)', l_fs4_blocks);
  p('Full Blocks ', l_full_blocks);                
  p('Free Blocks (MSSM)', l_free_blks);
  p('Total Blocks', l_total_blocks);
  p('Total Bytes', l_total_bytes);
  p('Total MBytes', total_mb);
  p('Average Fragmentation (%)', round(avg_frag, 2));
  p('Average Fragmentation (MB)', round(total_mb*avg_frag/100, 2));
  p('Unused Blocks', l_unused_blocks);
  p('Unused Bytes', l_unused_bytes);
  p('Last Used Ext FileId', l_lastusedextfileid);
  p('Last Used Ext BlockId', l_lastusedextblockid);
  p('Last Used Block', l_last_used_block);
END;
/

undef 1 2 3 4 owner segname partname parttype