rem  **************************************************************************
rem
rem  NAME:  TB_RCT.sql
rem
rem  HISTORY:
rem  Date             Who              What
rem  ________  ___________________  __________________________________________
rem  02/25/91  R. Gaydos            Created
rem  03/18/92  Gary Dodge           Improved format, changed SPOOL file name
rem
rem  FUNCTION:  Build a script to re-create user
rem
rem  **************************************************************************
accept var_user prompt 'Usuario: '
set linesize 1000
set arraysize 10
set verify off
set heading off
set feedback off
column col_usuario format a300

--set termout off echo off feedback off pagesize 0 heading off verify off
REM  

set serveroutput on
declare
	v_version v$instance.version%type;
	v_user dba_users%rowtype;
	v_password varchar2(500);
begin
	select version
	into v_version
	from v$instance;
	
	select *
	into v_user
	from dba_users
	where username = upper('&var_user');
	
	if v_version like '11%' or v_version like '12%' then
		select spare4
		into v_password
		from sys.user$
		where name = upper('&var_user');
	else
		select password
		into v_password
		from sys.user$
		where name = upper('&var_user');
	end if;
	
	dbms_output.put_line('create user "'||v_user.username||'" identified by values '''||v_password||''''||' default tablespace '||v_user.DEFAULT_TABLESPACE||' temporary tablespace '||v_user.temporary_tablespace || ';');
exception
	when no_data_found then
		dbms_output.put_line('Usu�rio inexistente.');
end;
/


SELECT 'ALTER USER "'||username||'" '||DECODE(profile, 'DEFAULT', ';', ' profile '||profile||';')
from dba_users
where username = upper('&var_user');

select 'grant '||granted_role||' to "'||grantee||'";'
from dba_role_privs
where grantee = upper('&var_user')
order by granted_role;

select 'grant '||privilege||' to "'||grantee||'";'
from dba_sys_privs  
where grantee = upper('&var_user')
order by privilege;

-- select 'grant '||privilege||' on '||owner||'.'||table_name||' to '||grantee||decode(grantable,'YES', ' with grant option;',';')
-- from dba_tab_privs
-- where grantee like upper('&var_user') 
-- order by owner, table_name
-- /
 
--set termout on feedback 15 verify on pagesize 20 linesize 80 space 1 heading on

prompt

set feedback on     
set verify on
set heading on
