col TRACE_TYPE for a21
col PRIMARY_ID for a30
col QUALIFIER_ID1 for a30
col QUALIFIER_ID2 for a30
col WAITS for a5
col BINDS for a5
col INSTANCE_NAME for a16

col username for a30
col osuser for a30
col terminal for a30
col sql_trace_waits for a5
col sql_trace_binds for a5

select TRACE_TYPE,
	   PRIMARY_ID,
	   QUALIFIER_ID1,
	   QUALIFIER_ID2,
	   WAITS,
	   BINDS,
	   INSTANCE_NAME
from dba_enabled_traces;

select username,
       osuser,
       terminal,
       sql_trace_waits,
	   sql_trace_binds
from v$session
where sql_trace = 'ENABLED'
order by username;
