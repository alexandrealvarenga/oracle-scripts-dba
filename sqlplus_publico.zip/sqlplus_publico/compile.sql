
set linesize 150
set pagesize 1000

accept   var_grantee prompt 'Nome do Chave que ir� Compilar :'
accept   var_owner prompt   'Nome do Owner dos objetos a Compilar:'

CREATE TABLE bdtrace.procedure_privileges (
  procedure_owner   VARCHAR2(30)    NOT NULL,
  grantee       VARCHAR2(30)    NOT NULL,
  privilege     VARCHAR2(10)    NOT NULL
       CHECK (privilege IN ('CREATE', 'ALTER'))
) ;

grant select on bdtrace.procedure_privileges to &var_grantee;

CREATE OR REPLACE TRIGGER bdtrace.restrict_proc_&var_grantee._trg
BEFORE DDL
ON &var_grantee..SCHEMA

/*---------- Definicao de Variaveis ----------*/
DECLARE
  permissao NUMBER(5);

BEGIN
   /*--------------------------------------------------------------------------------
   1) Identifica se esta eh uma chamada para create/alter procedure/function/package/
      package body.
   --------------------------------------------------------------------------------*/
   if (ora_sysevent = 'CREATE' or
       ora_sysevent = 'ALTER') then
      if (ora_dict_obj_type = 'PROCEDURE' or
          ora_dict_obj_type = 'FUNCTION' or
          ora_dict_obj_type = 'PACKAGE' or
          ora_dict_obj_type = 'PACKAGE BODY' or
          ora_dict_obj_type = 'TRIGGER' or
          ora_dict_obj_type = 'TYPE') then

          /*--------------------------------------------------------------------------------
          2) Se for, identifica se o "usuario executante do comando" tem autorizacao para
             criar/alterar procedures neste owner.
          --------------------------------------------------------------------------------*/
          SELECT count(*)
            INTO permissao
            FROM bdtrace.procedure_privileges
            WHERE procedure_owner = ora_dict_obj_owner AND
             grantee = ora_login_user AND
             privilege = ora_sysevent;

          /*--------------------------------------------------------------------------------
          3) Se nao tiver autorizacao: erro por falta de autorizacao.
          --------------------------------------------------------------------------------*/
          if permissao = 0 then
            RAISE_APPLICATION_ERROR(-20101,'Falta autorizacao de '||ora_sysevent||' '||ora_dict_obj_type||' para o usuario '||ora_dict_obj_owner||'.',TRUE);
          end if;
      end if;
   end if;
end;
/

--Grants necess�rios serem atribuidos para utiliza��o do debugger do PL/SQL Developer no oracle 8I
grant create any procedure to &var_grantee;
grant alter  any procedure to &var_grantee;

--Grants necess�rios serem atribuidos para utiliza��o do debugger do PL/SQL Developer 
grant create any TYPE to &var_grantee;
grant alter  any TYPE to &var_grantee;

--Grants necess�rios serem atribuidos para utiliza��o do debugger do PL/SQL Developer no oracle 10G
grant debug connect session to &var_grantee;
grant debug any procedure to &var_grantee;

grant create any trigger to &var_grantee;
grant alter  any trigger to &var_grantee;


insert into bdtrace.procedure_privileges values (upper('&var_owner'), upper('&var_grantee'), 'CREATE')
/
insert into bdtrace.procedure_privileges values (upper('&var_owner'), upper('&var_grantee'), 'ALTER')
/
COMMIT
/

