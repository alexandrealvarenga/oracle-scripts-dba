set echo off
set verify off
set head off feed off

column cmd for a100

accept tab prompt 'Tabela: '
accept owner prompt 'Owner: '
accept prll prompt 'Parallel: '

select 'alter table "'||t.owner||'"."'||t.table_name||'" move parallel '||&prll||' nologging;'||chr(10)||
       'alter table "'||t.owner||'"."'||t.table_name||'" noparallel logging;' cmd
from dba_tables t
where t.table_name like upper('&tab')
and t.owner like upper('&owner');

select 'alter index "'||i.owner||'"."'||i.index_name||'" nologging;'||chr(10)||
       'alter index "'||i.owner||'"."'||i.index_name||'" rebuild parallel '||&prll||';'||chr(10)||
       'alter index "'||i.owner||'"."'||i.index_name||'" logging noparallel;' cmd
from dba_constraints cc,
     dba_indexes i
where i.table_name like upper('&tab')
and i.table_owner like upper('&owner')
and i.index_name = cc.constraint_name (+)
and i.table_owner = cc.owner (+)
and i.index_type <> 'LOB'
order by decode(cc.constraint_type, 'P', 1, 'U', 2, 3) nulls last;

set head on feed on