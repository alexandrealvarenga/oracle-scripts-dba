-- *************************************************
-- Copyright � 2005 by Rampant TechPress
-- This script is free for non-commercial purposes
-- with no warranties.  Use at your own risk.
--
-- To license this script for a commercial purpose,
-- contact info@rampant.cc
-- *************************************************
 
set pages 999
 
set lines 92
 
spool %temp%\keep_syn.tmp
 
with t1
as
(
	select
	   o.owner          owner,
	   o.object_name    object_name,
	   o.subobject_name subobject_name,
	   o.object_type    object_type,
	   count(distinct file# || block#)         num_blocks
	from
	   dba_objects  o,
	   v$bh         bh
	where
	   o.data_object_id  = bh.objd
	and
	   o.owner not in ('SYS','SYSTEM')
	and
	   bh.status != 'free'
	group by
	   o.owner,
	   o.object_name,
	   o.subobject_name,
	   o.object_type
	order by
	   count(distinct file# || block#) desc
) 
select
   'alter '||s.segment_type||' '||t1.owner||'.'||s.segment_name||' storage (buffer_pool keep);' KEEP
from
   t1,
   dba_segments s
where
   s.segment_name = t1.object_name
and
   s.owner = t1.owner
and
   s.segment_type = t1.object_type
and
   nvl(s.partition_name,'-') = nvl(t1.subobject_name,'-')
and
   buffer_pool <> 'KEEP'
and
   object_type in ('TABLE','INDEX')
group by
   s.segment_type,
   t1.owner,
   s.segment_name
having
   (sum(num_blocks)/greatest(sum(blocks), .001))*100 > 80
;
 
 
spool off
