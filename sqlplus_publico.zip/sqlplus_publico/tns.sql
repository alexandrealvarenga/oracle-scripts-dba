set lines 1000 verify off head off
col connect_string for a500

accept inst prompt 'Instancia: '

select '# '||description||chr(10)||decode(type, 'P', 'PRODUCAO_', null)||instance||'.CVRD.BR='||connect_string connect_string
from sarbox_instance
where upper(instance) like upper('&inst')
and SGBD = 'ORACLE'
order by instance;

set head on
