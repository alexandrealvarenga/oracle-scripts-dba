alter session set nls_date_format = 'dd/mm/yyyy hh24:mi:ss';
set linesize 160
col tipo for a7
col obs for a10
col rotina for 99999
col PROC for a35
col anoproc for 9999999
col "TEMP.EXEC." for a12 


SELECT EMPRESA
     , INICIO
     , FINAL
     , SUBSTR((CAST(inicio AS TIMESTAMP)-CAST(final AS TIMESTAMP)),12,2) || ':' ||
       SUBSTR((CAST(inicio AS TIMESTAMP)-CAST(final AS TIMESTAMP)),15,2) || ':' ||
       SUBSTR((CAST(inicio AS TIMESTAMP)-CAST(final AS TIMESTAMP)),18,2) "TEMP.EXEC."
     , ROTINA
     , PROC
     , ANOPROC
     , MESPROC
     , OBS
     , PERIODO
     , TIPO
  FROM IND_ACOMPANHAMENTO_2
 WHERE TIPO = 'FASE 2'
   and empresa like upper('%&emp%')
 ORDER BY EMPRESA, ROTINA, INICIO
;