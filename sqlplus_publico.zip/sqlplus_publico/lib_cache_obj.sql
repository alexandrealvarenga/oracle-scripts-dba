-------------------------------------------------------------------------------------------------
-- Lista sess�es e objetos em espera por eventos de library cache
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (27/03/2017)
-- Ref.: http://allappsdba.blogspot.com.br/2012/04/to-check-library-cache-lock-contention.html
-------------------------------------------------------------------------------------------------

col sid for 999999
col lock_type for a56
col object_name for a65
col mode_held for a40
col mode_requested for a40
col lock_addr for a40
select /*+
            qb_name(main)

            leading(@SEL$DF20A908 VW_SQ_1@SEL$0AB56D8D DLI@MAIN)
            use_hash(@SEL$DF20A908 VW_SQ_1@SEL$0AB56D8D)
            no_swap_join_inputs(@SEL$DF20A908 VW_SQ_1@SEL$0AB56D8D)
            no_swap_join_inputs(@SEL$DF20A908 DLI@MAIN)

            cardinality(@SEL$71D7A081 S@SEL$4 1000)
            cardinality(dli.V$lock.S 1000)
            cardinality(dli.V$lock.R 40000)

            leading(@SEL$40AA690C S@SEL$31 E@SEL$31 LK@SEL$29 OB@SEL$29)
            use_hash(@SEL$40AA690C LK@SEL$29)
            use_hash(@SEL$40AA690C OB@SEL$29)
            use_nl(@SEL$40AA690C E@SEL$31)

            unnest(@subq)

            leading(@SEL$28E4548A X$KSUPRLAT@SEL$23 X$KSUPR@SEL$19 S@SEL$21 E@SEL$21)
            use_nl(@SEL$28E4548A X$KSUPR@SEL$19)
            use_hash(@SEL$28E4548A S@SEL$21)
            use_nl(@SEL$28E4548A E@SEL$21)

            leading(@SEL$1F9EFFC1 X$KSUPR@SEL$28 S@SEL$26 W@SEL$26 E@SEL$26)
            use_hash(@SEL$1F9EFFC1 S@SEL$26)
            use_nl(@SEL$1F9EFFC1 W@SEL$26)
            use_nl(@SEL$1F9EFFC1 E@SEL$26)
       */
       dli.session_id waiter,
       dli.lock_type type,
       dli.lock_id1 object_name,
       dli.mode_held,
       dli.mode_requested,
       dli.lock_id2 lock_addr
from dba_lock_internal dli
where dli.mode_requested <> 'None'
  and dli.mode_requested <> mode_held
  and exists (
        select /*+ UNNEST */
               null
        from v$session_wait a,
             v$session b
        where a.sid = b.sid
          and a.wait_time = 0
          and a.event like 'library cache%'
          and dli.session_id = a.sid
    )
/