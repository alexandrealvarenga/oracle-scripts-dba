set verify off
set heading off
set feedback off

accept owner prompt 'Owner: '
accept   dir prompt 'Diretorio de spool: '

set term off

spool "&dir\dump_ed_drop_create_&owner..sql"
prompt spool "&dir\dump_ed_drop_create_&owner..log"

prompt drop user &owner cascade;
select 'create user "'||username||'" identified by values '''||password||''''||' default tablespace '||DEFAULT_TABLESPACE||' temporary tablespace '||temporary_tablespace || ';'
from dba_users
where username = upper('&owner')
/

select 'grant '||granted_role||' to "'||grantee||'";'
from dba_role_privs
where grantee = upper('&owner')
/

select 'grant '||privilege||' to "'||grantee||'";'
from dba_sys_privs  
where grantee = upper('&owner')
/

select 'grant '||privilege||' on '||owner||'.'||table_name||' to '||grantee||';'
from dba_tab_privs
where grantee = upper('&owner')
/

prompt spool off
spool off


spool "&dir\dump_ed_grants_&owner..sql"
prompt spool "&dir\dump_ed_grants_&owner..log"

SELECT 'GRANT '||privilege||' on &owner..'||table_name||' to '||grantee||';' 
FROM dba_tab_privs 
WHERE (owner = upper('&owner')) and (grantee NOT LIKE 'ACB%')
/

SELECT 'CREATE PUBLIC SYNONYM '||table_name||' for '||table_owner||'.'||table_name||';' 
FROM dba_synonyms 
WHERE (table_owner = upper('&owner')) and (owner ='PUBLIC')
/

SELECT 'CREATE SYNONYM '||owner||'.'||table_name||' for '||table_owner||'.'||table_name||';' 
FROM dba_synonyms 
WHERE (table_owner = upper('&owner')) and (owner <>'PUBLIC')
/

prompt spool off
spool off

set term on

undef dir
undef owner

set feedback on
set heading on
set verify on
