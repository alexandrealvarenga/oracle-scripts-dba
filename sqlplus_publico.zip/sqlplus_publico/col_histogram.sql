select
    endpoint_value,
    endpoint_number,
    endpoint_number - nvl(prev_number,0) frequency
from    (
    select
        endpoint_value,
        endpoint_number,
        lag(endpoint_number,1) over(
            order by endpoint_number
        ) prev_number
    from
        dba_tab_histograms
    where
        owner = upper('&1')
    and table_name = upper('&2')
    and column_name = upper('&3')
    )
order by
    endpoint_value
;

undef 1 2 3
