/* sql_report_html.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Gera um active report em html do real-time sql monitoring
 * Utilizacao: @sql_report_html
 *
 * Ref.: https://oracle-base.com/articles/11g/real-time-sql-monitoring-11gr1
 */

SET LONG 1000000
SET LONGCHUNKSIZE 1000000
SET LINESIZE 1000
SET PAGESIZE 0
SET TRIM ON
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET TERM ON
SET VERIFY OFF

-- Bug 21089435 - Enterprise Manager "Sql Monitor" shows "ORA-31011: XML parsing failed" error (Doc ID 21089435.8)
alter session set events '31156 trace name context forever, level 0x400';

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

accept sqlid prompt 'SQL ID: '
accept p_dest default '&sqlid._&wdt..html' prompt 'Caminho do arquivo (default: &sqlid._&wdt..html): '

SET TERM OFF

SPOOL &p_dest
SELECT DBMS_SQLTUNE.report_sql_detail(
  sql_id       => '&sqlid',
  type         => 'ACTIVE',
  report_level => 'ALL') AS report
FROM dual;
SPOOL OFF

alter session set events '31156 trace name context off';

SET TERM ON
