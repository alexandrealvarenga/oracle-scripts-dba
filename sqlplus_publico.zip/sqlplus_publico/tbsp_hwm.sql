set serveroutput on echo off feed off verify off

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

accept m_tablespace char prompt   'Tablespace        : '

prompt %temp%\tbsp_hwm_&m_tablespace._&wdt..txt
spool %temp%\tbsp_hwm_&m_tablespace._&wdt..txt

select
	file_id,
	block_id,
	block_id + blocks - 1	end_block,
	owner,
	segment_name,
	partition_name,
	segment_type
from
	dba_extents
where
	tablespace_name = upper('&m_tablespace')
union all
select
	file_id,
	block_id,
	block_id + blocks - 1	end_block,
	'free'			owner,
	'free'			segment_name,
	null			partition_name,
	null			segment_type
from
	dba_free_space
where
	tablespace_name = upper('&m_tablespace')
order by
	1,2
/

spool off

prompt
prompt ed %temp%\tbsp_hwm_&m_tablespace._&wdt..txt
prompt
