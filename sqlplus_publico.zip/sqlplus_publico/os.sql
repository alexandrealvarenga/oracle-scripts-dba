@c producao_orapvt005

set verify off

col num_os for a27
col nom_funcionario for a35
col cod_centro_custo for a12
col cod_tarefa_pa for a5
col nom_area_accenture for a30

prompt "AS OS's MAIS RECENTES ESTAO LISTADAS NO INICIO"
prompt Entre com pelo menos uma das informacoes abaixo (USAR %):

accept nome prompt 'Projeto (Nome ou Codigo): '
accept cc   prompt 'Centro de Custo.........: '
accept tar  prompt 'Tarefa..................: '

select os.num_os, f.nom_funcionario, os.dat_solicitacao, os.cod_centro_custo, os.cod_tarefa_pa, os.dsc_objetivo_os
from pcansos.ordem_servico os, pcansexp.funcionario f
where (upper(os.NUM_OS) LIKE '%ABD%' 
	or upper(os.NUM_OS) LIKE upper('OABPRJ%')
	or upper(os.NUM_OS) LIKE upper('OABINT%'))
      AND (upper(os.NUM_OS) LIKE upper('&nome') 
      	or upper(os.DSC_OBJETIVO_OS) LIKE upper('&nome')
      	or upper(os.DSC_OS) LIKE upper('&nome')
      	or upper(os.cod_centro_custo) LIKE upper('&cc')
      	or upper(os.cod_tarefa_pa) LIKE upper('&tar'))
      AND (os.cod_seq_func_executor = f.cod_seq_funcionario)
ORDER by os.dat_solicitacao DESC
/

undef cc
undef tar
undef nome
undef dsc

set verify on

