------------------------------------------------------------------------
-- Criacao de tarefa do SQL Tuning Advisor para um determinado
-- SQL Tuning Set
--
-- Criado por: Lucas Lellis - lucas.lellis@dxc.com (05/02/2020)
------------------------------------------------------------------------

set verify off feed off echo off lines 200 serveroutput on size 1000000

accept sts_name prompt 'SQL Tuning Set: '
accept time_lim prompt 'Time limit (m): '

col epoch_time new_val w_epoch_time noprint

-- Ref: http://shafiqissani.wordpress.com/2010/09/30/how-to-get-the-current-epoch-time-unix-timestamp/
SELECT trim(trunc((SYSDATE - TO_DATE('01-01-1970 00:00:00', 'DD-MM-YYYY HH24:MI:SS')) * 24 * 60 * 60)) epoch_time
FROM DUAL;

-- Ref: http://www.oracle-base.com/articles/10g/automatic-sql-tuning-10g.php
DECLARE  
    l_sql_tune_task_id  VARCHAR2(200);
    l_sts_name varchar2(200) := '&sts_name';
    l_time_lim varchar2(200) := '&time_lim';
    l_task_name varchar2(200);
    l_job_name varchar2(200);
BEGIN
    if (l_sts_name = '' or l_sts_name is null) or
       (l_time_lim = '' or l_time_lim is null) then
       dbms_output.put_line('Parametro(s) nao informado(s)');
    else
        l_task_name := l_sts_name;
        l_job_name := 'job_'||l_sts_name;
        
        l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (                          
            sqlset_name => l_sts_name,                          
            scope       => DBMS_SQLTUNE.scope_comprehensive,                          
            time_limit  => l_time_lim * 60,                          
            task_name   => l_task_name,
            rank1       => 'ELAPSED_TIME',                      
            description => 'Tuning task for STS '||l_sts_name||'.');
    

        dbms_scheduler.create_job (
            job_name            => l_job_name,
            job_type            => 'STORED_PROCEDURE',
            job_action          =>  'sys.dbms_sqltune.execute_tuning_task',
            number_of_arguments => 1,
            start_date          => current_date,
            enabled             => false,
            auto_drop           => true,
            comments            => 'Tuning advisor do SQL Tuning Set '||l_sts_name);
        
        dbms_scheduler.set_job_argument_value(
            job_name                => l_job_name,
            argument_position       => 1,
            argument_value          => l_task_name);
            
        dbms_scheduler.enable(l_job_name);
        
        dbms_output.put_line('## Task submetida com sucesso ##'||chr(10));
        
        dbms_output.put_line(
            '-- Verificar status da task do advisor --'||chr(10)||
            'column error_message for a60 word_wrapped');
        dbms_output.put_line(
            'select execution_start, execution_end, status, error_message'||chr(10)||
            'from user_advisor_log');
        dbms_output.put_line(
            'where task_name='''||l_task_name||''';'||chr(10)||chr(10));
        dbms_output.put_line(
            '-- Cancelar status da task do advisor --'||chr(10)||
            '-- exec dbms_sqltune.drop_tuning_task('''||l_task_name||''')'||chr(10)||
            '-- exec dbms_scheduler.drop_job('''||l_job_name||''',true)'||chr(10));
            
        dbms_output.put_line(
            '-- Executar apos a conclusao da task do advisor --'||chr(10)||
            'SET LONG 100000'||chr(10)||
            'SET PAGESIZE 50000'||chr(10)||
            'SET LINESIZE 500'||chr(10)||
            'SET HEAD off'||chr(10)||
            'SET FEED off'||chr(10)||
            'COL recommendations for a500'||chr(10)||
            'COL script for a500');
        dbms_output.put_line(            
            'SELECT DBMS_SQLTUNE.report_tuning_task('''||l_task_name||''') AS recommendations FROM dual;');
        dbms_output.put_line(  
            'SELECT DBMS_SQLTUNE.script_tuning_task('''||l_task_name||''') AS script FROM dual;'||chr(10)||chr(10));
    end if;
END;
/

undef sqlid time_lim
set verify on feed on
