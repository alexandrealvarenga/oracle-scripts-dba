define p_sqlid = &sqlid
define p_plan_hash_value = &plan_hash_value

select T.SQL_TEXT
from SYS.DBA_HIST_SQLTEXT t
where T.DBID = (select dbid from V$DATABASE)
and T.SQL_ID = '&p_sqlid';

select *
from table(dbms_xplan.display_awr(
        '&p_sqlid',
        &p_plan_hash_value,
        (select dbid from v$database),
        'ALL'
    )
);
