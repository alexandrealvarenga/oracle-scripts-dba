/* topnsql_awr_fmds.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@dxc.com)
 * Descricao:  Top N SQL por elapsed time extraido do AWR agrupado por force_matching_signature em vez de SQL ID
 * Utilizacao: @topnsql_awr_fms
 */

store set %temp%\sqlenv replace

set lines 280 pages 9999 trimspool on
col snap_date for a20

select snap.snap_id,
       to_char(snap.end_interval_time, 'DD/MM/YYYY HH24:MI') snap_date
from dba_hist_snapshot snap,
     v$database db,
     v$instance inst
where db.dbid = snap.dbid
and snap.instance_number = inst.instance_number
and snap.end_interval_time > trunc(sysdate) - &awr_days
order by snap.snap_id;

col db_time for 999G999G999G990D00 heading "DB Time (minutes)"
col db_time new_val l_dbtime

SELECT Round(NVL((e.value - s.value),-1)/60/1000000,2) db_time
FROM DBA_HIST_SYS_TIME_MODEL s,
DBA_HIST_SYS_TIME_MODEL e
WHERE s.snap_id = &&min_snap_id AND
e.snap_id = &&max_snap_id anD
e.dbid = s.dbid AND
e.instance_number = s.instance_number AND
s.stat_name = 'DB time' AND
e.stat_id = s.stat_id
and s.instance_number = (select instance_number from v$instance);

col force_matching_signature for 99999999999999999999
col module for a30 wrapped
col sql_text for a80 word_wrapped

col "Executions" for 999G999G999G990
col "Elapsed Time(s) - Total" for 999G999G999G990D00
col "Elapsed Time(s) - Avg" for 999G999G999G990D00
col "% DB Time" for 999G990D00
col "Buffer Gets" for 999G999G999G990
col "Physical Reads" for 999G999G999G990
col "Rows Processed - Avg" for 999G999G999G990D00

compute sum label 'Sum - %DB Time' of "% DB Time" on report
break on report

select qry.*
from (
    select *
    from (
        select st.force_matching_signature,
            st.module,
            sum(st.executions_delta) "Executions",
            sum(st.elapsed_time_delta)/1000000/decode(sum(st.executions_delta), 0, 1, sum(st.executions_delta)) "Elapsed Time(s) - Avg",
            sum(st.elapsed_time_delta)/1000000 "Elapsed Time(s) - Total",
            (sum(st.elapsed_time_delta)/1000000) * 100 / (&l_dbtime * 60) "% DB Time",
            sum(st.buffer_gets_delta) "Buffer Gets",
            sum(st.disk_reads_delta) "Physical Reads",
            sum(st.rows_processed_delta)/decode(sum(st.executions_delta), 0, 1, sum(st.executions_delta)) "Rows Processed - Avg"
        from dba_hist_sqlstat st
        where (st.snap_id > &&min_snap_id and st.snap_id <= &&max_snap_id)
        and st.dbid = (select dbid from v$database)
        and st.instance_number = (select instance_number from v$instance)
        and st.force_matching_signature <> 0
        group by st.force_matching_signature, st.module
        order by "Elapsed Time(s) - Total" desc
    )
    where rownum <= &topn
) qry
where rownum <= &topn;

undef min_snap_id
undef max_snap_id
undef sql_text
undef awr_days

clear breaks
clear computes

@%temp%\sqlenv
prompt