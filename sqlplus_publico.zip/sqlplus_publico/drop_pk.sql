set verify off echo off

accept tab_name prompt 'Nome da tabela: '

select 'alter table '||owner||'.'||table_name||' drop constraint '||constraint_name||' ;'
from dba_constraints
where r_constraint_name = substr('&tab_name', 1, 7)||'I'
and constraint_type = 'R';



