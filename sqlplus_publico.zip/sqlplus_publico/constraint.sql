--
-- Geovani Mazioli da Silva 
-- verifica informa��es de constraint
-- Data: 17/07/2008
--

set verify off
set pagesize 50000

accept cons prompt 'Constraint: '

SELECT	owner, table_name, constraint_name, r_owner, R_CONSTRAINT_NAME, status
FROM 	dba_constraints
WHERE 	constraint_name LIKE upper ('&cons')
/

SELECT 'alter table '||owner||'.'||table_name||' able constraint &cons;'
FROM 	dba_constraints
WHERE 	constraint_name LIKE upper ('&cons')
/


undef link

set verify on
