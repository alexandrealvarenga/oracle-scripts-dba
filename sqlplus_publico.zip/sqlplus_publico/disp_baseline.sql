-------------------------------------------------------------------------------
--       Nome : disp_baseline.sql
--      Autor : Lucas Pimentel Lellis (lucas.lellis@cgi.com)
-- Finalidade : Executar o display de um SQL Plan Baseline
--
-- Parametros : 1 - Plan Name (do Baseline)
-------------------------------------------------------------------------------

SET LONG 999999999
SELECT *
FROM   TABLE(DBMS_XPLAN.display_sql_plan_baseline(plan_name=>'&1'));
