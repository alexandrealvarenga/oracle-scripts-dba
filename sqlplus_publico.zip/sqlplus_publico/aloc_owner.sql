set verify off
set feedback off

col segment_type hea "Segmento" for a15

prompt
accept owner prompt 'Owner: '

SELECT segment_type, trunc(sum(bytes)/1048576,2) as "Alocado (MB)"
FROM   dba_segments
WHERE  owner = upper ('&owner')
GROUP BY owner, segment_type;

set heading off
SELECT 'TOTAL..............: ' || trunc(sum(bytes)/1048576,2)
FROM dba_segments
WHERE  owner = upper ('&owner');

prompt 

undef &owner

set heading on
set feedback on
set verify on
