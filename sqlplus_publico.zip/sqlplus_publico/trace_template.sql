col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

col pid new_val wpid noprint
select p.spid pid
from v$session s
join v$process p on p.addr = s.paddr
where s.sid = sys_context('userenv','sid'); 

col fn new_val wfn noprint
select sys_context('userenv','instance_name')||'_ora_&wpid._LUCAS_&wdt' fn
from dual;

col cmd new_val wcmd noprint
select 'scp oracle@'||sys_context('userenv','server_host')||':'||(select value from v$parameter where name = 'user_dump_dest')||'/&wfn..trc .' cmd
from dual;

alter session set current_schema=--USUARIO_APLICACAO--;
alter session set tracefile_identifier=C0135418_&wdt;
alter session set events '10046 trace name context forever, level 12';
set autotrace on

/*
 * INSERIR QUERY
 *
 */

disc

prompt
prompt host &wcmd
prompt host orasrp &wfn..trc &wfn..html
prompt host del &wfn..trc
prompt host &wfn..html
prompt
