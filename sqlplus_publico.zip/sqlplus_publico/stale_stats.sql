set verify off feed on serveroutput on
accept v_owner prompt 'Owner: '

declare 
    mystaleobj dbms_stats.ObjectTab; 
begin 
    DBMS_STATS.GATHER_SCHEMA_STATS(ownname=>upper('&v_owner'), objlist=>mystaleobj, options=>'LIST AUTO'); 
    for i in 1 .. mystaleobj.count 
    loop 
        dbms_output.put_line('exec dbms_stats.gather_table_stats(ownname => '''||upper('&v_owner')||''', tabname => '''||mystaleobj(i).objname||''', estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE, degree=> 6,    method_opt=>''FOR ALL COLUMNS SIZE SKEWONLY'', no_invalidate => false);');
    end loop; 
end; 
/ 
