/* Shows which objects are associated with opened transactions */

col sid for 9999999999
col object_id for 9999999999
col tran_addr for a20
col object_name for a30
col current_sql for a100 WORD_WRAPPED
break on sid on tran_addr on tran_start_time on current_sql skip page
SELECT
    s.sid,
    t.addr tran_addr,
    to_char(t.start_date, 'DD/MM/YYYY hh24:mi:ss') tran_start_time,
    q.SQL_TEXT current_sql,
    p.object_id,
    D.OBJECT_NAME
FROM
    v$transaction t,
    v$session s,
    V$locked_object p,
    dba_objects d,
    v$sqlarea q
WHERE
    t.ses_addr = s.saddr
    AND p.session_id = s.sid
    AND d.object_id = p.object_id
    and s.SQL_ID = q.SQL_ID
order by s.sid, t.addr, d.object_name
/
clear COLUMNS
clear BREAKS
