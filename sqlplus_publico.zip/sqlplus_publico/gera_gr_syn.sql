store set %temp%\sqlenv replace

set echo off
set heading off
set trimspool on
set feedback off
set verify off

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;


accept ownr prompt 'Owner: '
accept sf_role prompt 'Sufixo da role: '
accept ownr_syn prompt 'Owner do sinonimo: '
accept ndias prompt 'Dias (0 = hoje): '
accept dir prompt 'Diretorio de spool: '

spool "&dir\grants_sinonimos_&wdt..sql"
prompt spool "&dir\grants_sinonimos_&wdt..log"
prompt
prompt set echo on

select 'grant delete, insert, update on &ownr'||'.'||t.object_name||' to a&sf_role;'
from dba_objects t
where t.object_type = 'TABLE'
and t.owner=upper('&ownr')
and t.object_name not in (select table_name from dba_tab_privs where owner = '&ownr' and grantee=('A'||upper('&sf_role')))
and t.created >= (trunc(sysdate) - &ndias)
order by object_name;

prompt 
 
 
select 'grant select on &ownr'||'.'||t.object_name||' to c&sf_role;'
from dba_objects t
where t.object_type = 'TABLE'
and t.owner=upper('&ownr')
and t.object_name not in (select table_name from dba_tab_privs where owner = '&ownr' and grantee=('C'||upper('&sf_role')))
and t.created >= (trunc(sysdate) - &ndias)
order by object_name;


prompt

select 'grant select on &ownr'||'.'||t.object_name||' to a&sf_role;'
from dba_objects t
where t.object_type = 'SEQUENCE'
and t.owner=upper('&ownr')
and t.object_name not in (select table_name from dba_tab_privs where owner = '&ownr' and grantee=('A'||upper('&sf_role')))
and t.created >= (trunc(sysdate) - &ndias)
order by object_name;


prompt


select 'grant execute on &ownr'||'.'||o.object_name||' to e&sf_role;'
from dba_objects o
where o.owner=upper('&ownr')
and o.object_type in ('PROCEDURE','FUNCTION','PACKAGE')
and o.object_name not in (select table_name from dba_tab_privs where owner = upper('&ownr') and grantee=('E'||upper('&sf_role')))
and o.created >= (trunc(sysdate) - &ndias)
order by object_name;

prompt


select 
    CASE 
        WHEN upper('&ownr_syn') is null
            THEN 
                'create public synonym '||t.object_name||' for &ownr'||'.'||t.object_name||';'
            ELSE 
                'create synonym &ownr_syn'||'.'||t.object_name||' for &ownr'||'.'||t.object_name||';'
    END
from dba_objects t
where owner = upper('&ownr') 
    and t.object_name not in 
        (select synonym_name from dba_synonyms where table_owner=upper('&ownr') and (owner=upper('&ownr_syn') or owner='PUBLIC'))
    and t.created >= (trunc(sysdate) - &ndias)
    and t.object_type in ('TABLE','FUNCTION','PROCEDURE','PACKAGE','SEQUENCE')
order by object_type, object_name;

prompt spool off
spool off

undef ownr pro
undef sf_role 
undef ownr_syn
undef ndias

@%temp%\sqlenv.sql

prompt @"&dir\grants_sinonimos_&wdt..sql"
