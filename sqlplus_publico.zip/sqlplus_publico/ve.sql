col mb_used for 999G999G999D99
col mb_free for 999G999G999D99
col object_name for a30
undefine table_name
set lines 180 verify off pages 9999
TTITLE ' ESTIMATIVA DE ESPA�O PARA LIVEREORG (adi��o de 20% no tamanho utilizado). COLUNA MB_USED = tamanho real '

column dummy noprint;
break on dummy;
compute sum of mb_used on dummy;

select null dummy, object_name,type, mb_used, tablespace_name, mb_free,
CASE
  WHEN needed < 0 THEN '*** Nao ha espaco disponivel ***'
  ELSE 'OK'
 END observacao
from
(select ds.segment_name object_name, ds.segment_type type, ds.mb_used mb_used, ds.tablespace_name tablespace_name,df.mb_free mb_free, mb_free - trunc(mb_used * 1.2) needed
from (select segment_name, segment_type,tablespace_name, sum(bytes)/1024/1024 mb_used
      from dba_segments
      where segment_name = upper('&&table_name')
      group by segment_name,segment_type,tablespace_name) ds,
     (select tablespace_name, round(sum(bytes)/1024/1024) mb_free
      from dba_free_space
      where tablespace_name = nvl((select tablespace_name from dba_tables where table_name = upper('&&table_name')), (select distinct tablespace_name from dba_tab_partitions where table_name = upper('&&table_name')))
      group by tablespace_name) df
where df.tablespace_name = ds.tablespace_name)
union
select null dummy, object_name, type, mb_used, tablespace_name, mb_free,
CASE
  WHEN needed < 0 THEN '*** Nao ha espaco disponivel ***'
  ELSE 'OK'
 END observacao
from
(select ds.index_name object_name, ds.segment_type type, ds.mb_used mb_used,ds.tablespace_name tablespace_name,df.mb_free mb_free, mb_free - trunc(mb_used * 1.2) needed
from (select segment_name index_name, segment_type, sum(bytes)/1024/1024 mb_used, tablespace_name
      from dba_segments
      where segment_name in (select index_name from dba_indexes where table_name = upper('&&table_name'))
      group by segment_name, segment_type, tablespace_name) ds,
      (select tablespace_name, round(sum(bytes)/1024/1024) mb_free
      from dba_free_space
      where tablespace_name in (select tablespace_name from dba_indexes where table_name = upper('&&table_name'))
      group by tablespace_name) df
where df.tablespace_name = ds.tablespace_name)
/
undef table_name
ttitle off;

clear breaks computes