-- Estat�sticas de um SQL no AWR
-- Lucas Pimentel Lellis (lucas.lellis@cgi.com) - 19/02/2015
-- Baseado em: http://oracleprof.blogspot.com.br/2011/06/how-to-color-mark-sql-for-awr-snapshots.html

col exetime_s format 99999999990.00
col CPU_TIME_DELTA_S format 99999999990.00
col ELAPSED_TIME_DELTA_S format 99999999990.00
col begin_interval_time format a30 heading 'Begin Interval Time'
col plan_hash_value heading 'Plan Hash Value'
col exetime_s heading 'Avg Exec Time (s)'
col EXECUTIONS_DELTA heading 'Executions Delta'
col CPU_TIME_DELTA_S heading 'CPU Time Delta (s)'
col ELAPSED_TIME_DELTA_S heading 'Elapsed Time Delta (s)'
col DISK_READS_DELTA heading 'Disk Reads Delta'

select begin_interval_time, 
       PLAN_HASH_VALUE, 
       (ELAPSED_TIME_DELTA/EXECUTIONS_DELTA)/1e6 exetime_s, 
       EXECUTIONS_DELTA, 
       CPU_TIME_DELTA/1e6 CPU_TIME_DELTA_S, 
       ELAPSED_TIME_DELTA/1e6 ELAPSED_TIME_DELTA_S, 
       DISK_READS_DELTA
from dba_hist_sqlstat ss, dba_hist_snapshot s 
where sql_id = '&SQL_ID' 
and s.begin_interval_time >= trunc(sysdate) - &num_days
and s.dbid = (select dbid from v$database)
and s.instance_number = sys_context('USERENV', 'INSTANCE')
and s.dbid = ss.dbid
and s.instance_number = ss.instance_number
and s.snap_id = ss.snap_id
order by s.snap_id, sql_id;

undef sql_id num_days
clear columns
