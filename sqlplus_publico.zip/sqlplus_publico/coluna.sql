--
-- Geovani Mazioli da Silva 
-- coment�rio de colunas de um owner/tabela.
-- Data: 17/07/2008
--

set verify off

COL	owner	FOR	A15
COL	table_name	FOR	A20
COL	column_name	FOR	A20
COL	comments	FOR	A100

accept own prompt 'Usuario: '
accept tab prompt 'Tabela.: '
accept col prompt 'Coluna.: '

SELECT *
FROM dba_col_comments
WHERE owner LIKE upper ('%&own%') AND
	table_name LIKE upper ('%&tab%') AND
	column_name LIKE upper ('%&col%');

undef &own
undef &tab
undef &col

set verify on

clear col
