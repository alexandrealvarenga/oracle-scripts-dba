------------------------------------------------------------------------
-- Gera comandos de trace para uma sess�o
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (05/04/2017)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

-------------------------
-- VARIAVEIS OBRIGATORIAS
define DESTDIR=%TEMP%
define TRACE_IDENT=LUCAS_
-------------------------

set feed off newpage none serveroutput on size 1000000 linesize 32767 trimspool on verify off echo off head off pages 9999
col sid new_val sid noprint
col dt new_val dt noprint
col inst new_val inst noprint

select lower(SYS_CONTEXT('USERENV','INSTANCE_NAME')) inst, SYS_CONTEXT('USERENV','SID') sid, to_char(sysdate, 'YYYYMMDDHH24MISS') dt from dual;

accept p_sid default &&sid number prompt 'SID (ENTER para a propria sessao): '

variable l_sid number
exec :l_sid := &p_sid

-- necessario para eliminar os espacos a esquerda
define p_sid_arq = &&p_sid

prompt

spool &&DESTDIR.\trace_cmd_&&inst._&&p_sid_arq._&&dt..sql
declare
    l_serial    v$session.serial#%type;
    l_pid       v$process.spid%type;
    l_traceid   varchar2(30) := '&&TRACE_IDENT'||'&&dt';
    l_cam_trace v$parameter.value%type;
begin
    select ses.serial#, prc.spid
      into l_serial, l_pid
    from v$session ses,
         v$process prc
    where ses.paddr = prc.addr
      and ses.sid = :l_sid;

    --
    -- Evento 10046
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Trace 10046 - SQL Trace - Propria sessao'                                                                                   || chr(10)||chr(10)||
        q'[alter session set tracefile_identifier='10046_]'||l_traceid||''';'                                                           || chr(10)||
        q'[alter session set max_dump_file_size='unlimited';]'                                                                          || chr(10)||
        q'[alter session set events '10046 trace name context forever, level 12';]'                                                     || chr(10)||
        q'[alter session set events '10046 trace name context off';]'                                                                   || chr(10)||
        q'[disc]'                                                                                                                       || chr(10)||chr(10)
    );

    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Trace 10046 - SQL Trace'                                                                                                    || chr(10)||chr(10)||
        q'[oradebug setospid ]'||l_pid                                                                                                  || chr(10)||
        q'[oradebug settracefileid 10046_]'||l_traceid                                                                                  || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug event 10046 trace name context forever, level 12]'                                                                  || chr(10)||
        q'[oradebug event 10046 trace name context off]'                                                                                || chr(10)||
        q'[oradebug tracefile_name]'                                                                                                    || chr(10)||chr(10)||

        '-- OU --'                                                                                                                      || chr(10)||chr(10)||

        'exec dbms_monitor.session_trace_enable(session_id=>'||:l_sid||', serial_num=>'||l_serial||', waits=> true, binds => true);'    || chr(10)||
        'exec dbms_monitor.session_trace_disable(session_id=>'||:l_sid||', serial_num=>'||l_serial||');'                                || chr(10)||chr(10)||

        '-- OU --'                                                                                                                      || chr(10)||chr(10)||

        'exec sys.dbms_system.set_ev(si=>'||:l_sid||', se=>'||l_serial||', ev=> 10046, le=>12, nm=>'''');'                              || chr(10)||
        'exec sys.dbms_system.set_ev(si=>'||:l_sid||', se=>'||l_serial||', ev=> 10046, le=>0, nm=>'''');'                               || chr(10)||chr(10)
    );

    --
    -- Evento 10053
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Trace 10053 - Otimizador - Propria sessao'                                                                                  || chr(10)||chr(10)||
        q'[alter session set tracefile_identifier='10053_]'||l_traceid||''';'                                                           || chr(10)||
        q'[alter session set max_dump_file_size='unlimited';]'                                                                          || chr(10)||
        q'[alter session set events '10053 trace name context forever, level 1';]'                                                      || chr(10)||
        q'[alter session set events '10053 trace name context off';]'                                                                   || chr(10)||chr(10)
    );

    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Trace 10053 - Otimizador'                                                                                                   || chr(10)||chr(10)||
        q'[oradebug setospid ]'||l_pid                                                                                                  || chr(10)||
        q'[oradebug settracefileid 10053_]'||l_traceid                                                                                  || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug event 10053 trace name context forever, level 1]'                                                                   || chr(10)||
        q'[oradebug event 10053 trace name context off]'                                                                                || chr(10)||
        q'[oradebug tracefile_name]'                                                                                                    || chr(10)||chr(10)||

        '-- OU --'                                                                                                                      || chr(10)||chr(10)||

        'exec sys.dbms_system.set_ev(si=>'||:l_sid||', se=>'||l_serial||', ev=> 10053, le=>1, nm=>'''');'                               || chr(10)||
        'exec sys.dbms_system.set_ev(si=>'||:l_sid||', se=>'||l_serial||', ev=> 10053, le=>0, nm=>'''');'                               || chr(10)||chr(10)
    );

    --
    -- Hanganalyze - Single-Instance
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Hanganalyze - Single-Instance'                                                                                              || chr(10)||chr(10)||
        q'[alter session set tracefile_identifier='hanganalyze_]'||l_traceid||''';'                                                     || chr(10)||
        q'[alter session set max_dump_file_size='unlimited';]'                                                                          || chr(10)||
        q'[alter session set events 'immediate trace name hanganalyze level 3';]'                                                       || chr(10)||chr(10)||

        '-- OU --'                                                                                                                      || chr(10)||chr(10)||

        q'[oradebug setmypid]'                                                                                                          || chr(10)||
        q'[oradebug settracefileid hanganalyze_]'||l_traceid                                                                            || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug hanganalyze 3]'                                                                                                     || chr(10)||chr(10)
    );

    --
    -- Hanganalyze - RAC >=11g
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Hanganalyze - RAC >=11g'                                                                                                    || chr(10)||chr(10)||
        q'[oradebug setorapname reco]'                                                                                                  || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug -g all hanganalyze 3]'                                                                                              || chr(10)||chr(10)
    );

    --
    -- Hanganalyze - RAC 10g
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Hanganalyze - RAC 10g'                                                                                                      || chr(10)||chr(10)||
        q'[oradebug setmypid]'                                                                                                          || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug -g all hanganalyze 3]'                                                                                              || chr(10)||chr(10)
    );

    --
    -- Hanganalyze - Conexao PRELIM
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Hanganalyze - PRELIM'                                                                                                       || chr(10)||chr(10)||
        q'[oradebug setospid -- USAR PID de PROCESSO FG EXISTENTE --]'                                                                  || chr(10)||
        q'[oradebug settracefileid hanganalyze_]'||l_traceid                                                                            || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug dump hanganalyze 3]'                                                                                                || chr(10)||
        q'[oradebug tracefile_name]'                                                                                                    || chr(10)||chr(10)
    );

    --
    -- Systemstate - Single-Instance
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Systemstate - Single-Instance'                                                                                              || chr(10)||chr(10)||
        q'[alter session set tracefile_identifier='systemstate_]'||l_traceid||''';'                                                     || chr(10)||
        q'[alter session set max_dump_file_size='unlimited';]'                                                                          || chr(10)||
        q'[alter session set events 'immediate trace name systemstate level 266';]'                                                     || chr(10)||chr(10)||

        '-- OU --'                                                                                                                      || chr(10)||chr(10)||

        q'[oradebug setmypid]'                                                                                                          || chr(10)||
        q'[oradebug settracefileid systemstate_]'||l_traceid                                                                            || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug dump systemstate 266]'                                                                                              || chr(10)||
        q'[oradebug tracefile_name]'                                                                                                    || chr(10)||chr(10)
    );

    --
    -- Systemstate - RAC >=11.2.0.3
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Systemstate - RAC >=11.2.0.3'                                                                                               || chr(10)||chr(10)||
        q'[oradebug setorapname reco]'                                                                                                  || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug -g all dump systemstate 266]'                                                                                       || chr(10)||
        q'[-- Procurar pelo trace do processo diag]'                                                                                    || chr(10)||chr(10)
    );

    --
    -- Systemstate - RAC <=11.2.0.2
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Systemstate - RAC <=11.2.0.2'                                                                                               || chr(10)||chr(10)||
        q'[oradebug setmypid]'                                                                                                          || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug -g all dump systemstate 258]'                                                                                       || chr(10)||
        q'[-- Procurar pelo trace do processo diag]'                                                                                    || chr(10)||chr(10)
    );

    --
    -- Systemstate - Conexao PRELIM
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Systemstate - PRELIM'                                                                                                       || chr(10)||chr(10)||
        q'[oradebug setospid -- USAR PID DE PROCESSO FG EXISTENTE --]'                                                                  || chr(10)||
        q'[oradebug settracefileid systemstate_]'||l_traceid                                                                            || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug dump systemstate 266]'                                                                                              || chr(10)||
        q'[oradebug tracefile_name]'                                                                                                    || chr(10)||chr(10)
    );

    --
    -- Errorstack
    --
    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Errorstack - Propria sessao'                                                                                                || chr(10)||chr(10)||
        q'[alter session set tracefile_identifier='errorstack_]'||l_traceid||''';'                                                      || chr(10)||
        q'[alter session set max_dump_file_size='unlimited';]'                                                                          || chr(10)||
        q'[alter session set events 'immediate trace name errorstack level 3';]'                                                        || chr(10)||chr(10)
    );

    dbms_output.put_line(
        '-----------------------------------------------------------------------------------'                                           || chr(10)||
        '-- Errorstack'                                                                                                                 || chr(10)||chr(10)||

        q'[oradebug setospid ]'||l_pid                                                                                                  || chr(10)||
        q'[oradebug settracefileid errorstack_]'||l_traceid                                                                             || chr(10)||
        q'[oradebug unlimit]'                                                                                                           || chr(10)||
        q'[oradebug dump errorstack 3]'                                                                                                 || chr(10)||
        q'[oradebug tracefile_name]'                                                                                                    || chr(10)||chr(10)
    );
    --
    -- Destino dos arquivos de trace
    --
    select value into l_cam_trace from v$parameter where lower(name) = 'user_dump_dest';
    dbms_output.put_line(
        '-------------------------------------------------------------------------------------------------'     || chr(10)||
        '-- Caminho dos arquivos de trace: '||l_cam_trace                                                       || chr(10)||chr(10)
    );

exception
    when no_data_found then
        dbms_output.put_line('SID inexistente');
end;
/

spool off
prompt host &&DESTDIR.\trace_cmd_&&inst._&&p_sid_arq._&&dt..sql

clear columns sql
undef sid p_sid dt p_sid_arq inst

@%temp%\sqlenv
prompt

