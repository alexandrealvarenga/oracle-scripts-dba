/* hv_sqlid.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Obtem um SQL ID a partir de um Hash Value
 * Utilizacao: @hv_sqlid 7h3bb6cd821wr
 *
 */

set verify off
col sql_id for a15

select sql_id from v$sql where hash_value = &1;

undef 1
