-------------------------------------------------------------------------------------------------------------------
-- Lista a tabela a qual pertence um indice
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (26/04/2017)
-------------------------------------------------------------------------------------------------------------------


set verify off
col table_owner for a30
col table_name for a30
col owner for a30
col index_name for a30

select owner, index_name, table_owner, table_name
from dba_indexes
where index_name like upper('&1')
order by 1, 2, 3, 4;

clear columns
undef 1