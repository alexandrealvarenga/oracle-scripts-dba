col sequence# for 9999999999
col status for a6
col deleted for a7
col name for a80
set lines 180
select sequence#, status, deleted, name from v$archived_log where &scn between first_change# and next_change#;