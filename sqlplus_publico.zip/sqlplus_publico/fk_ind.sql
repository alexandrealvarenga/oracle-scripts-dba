set verify off
col owner              format a20
col table_name         format a32
col constraint_name    format a32
col Constraint_Columns format a120 wrap
accept ow prompt 'Informe o owner (parte) das constraints : '
select t1.owner, t1.table_name, t1.constraint_name, t1.r_owner, t1.r_constraint_name, t2.table_name, t1.constraint_columns
from   dba_constraints t2
       ,(select c.owner
       ,        c.table_name
       ,        c.constraint_name
       ,        c.r_owner
       ,        c.r_constraint_name
       ,        c.constraint_columns
       from     (select   b.owner                                                 owner
                 ,        a.constraint_name                                       constraint_name
                 ,        a.table_name                                            table_name
                 ,        b.r_owner                                               r_owner
                 ,        b.r_constraint_name                                     r_constraint_name
                 ,        max(decode(position,  1,         column_name, null)) ||
                          max(decode(position,  2, ', ' || column_name, null)) ||
                          max(decode(position,  3, ', ' || column_name, null)) ||
                          max(decode(position,  4, ', ' || column_name, null)) ||
                          max(decode(position,  5, ', ' || column_name, null)) ||
                          max(decode(position,  6, ', ' || column_name, null)) ||
                          max(decode(position,  7, ', ' || column_name, null)) ||
                          max(decode(position,  8, ', ' || column_name, null)) ||
                          max(decode(position,  9, ', ' || column_name, null)) ||
                          max(decode(position, 10, ', ' || column_name, null)) ||
                          max(decode(position, 11, ', ' || column_name, null)) ||
                          max(decode(position, 12, ', ' || column_name, null)) ||
                          max(decode(position, 13, ', ' || column_name, null)) ||
                          max(decode(position, 14, ', ' || column_name, null)) ||
                          max(decode(position, 15, ', ' || column_name, null)) ||
                          max(decode(position, 16, ', ' || column_name, null))    constraint_columns
                 from     dba_cons_columns  a
                 ,        dba_constraints   b
                 where    a.constraint_name = b.constraint_name
                 and      a.owner           = b.owner
                 and      a.table_name      = b.table_name
                 and      b.constraint_type = 'R'
                 group by b.owner
                 ,        a.table_name
                 ,        a.constraint_name
                 ,        b.r_owner
                 ,        b.r_constraint_name) C
       ,        (select   table_owner                                                  table_owner
                 ,        table_name                                                   table_name
                 ,        index_name                                                   index_name
                 ,        max(decode(column_position, 1,        column_name, null)) ||
                          max(decode(column_position, 2,', ' || column_name, null)) ||
                          max(decode(column_position, 3,', ' || column_name, null)) ||
                          max(decode(column_position, 4,', ' || column_name, null)) ||
                          max(decode(column_position, 5,', ' || column_name, null)) ||
                          max(decode(column_position, 6,', ' || column_name, null)) ||
                          max(decode(column_position, 7,', ' || column_name, null)) ||
                          max(decode(column_position, 8,', ' || column_name, null)) ||
                          max(decode(column_position, 9,', ' || column_name, null)) ||
                          max(decode(column_position,10,', ' || column_name, null)) ||
                          max(decode(column_position,11,', ' || column_name, null)) ||
                          max(decode(column_position,12,', ' || column_name, null)) ||
                          max(decode(column_position,13,', ' || column_name, null)) ||
                          max(decode(column_position,14,', ' || column_name, null)) ||
                          max(decode(column_position,15,', ' || column_name, null)) ||
                          max(decode(column_position,16,', ' || column_name, null))     index_columns
                 from     dba_ind_columns
                 group by table_owner
                 ,        table_name
                 ,        index_name) i
       where    c.table_name    = i.table_name (+)
       and      c.owner         = i.table_owner (+)
       and      upper(c.owner)  like upper('%&ow%')
       and      i.index_columns (+) like c.constraint_columns || '%'
       and      i.table_name    is null
       order by 1, 2) t1
where t1.r_owner           = t2.owner
and   t1.r_constraint_name = t2.constraint_name
/
set verify on
undef ow;