col usuario for a15
col amostra for a100 word_wrapped
set long 5000 verify off

accept v_usr prompt 'Usuario: '

select s1.inst_id, s1.plan_hash_value, s1.exec_count, s2.amostra
from
(select inst_id, plan_hash_value, count(*) exec_count
from gv$sql
where parsing_schema_name = upper('&v_usr')
and plan_hash_value <> 0
group by inst_id, plan_hash_value) s1
join
(select inst_id, plan_hash_value, sql_text amostra, row_number() over (partition by plan_hash_value, inst_id order by plan_hash_value) rownumber
from gv$sql
where parsing_schema_name = upper('&v_usr')
and plan_hash_value <> 0) s2 on s1.plan_hash_value = s2.plan_hash_value and s1.inst_id = s2.inst_id
where s2.rownumber = 1
order by s1.exec_count desc
/
