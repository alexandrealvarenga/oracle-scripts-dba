/* pga_usage_hist.sql
 *
 * Autor:      Tomasz Lesinski
 * Descricao:  Historico de uso de PGA
 * Utilizacao: @pga_usage_hist
 * Ref.: https://dbaora.com/oracle-pga-monitoring-using-ash-and-awr/
 */

undef username n_days per_mins

WITH
pga_data as
(
  SELECT /*+ MATERIALIZED */
      sample_time,
      nvl(sum(ash.pga_allocated/1024/1024),0) AS sum_pga_mb
    FROM
      dba_hist_active_sess_history ash,
      dba_users u
   WHERE ash.user_id = u.user_id
     AND u.username  LIKE upper('&&username')
     AND sample_time > SYSDATE- &&n_days
     AND sample_time < SYSDATE
     AND ash.instance_number = (select instance_number from v$instance)
     AND ash.dbid = (select dbid from v$database)
  GROUP BY action, sample_time
),
cal_data AS
(
  SELECT
    trunc(SYSDATE, 'MI') - (LEVEL/(24*60) * &&per_mins)     AS date_min,
    trunc(SYSDATE, 'MI') - ((LEVEL-1)/(24*60) * &&per_mins) AS date_max
  FROM dual
  CONNECT BY LEVEL < (24*60*&&n_days/&&per_mins)+1
  ORDER BY date_min
)
SELECT /*+ NO_MERGE(h) NO_MERGE(c) */
    to_char(c.date_min, 'YYYY-MM-DD HH24:MI:SS') date_min,
    trunc(nvl(avg(sum_pga_mb),0), 2) avg_pga_mb,
    trunc(nvl(min(sum_pga_mb),0), 2) min_pga_mb,
    trunc(nvl(max(sum_pga_mb),0), 2) max_pga_mb
  FROM
    pga_data h,
    cal_data c
 WHERE h.sample_time (+) >= c.date_min
   AND h.sample_time (+) <  c.date_max
GROUP BY c.date_min
order by c.date_min;

undef username n_days per_mins
