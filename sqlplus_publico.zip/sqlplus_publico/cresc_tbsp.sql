-- Lucas Pimentel Lellis
-- Crescimento dos tablespaces nos �ltimos x meses

col nm_tablespace_name for a30
col alocado for 999G999G999G990
col livre for 999G999G999G990
col usado for 999G999G999G990
col cresc_alocado for 999G999G999G990
col cresc_livre for 999G999G999G990
col cresc_usado for 999G999G999G990
col nr_per_ocupado for 99999999999990
col dummy noprint

compute avg label 'MEDIA' of cresc_alocado on dummy
compute avg label 'MEDIA' of cresc_usado on dummy
break on dummy skip page

select nm_tablespace_name dummy,
       nm_tablespace_name,
       to_char(dt_sysdate, 'DD/MM/YYYY') dt_coleta,
       alocado,
       alocado - lag(alocado) over (partition by nm_tablespace_name order by dt_sysdate) cresc_alocado,
       livre,
       alocado-livre usado,
       alocado-livre - lag(alocado-livre) over (partition by nm_tablespace_name order by dt_sysdate) cresc_usado,
       nr_per_ocupado
from (
    select nm_tablespace_name, dt_sysdate, round(nr_tot_alocado/power(1024, 2)) alocado,
           round(nr_tot_livre/power(1024,2)) livre,
           nr_per_ocupado,
           row_number() over (partition by nm_tablespace_name, trunc(dt_sysdate, 'MONTH') order by dt_sysdate) rn
    from ORADBA.USED_TABLESPACE_GROWTH g
    where trunc(dt_sysdate, 'MONTH') >= add_months(trunc(sysdate, 'MONTH'), -&num_meses)
    and upper(nm_tablespace_name) like upper('&nome_tablespace')
) g
where rn = 1
order by nm_tablespace_name, dt_sysdate;

clear columns
clear breaks
clear computes
undef num_meses
undef nome_tablespace
