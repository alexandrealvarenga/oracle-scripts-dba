set verify off
set feedback off

col sql_text for a70

accept id number prompt 'SID : '
select a.sql_text
from v$sqltext a,
     v$session s
where s.sql_address = a.address
  and s.sid = &id
order by a.piece
/

set feedback on
set verify on
