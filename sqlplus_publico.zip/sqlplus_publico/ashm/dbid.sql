

--col f_minutes new_value v_minutes
--select &minutes f_minutes from dual;
--select &v_minutes from dual;

define v_dbid=NULL;
select &v_dbid from dual;
col f_dbid new_value v_dbid
select &database_id f_dbid from dual;
select &v_dbid from dual;
select nvl(&v_dbid,dbid) f_dbid from v$database;
select &v_dbid from dual;

