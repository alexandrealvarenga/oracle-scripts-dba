set term off
store set %temp%\sqlenv replace
set term on

set feed off
set ver off
set line 150

ttitle "Tabela: " tabela

col tabela noprint
col coluna for a20 
col notnull head "Null?" for a8
col tipo head "Tipo" for a20
col data_default head "Default" for a20
col comments head "Coment�rio" for a50 wrap

break on tabela

select tc.owner||'.'||tc.table_name||' - '||tcc.comments Tabela,
       tc.column_name Coluna,
       decode(tc.nullable, 'N', 'NOT NULL',
                           '') notnull,
         decode (tc.data_type, 'DATE', tc.data_type,
                             'NUMBER', tc.data_type||'('||nvl(tc.data_precision,38)||
                                 decode(data_scale,null,')',
                                                   0,')',
                                                   ','||data_scale||')'),
                             'LONG', tc.data_type,
                             tc.data_type||'('||tc.data_length||')') Tipo,
       tc.data_Default , cc.comments 
from  dba_tab_columns tc, dba_col_comments cc, dba_tab_comments tcc
where tc.owner = cc.owner(+) and
      tc.table_name = cc.table_name(+) and
      tc.column_name = cc.column_name(+) and
      tc.owner = tcc.owner(+) and
      tc.table_name = tcc.table_name(+) and
      tc.table_name = UPPER('&1')
ORDER BY 1, tc.column_id;


ttitle off
@%temp%\sqlenv.sql
set term on
