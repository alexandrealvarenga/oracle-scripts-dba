------------------------------------------------------------------------
-- Listagem dos 10 piores SQLs de um usuário e execução
-- do SQL Tuning Advisor
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (05/10/2013)
------------------------------------------------------------------------

set verify off feed off echo off lines 200 serveroutput on size 1000000

accept usernm prompt 'Username: '

col sql_id for a20
col executions for 9999999999
col elapsed_seconds for 999999999999999.00
col plan_hash_value for 9999999999
col force_matching_signature for 9999999999999999999999999
col text for a100
select *
from (
    select s.sql_id, s.executions, round(s.elapsed_time * 1e-6, 2) elapsed_seconds, plan_hash_value, force_matching_signature, substr(s.sql_text, 0, 100) text
    from v$sql s
    where upper(s.parsing_schema_name) = upper('&usernm')
    order by s.elapsed_time desc
) where rownum <= 10
order by 3 desc;

prompt
accept sqlid prompt 'SQL ID: '
accept time_lim prompt 'Time limit (s): '

col epoch_time new_val w_epoch_time noprint

-- Ref: http://shafiqissani.wordpress.com/2010/09/30/how-to-get-the-current-epoch-time-unix-timestamp/
SELECT trim(trunc((SYSDATE - TO_DATE('01-01-1970 00:00:00', 'DD-MM-YYYY HH24:MI:SS')) * 24 * 60 * 60)) epoch_time
FROM DUAL;

-- Ref: http://www.oracle-base.com/articles/10g/automatic-sql-tuning-10g.php
DECLARE  
    l_sql_tune_task_id  VARCHAR2(200);
    l_sqlid varchar2(200) := '&sqlid';
    l_time_lim varchar2(200) := '&time_lim';
    l_task_name varchar2(200);
    l_job_name varchar2(200);
    l_in_cache pls_integer := 0;
    l_min_snap dba_hist_snapshot.snap_id%type;
    l_max_snap dba_hist_snapshot.snap_id%type;
BEGIN
    if (l_sqlid = '' or l_sqlid is null) or
       (l_time_lim = '' or l_time_lim is null) then
       dbms_output.put_line('Parametro(s) nao informado(s)');
    else
        l_task_name := l_sqlid||'_&w_epoch_time';
        l_job_name := 'job_'||l_sqlid||'_&w_epoch_time';
        
        select count(*) in_cache
        into l_in_cache
        from v$sql
        where sql_id = l_sqlid;
        
        if l_in_cache > 0 then
            l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (                          
                sql_id      => l_sqlid,                          
                scope       => DBMS_SQLTUNE.scope_comprehensive,                          
                time_limit  => l_time_lim,                          
                task_name   => l_task_name,                          
                description => 'Tuning task for statement '||l_sqlid||'.');
        else
            select min(snap_id), max(snap_id)
            into l_min_snap, l_max_snap
            from dba_hist_snapshot;
        
            l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (                          
                begin_snap  => l_min_snap,
                end_snap    => l_max_snap,
                sql_id      => l_sqlid,                          
                scope       => DBMS_SQLTUNE.scope_comprehensive,                          
                time_limit  => l_time_lim,                          
                task_name   => l_task_name,                          
                description => 'Tuning task for statement '||l_sqlid||'.');
        end if;
        
        dbms_scheduler.create_job (
            job_name            => l_job_name,
            job_type            => 'STORED_PROCEDURE',
            job_action          =>  'sys.dbms_sqltune.execute_tuning_task',
            number_of_arguments => 1,
            start_date          => current_date,
            enabled             => false,
            auto_drop           => true,
            comments            => 'Tuning advisor da query '||l_sqlid);
        
        dbms_scheduler.set_job_argument_value(
            job_name                => l_job_name,
            argument_position       => 1,
            argument_value          => l_task_name);
            
        dbms_scheduler.enable(l_job_name);
        
        dbms_output.put_line('## Task submetida com sucesso ##'||chr(10));
        
        dbms_output.put_line(
            '-- Verificar status da task do advisor --'||chr(10)||
            'column error_message for a60 word_wrapped');
        dbms_output.put_line(
            'select execution_start, execution_end, status, error_message'||chr(10)||
            'from user_advisor_log');
        dbms_output.put_line(
            'where task_name='''||l_task_name||''';'||chr(10)||chr(10));
        dbms_output.put_line(
            '-- Cancelar status da task do advisor --'||chr(10)||
            '-- exec dbms_sqltune.drop_tuning_task('''||l_task_name||''')'||chr(10)||
            '-- exec dbms_scheduler.drop_job('''||l_job_name||''',true)'||chr(10));
            
        dbms_output.put_line(
            '-- Executar apos a conclusao da task do advisor --'||chr(10)||
            'SET LONG 100000'||chr(10)||
            'SET PAGESIZE 50000'||chr(10)||
            'SET LINESIZE 500'||chr(10)||
            'SET HEAD off'||chr(10)||
            'SET FEED off'||chr(10)||
            'COL recommendations for a500'||chr(10)||
            'COL script for a500');
        dbms_output.put_line(            
            'SELECT DBMS_SQLTUNE.report_tuning_task('''||l_task_name||''') AS recommendations FROM dual;');
        dbms_output.put_line(  
            'SELECT DBMS_SQLTUNE.script_tuning_task('''||l_task_name||''') AS script FROM dual;'||chr(10)||chr(10));
    end if;
END;
/

undef sqlid time_lim
set verify on feed on
