col tam_mb for 9999999999999.00
select name, bytes/1024/1024 tam_mb, resizeable
from v$sgainfo;
