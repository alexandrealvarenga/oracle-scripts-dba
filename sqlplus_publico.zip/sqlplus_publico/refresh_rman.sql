-------------------------------------------------------------------------------
--       Nome : Salvar permissoes, sinonimos e db links para refresh via RMAN
--      Autor : Lucas Pimentel Lellis
--       Data : 26/05/2010
-- Finalidade : Salvar permissoes, sinonimos e db links das
--              instancias que tem seu refresh feito via RMAN
--
--       Ref. : How To Regenerate the ACL Creation Script Based On
--              the Contents Of DBA_NETWORK_ACLS (Doc ID 1634275.1)
-------------------------------------------------------------------------------

set term off

store set %temp%\sqlenv replace

set term on echo off feedback off verify off linesize 1000 long 999999999 longchunksize 999999999 trimspool on

accept INSTDEST prompt 'Instancia de DESTINO: '
accept SENHA_DESTINO prompt 'SENHA do SYS - DESTINO: ' hide
accept DIR prompt 'Diretorio dos scripts: '
accept INSTORIG prompt 'Instancia de ORIGEM: '
accept SENHA_ORIGEM prompt 'SENHA do SYS - ORIGEM: ' hide

------------------------------------------------------------------------------------------
-- PASSO 00: Gerar Arquivos de conexo
------------------------------------------------------------------------------------------
set term off
spool "&DIR/_conecta.sql"

prompt SET ECHO OFF HEAD OFF TERM OFF

set escape on
prompt
prompt conn SYS/##########@\&1 as sysdba
prompt
set escape off

prompt SET LINESIZE 1000
prompt SET LONG 999999999
prompt SET PAGESIZE 50000
prompt
prompt SET TERM ON FEED OFF
prompt
prompt alter session set nls_date_format='DD/MM/YYYY HH24:MI:SS';;
prompt
prompt SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
prompt FROM global_name;;
prompt
prompt set trimspool on term off feedback off verify off echo off heading off serveroutput on

spool off

spool "&DIR/_conecta_memoria.sql"

prompt SET ECHO OFF HEAD OFF TERM OFF

set escape on
prompt
prompt conn SYS/########## as sysdba
prompt
set escape off

prompt SET LINESIZE 1000
prompt SET LONG 999999999
prompt SET PAGESIZE 50000
prompt
prompt SET TERM ON FEED OFF
prompt
prompt alter session set nls_date_format='DD/MM/YYYY HH24:MI:SS';;
prompt
prompt SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
prompt FROM global_name;;
prompt
prompt set trimspool on term off feedback off verify off echo off heading off serveroutput on

set escape on
prompt set sqlprompt '\&_USER.@\&_CONNECT_IDENTIFIER.> '

spool off

set trimspool on term off feedback off verify off echo off heading off serveroutput on size 1000000 escape off

conn SYS/&SENHA_DESTINO@&INSTDEST as sysdba
set term on feed off
SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set term off

col dt new_val ldt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

------------------------------------------------------------------------------------------
-- PASSO 01: Exportar Metadados da instancia de destino
------------------------------------------------------------------------------------------

set term on
prompt
prompt PASSO 01: Exportar Metadados da instancia de destino
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._01_export_metadata.txt"

prompt
prompt ###################################
prompt # Executar no servidor de DESTINO
prompt ###################################
prompt
prompt expdp userid="'/ as sysdba'" directory=data_pump_dir content=metadata_only full=y dumpfile=refresh_rman_&ldt..dmp logfile=refresh_rman.log
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 02: Recriar tablespaces e profiles
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 02: Recriar tablespaces e profiles
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._02_impdp_tbsp_profile.txt"

prompt
prompt ###################################
prompt # Executar no servidor de DESTINO
prompt ###################################
prompt
prompt impdp userid="'/ as sysdba'" directory=data_pump_dir include=tablespace,profile dumpfile=refresh_rman_&ldt..dmp logfile=refresh_rman_impdp_&ldt..log
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 03: Recriar usuarios e roles da instancia de destino
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 03: Recriar usuarios da instancia de destino
prompt
set term off serveroutput on size 1000000

col create_user for a1000

spool "&DIR/&INSTDEST._03_users_roles.txt"

prompt
prompt ###################################
prompt # Executar no servidor de DESTINO
prompt ###################################
prompt
prompt impdp userid="'/ as sysdba'" directory=data_pump_dir include=user,role,tablespace_quota dumpfile=refresh_rman_&ldt..dmp logfile=refresh_rman_impdp_users_roles_&ldt..log
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 04: Dropar db links clonados da instancia de origem
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 04: Dropar db links clonados da instancia de origem
prompt
set term off serveroutput on size 1000000

conn SYS/&SENHA_ORIGEM@&INSTORIG as sysdba
set term on feed off
SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set term off serveroutput on size 1000000

DEFINE SENHA_TEMP=kasfw12z

spool "&DIR/&INSTDEST._04_limpa_db_links_orig.sql"

prompt spool "&DIR/&INSTDEST._04_limpa_db_links_orig.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on

select distinct 'alter user "'||dbl.owner||'" identified by &SENHA_TEMP;'
from dba_db_links dbl
where dbl.owner not in ('SYS', 'PUBLIC');


prompt
prompt grant create database link to public;;
prompt

DECLARE
        owner_anterior dba_db_links.owner%type := '';
BEGIN
        FOR c_dblink IN (select owner, db_link from dba_db_links order by owner, db_link)
        LOOP
                IF c_dblink.owner <> owner_anterior OR owner_anterior IS NULL THEN
                        IF c_dblink.owner in ('PUBLIC', 'SYS') THEN
                                dbms_output.put_line(Chr(10)||'@@_conecta &INSTDEST'||Chr(10));
            ELSE
                                dbms_output.put_line(Chr(10)||'conn '||c_dblink.owner||'/&SENHA_TEMP@&INSTDEST'||Chr(10));
                        END IF;
                        owner_anterior := c_dblink.owner;
                        dbms_output.put_line('set echo on feed on'||Chr(10));
                END IF;
                IF c_dblink.owner = 'PUBLIC' THEN
                        dbms_output.put_line('drop public database link "'||c_dblink.db_link||'";');
                ELSE
                        dbms_output.put_line('drop database link "'||c_dblink.db_link||'";');
                END IF;
        END LOOP;
END;
/

prompt
prompt disc
prompt spool off
prompt

spool off


------------------------------------------------------------------------------------------
-- PASSO 05: Recriar db links da instancia de destino
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 05: Recriar db links da instancia de destino
prompt
set term off serveroutput on size 1000000

column codigo_fonte format a1000

conn SYS/&SENHA_DESTINO@&INSTDEST as sysdba
set term on feed off
SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._05_recria_db_links.txt"

prompt
prompt ###################################
prompt # Executar no servidor de DESTINO
prompt ###################################
prompt
prompt impdp userid="'/ as sysdba'" directory=data_pump_dir include=db_link dumpfile=refresh_rman_&ldt..dmp logfile=refresh_rman_impdp_db_link_&ldt..log
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 06: Dropar sinonimos com db links que apontam para instancias de producao
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 06: Dropar sinonimos com db links que apontam para instancias de producao
prompt
set term off serveroutput on size 1000000

conn SYS/&SENHA_ORIGEM@&INSTORIG as sysdba
set term on feed off
SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._06_limpa_sinonimos_prod.sql"

prompt spool "&DIR/&INSTDEST._06_limpa_sinonimos_prod.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on

prompt
prompt grant create synonym to public;;
prompt

select 'drop synonym "'||syn.owner||'"."'||syn.synonym_name||'";'
from dba_synonyms syn
where not db_link is null
and owner <> 'PUBLIC'
order by syn.owner, syn.synonym_name;

select 'drop public synonym "'||synonym_name||'";'
from dba_synonyms
where not db_link is null
and owner = 'PUBLIC';

prompt
prompt revoke create database link from public;;
prompt

prompt
prompt disc
prompt spool off
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 07: Recriar sinonimos com db links de desenvolvimento
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 07: Recriar sinonimos com db links de desenvolvimento
prompt
set term off serveroutput on size 1000000

conn SYS/&SENHA_DESTINO@&INSTDEST as sysdba
set term on feed off
SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._07_recria_sinonimos_origem.sql"

prompt spool "&DIR/&INSTDEST._07_recria_sinonimos_origem.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on


select 'create or replace public synonym "'||synonym_name||'" for "'||table_owner||'"."'||table_name||'"@"'||db_link||'";'
from dba_synonyms
where not db_link is null
and owner = 'PUBLIC';


select 'create or replace synonym "'||syn.owner||'"."'||syn.synonym_name||'" for "'||syn.table_owner||'"."'||syn.table_name||'"@"'||syn.db_link||'";'
from dba_synonyms syn
where not db_link is null
and owner <> 'PUBLIC'
order by owner, synonym_name;

prompt
prompt @@_conecta &INSTDEST

prompt
prompt revoke create synonym from public;;
prompt

prompt
prompt disc
prompt spool off
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 08: Alterar senhas dos usuarios da instancia de destino
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 08: Alterar senhas dos usuarios da instancia de destino
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._08_alterar_senhas.sql"

prompt spool "&DIR/&INSTDEST._08_alterar_senhas.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on
prompt

declare
    l_ddl varchar2(32767);
begin
    dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'SQLTERMINATOR', false);

    -- in order to return the create user command in a single line
    dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'PRETTY', false);

    for c_user in (select dbms_metadata.get_ddl('USER', username, null) codigo_fonte, account_status
                   from dba_users
                   where username not in ('ANONYMOUS', 'XS$NULL', 'SYS')
                  ) loop

        -- removes everything after the password hash
        l_ddl := regexp_replace(c_user.codigo_fonte, '[ ]*(DEFAULT|TEMPORARY) TABLESPACE .+', '');

        l_ddl := replace(l_ddl, 'CREATE ', 'ALTER ');

        -- removes all newline characters
        l_ddl := replace(l_ddl, chr(10), null);
        l_ddl := replace(l_ddl, chr(13), null);

        if c_user.account_status = 'OPEN' then
            l_ddl := l_ddl || ' ACCOUNT UNLOCK;';
        else
            l_ddl := l_ddl || ';';
        end if;

        dbms_output.put_line(l_ddl);

    end loop;

    -- Undoes changes to dbms_metadata parameters
    dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'DEFAULT', true);
end;
/

prompt
prompt disc
prompt spool off
prompt

spool off

------------------------------------------------------------------------------------------
-- PASSO 09: Remover Network ACLs copiadas da origem
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 09: Remover Network ACLs copiadas da origem
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._09_remover_acls.sql"

prompt spool "&DIR/&INSTDEST._09_remover_acls.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on
prompt

select distinct 'exec dbms_network_acl_admin.drop_acl('||chr(39)||acl||chr(39)||');'
from dba_network_acls
order by 1;

prompt
prompt commit;;

prompt
prompt disc
prompt spool off
prompt

spool off


------------------------------------------------------------------------------------------
-- PASSO 10: Recriar Network ACLs do destino
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 10: Recriar Network ACLs do destino
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._10_recriar_acls.sql"

prompt spool "&DIR/&INSTDEST._10_recriar_acls.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on
prompt

declare
  v_param_list varchar2(2000);

  cursor rec_c(i_ACLID dba_network_acl_privileges.ACLID%type, i_ACL dba_network_acl_privileges.ACL%type) is
    select rownum POSITION,
           ACL,
           PRINCIPAL,
           decode(privilege,
                  'use-cli',
                  'use-client-certificates',
                  'use-pas',
                  'use-passwords',
                  privilege) PRIVILEGE,
           IS_GRANT,
           INVERT,
           decode(START_DATE,
                  null,
                  'null',
                  'to_timestamp_tz(''' ||
                  to_char(START_DATE, 'YYYYMMDDHH24MISSXFFTZR') ||
                  ''',''YYYYMMDDHH24MISSXFF TZR'')') START_DATE,
           decode(END_DATE,
                  null,
                  'null',
                  'to_timestamp_tz(''' ||
                  to_char(END_DATE,
                          'YYYYMMDDHH24MISSXFFTZR' ||
                          ''',''YYYYMMDDHH24MISSXFF TZR'')')) END_DATE
      from dba_network_acl_privileges a
     where a.ACLID = i_ACLID
       and a.ACL = i_ACL;

  rec rec_c%rowtype;

begin
  for i in (select distinct ACLID, ACL from dba_network_acl_privileges) loop
    open rec_c(i.ACLID, i.acl);
    fetch rec_c
      into rec;
    v_param_list := 'acl=>''' ||
                    substr(rec.acl, instr(rec.acl, '/', -1) + 1) || '''';
    v_param_list := v_param_list || ',description=>''' ||
                    substr(rec.acl, 11, length(rec.acl)) || '''';
    v_param_list := v_param_list || ',principal=>''' || rec.principal || '''';
    v_param_list := v_param_list || ',privilege=>''' || rec.privilege || '''';
    v_param_list := v_param_list || ',is_grant=>' || rec.is_grant;
    v_param_list := v_param_list || ',start_date=>' || rec.END_DATE;
    v_param_list := v_param_list || ',end_date=>' || rec.END_DATE || ');';
    dbms_output.put_line(chr(10)||'exec dbms_network_acl_admin.create_acl(' ||
                         v_param_list);
    -- fetch rec_c into rec ; NOT FETCHING HERE TO AVOID DUPLICATES
    while rec_c%FOUND loop
      v_param_list := 'acl=>''' ||
                      substr(rec.acl, instr(rec.acl, '/', -1) + 1) || '''';
      v_param_list := v_param_list || ',principal=>''' || rec.principal || '''';
      v_param_list := v_param_list || ',is_grant=>' || rec.is_grant;
      v_param_list := v_param_list || ',privilege=>''' || rec.privilege || '''';
      v_param_list := v_param_list || ',position=>' || rec.POSITION;
      v_param_list := v_param_list || ',start_date=>' || rec.END_DATE;
      v_param_list := v_param_list || ',end_date=>' || rec.END_DATE || ');';
      dbms_output.put_line('exec DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(' ||
                           v_param_list);
      fetch rec_c
        into rec;
    end loop;
    close rec_c;

    for rec2 in (select HOST,
                        decode(LOWER_PORT, null, 'null', to_char(LOWER_PORT)) LOWER_PORT,
                        decode(UPPER_PORT, null, 'null', to_char(UPPER_PORT)) UPPER_PORT,
                        ACL,
                        ACLID
                   from dba_network_acls
                  where acl = i.acl
                    and ACLID = i.aclid) loop
      v_param_list := 'acl=>''' ||
                      substr(rec2.acl, instr(rec2.acl, '/', -1) + 1) ||
                      ''',host=>''' || rec2.host || ''',lower_port=>' ||
                      rec2.lower_port || ',upper_port=>' || rec2.upper_port || ');';
      dbms_output.put_line('exec DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL(' ||
                           v_param_list);
    end loop;

  end loop;
end;
/

prompt
prompt commit;;

prompt
prompt disc
prompt spool off
prompt

spool off



------------------------------------------------------------------------------------------
-- PASSO 11: Conceder grants
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 11: Conceder grants
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._11_grants.sql"

prompt spool "&DIR/&INSTDEST._11_grants.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on

select 'grant '||privilege||' to "'||grantee||'"'||decode(admin_option, 'YES', ' with admin option')||';'
from dba_sys_privs
order by grantee, privilege;

select 'grant '||granted_role||' to "'||grantee||'"'||decode(admin_option, 'YES', ' with admin option')||';'
from dba_role_privs
order by grantee, granted_role;

select 'grant '||privilege||' on '||owner||'."'||table_name||'" to "'||grantee||'"'||decode(grantable, 'YES', ' with grant option')||';'
from dba_tab_privs
where table_name not like 'BIN$%'
  and owner <> 'SYS'
order by grantee, privilege, table_name;

prompt
prompt disc
prompt spool off
prompt

spool off



------------------------------------------------------------------------------------------
-- PASSO 12: Conceder grants para objetos do SYS
------------------------------------------------------------------------------------------
set term on
prompt
prompt PASSO 12: Conceder grants para objetos do SYS
prompt
set term off serveroutput on size 1000000

spool "&DIR/&INSTDEST._12_grants_objetos_sys.sql"

prompt spool "&DIR/&INSTDEST._12_grants_objetos_sys.log"
prompt
prompt @@_conecta &INSTDEST
prompt set echo on feedback on term off trimspool on

select 'grant '||privilege||' on '||owner||'."'||table_name||'" to '||grantee||';'
from dba_tab_privs
where table_name not like 'BIN$%'
  and owner = 'SYS';

prompt
prompt disc
prompt spool off
prompt

spool off

------------------------------------------------------------------------------------------
-- Finalizacao
------------------------------------------------------------------------------------------
undef SENHA_TEMP
undef INSTDEST
undef INSTORIG
undef USUARIO
undef SENHA_DESTINO
undef SENHA_ORIGEM


@%temp%\sqlenv

prompt
prompt
prompt Scripts disponiveis em: "&DIR"
prompt
prompt

undef DIR

set term on
disc
