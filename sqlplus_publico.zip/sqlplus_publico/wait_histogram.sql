accept evt_name prompt 'Event Name: ' default ''
column dummy noprint
break on dummy skip page
select event dummy, event, wait_time_milli, wait_count, round(pct, 2) pct, round(sum(pct) over (partition by event order by wait_time_milli), 2) sum_pct
from (
    select h.event, wait_time_milli, wait_count, ratio_to_report(wait_count) over (partition by event) * 100 pct
    from    v$event_histogram h
    where   event like lower('&evt_name')
) order by event, wait_time_milli
;
undef evt_name
clear breaks
clear columns
