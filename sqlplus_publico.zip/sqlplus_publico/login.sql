DEFINE _EDITOR="code"
set trimspool on trimout on feed on autocommit off time on sqlbl on tab off verify off
set linesize 1000 arraysize 500 pages 9999 longchunksize 10240000 long 2000000
set describe depth 1 linenum on indent on
set serveroutput on exitcommit off

col first_change# for 99999999999999999
col next_change# for 99999999999999999
col checkpoint_change# for 99999999999999999
col resetlogs_change# for 99999999999999999
col current_scn for 99999999999999999
col plan_plus_exp for a100
col value_col_plus_show_param ON HEADING  'VALUE'  FORMAT a100

set sqlprompt "_USER'@'_CONNECT_IDENTIFIER _PRIVILEGE> "
