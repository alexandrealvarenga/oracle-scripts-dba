------------------------------------------------------------------------
-- Criacao de tarefa do SQL Access Advisor para um determinado
-- SQL Tuning Set
--
-- Criado por: Lucas Lellis - lucas.lellis@dxc.com (05/02/2020)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

set verify off feed off echo off lines 200 serveroutput on size 1000000

accept sts_name prompt 'SQL Tuning Set: '
accept time_lim prompt 'Time limit (m): '


-- Bug 12861432 : ADVISOR PARAMETER PROBLEMS WHEN NLS_NUMERIC_CHARACTERS=',.'
alter session set NLS_NUMERIC_CHARACTERS='.,';

-- Ref: http://www.oracle-base.com/articles/10g/automatic-sql-tuning-10g.php
DECLARE  
    l_acc_adv_task_id  VARCHAR2(200);
    l_sts_name varchar2(200) := '&sts_name';
    l_time_lim varchar2(200) := '&time_lim';
    l_task_name varchar2(200);
    l_job_name varchar2(200);
    l_task_desc varchar2(256) := 'SQL Access Advisor - Lucas Lellis';
BEGIN
    if (l_sts_name = '' or l_sts_name is null) or
       (l_time_lim = '' or l_time_lim is null) then
       dbms_output.put_line('Parametro(s) nao informado(s)');
    else
        l_task_name := 'acc_adv_'||l_sts_name;
        l_job_name := 'job_'||l_sts_name;
        dbms_output.put_line(l_task_name);
        ------------------------------
        -- ACC ADVISOR - inicio
        ------------------------------

        /* Create Task */
        dbms_advisor.create_task(advisor_name   => DBMS_ADVISOR.SQLACCESS_ADVISOR,
                                 task_id        => l_acc_adv_task_id,
                                 task_name      => l_task_name,
                                 task_desc      => l_task_desc);

        /* Reset Task */
        dbms_advisor.reset_task(l_task_name);

        /* Link sts_name Workload to Task */
        dbms_advisor.add_sqlwkld_ref(l_task_name,l_sts_name,1);

        /* Set sts_name Workload Parameters */
        dbms_advisor.set_task_parameter(l_task_name,'VALID_ACTION_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'VALID_MODULE_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'SQL_LIMIT',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'VALID_USERNAME_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'VALID_TABLE_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'INVALID_TABLE_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'INVALID_ACTION_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'INVALID_USERNAME_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'INVALID_MODULE_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'VALID_SQLSTRING_LIST',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'INVALID_SQLSTRING_LIST','"@!"');

        /* Set Task Parameters */
        dbms_advisor.set_task_parameter(l_task_name,'ANALYSIS_SCOPE','INDEX, TABLE, PARTITION');
        dbms_advisor.set_task_parameter(l_task_name,'RANKING_MEASURE','ELAPSED_TIME');
        dbms_advisor.set_task_parameter(l_task_name,'DEF_PARTITION_TABLESPACE',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'TIME_LIMIT',l_time_lim);
        dbms_advisor.set_task_parameter(l_task_name,'MODE','COMPREHENSIVE');
        dbms_advisor.set_task_parameter(l_task_name,'STORAGE_CHANGE',DBMS_ADVISOR.ADVISOR_UNLIMITED);
        dbms_advisor.set_task_parameter(l_task_name,'DML_VOLATILITY','TRUE');
        dbms_advisor.set_task_parameter(l_task_name,'WORKLOAD_SCOPE','PARTIAL');
        dbms_advisor.set_task_parameter(l_task_name,'DEF_INDEX_TABLESPACE',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'DEF_INDEX_OWNER',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'DEF_MVIEW_TABLESPACE',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'DEF_MVIEW_OWNER',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'DEF_MVLOG_TABLESPACE',DBMS_ADVISOR.ADVISOR_UNUSED);
        dbms_advisor.set_task_parameter(l_task_name,'CREATION_COST','TRUE');
        dbms_advisor.set_task_parameter(l_task_name,'JOURNALING','4');
        dbms_advisor.set_task_parameter(l_task_name,'DAYS_TO_EXPIRE','7');



        ------------------------------
        -- ACC ADVISOR - fim
        ------------------------------

        
        dbms_scheduler.create_job (
            job_name            => l_job_name,
            job_type            => 'STORED_PROCEDURE',
            job_action          =>  'sys.dbms_advisor.execute_task',
            number_of_arguments => 1,
            start_date          => current_date,
            enabled             => false,
            auto_drop           => true,
            comments            => 'Access advisor do STS '||l_sts_name);
        
        dbms_scheduler.set_job_argument_value(
            job_name                => l_job_name,
            argument_position       => 1,
            argument_value          => l_task_name);
            
        dbms_scheduler.enable(l_job_name);
        
        dbms_output.put_line('## Task submetida com sucesso ##'||chr(10));
        
        dbms_output.put_line(
            '-- Verificar status da task do advisor --'||chr(10)||
            'column error_message for a60 word_wrapped');
        dbms_output.put_line(
            'select execution_start, execution_end, status, error_message'||chr(10)||
            'from user_advisor_log');
        dbms_output.put_line(
            'where task_name='''||l_task_name||''';'||chr(10)||chr(10));
        dbms_output.put_line(
            '-- Cancelar status da task do advisor --'||chr(10)||
            '-- exec dbms_advisor.delete_task('''||l_task_name||''')'||chr(10)||
            '-- exec dbms_scheduler.drop_job('''||l_job_name||''',true)'||chr(10));
            
        dbms_output.put_line(
            '-- Executar apos a conclusao da task do advisor --'||chr(10)||
            'store set %temp%\sqlenv replace'||chr(10)||
            'SET LONG 100000'||chr(10)||
            'SET PAGESIZE 50000'||chr(10)||
            'SET LINESIZE 500'||chr(10)||
            'SET HEAD off'||chr(10)||
            'SET FEED off'||chr(10)||
            'COL recommendations for a500'||chr(10)||
            'COL script for a500');
        dbms_output.put_line(            
            'SELECT DBMS_ADVISOR.get_task_script('''||l_task_name||''') AS recommendations FROM dual;');
        dbms_output.put_line(  
            '@%temp%\sqlenv'||chr(10)||chr(10));
    end if;
END;
/

undef usernm time_lim
set verify on feed on


@%temp%\sqlenv
prompt
