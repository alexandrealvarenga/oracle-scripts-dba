set serveroutput on echo off verify off

accept tab prompt "Tabela: "
accept owner prompt "Owner: "

declare
	nome_pk dba_constraints.R_CONSTRAINT_NAME%type;
	ddl clob;
begin
	select constraint_name
	into nome_pk
	from dba_constraints
	where owner = upper('&owner')
	and table_name = upper('&tab')
	and constraint_type = 'P';

	for c_const in (select owner, table_name, constraint_name 
					from dba_constraints 
					where constraint_type = 'R' and r_constraint_name = nome_pk and r_owner = upper('&owner') order by table_name, constraint_name) loop
		ddl := dbms_metadata.get_ddl('REF_CONSTRAINT', c_const.constraint_name, c_const.owner);
		dbms_output.put_line(ddl || '/');
	end loop;	
end;
/
