set echo off
set verify off

break on index_name skip page
column index_name format a40
column column_name format a40
column const_type format a10
column position format 99999999
col locality for a10

accept tab prompt 'Tabela: '
accept owner prompt 'Owner: '

select ic.index_name, i.uniqueness, ic.column_name, ic.column_position position, cc.constraint_type const_type, p.locality
from dba_ind_columns ic,
     dba_constraints cc,
     dba_indexes i,
     dba_part_indexes p
where ic.table_name like upper('&tab')
and ic.table_owner like upper('&owner')
and ic.index_name = i.index_name
and ic.index_owner = i.owner
and i.index_name = cc.constraint_name (+)
and i.table_owner = cc.owner (+)
and i.index_name = p.index_name (+)
and i.owner = p.owner (+)
order by cc.constraint_type desc nulls last, ic.index_name, ic.column_position;

clear breaks
