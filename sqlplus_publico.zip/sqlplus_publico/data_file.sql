col file_name for a90
col mb for 99999999999
set verify off

select 'alter database datafile '''||file_name||''' resize ' file_name, bytes/1024/1024 mb
from dba_data_files
where tablespace_name=upper('&1')
order by 1, 2 desc;

