set head on feed off
clear breaks
clear computes

col COMPONENT for a25
col CURRENT_SIZE for a12
col MIN_SIZE for a10
col MAX_SIZE for a10
col USER_SPECIFIED_SIZE for a19
col OPER_COUNT for 999999
col LAST_OPER_TYPE for a14
col LAST_OPER_MODE for a14
col LAST_OPER_TIME for a15
col GRANULE_SIZE for 9999999999

select
    COMPONENT,
    CURRENT_SIZE/1024/1024 || 'MB' CURRENT_SIZE,
    MIN_SIZE/1024/1024 || 'MB' MIN_SIZE,
    MAX_SIZE/1024/1024 || 'MB' MAX_SIZE,
    USER_SPECIFIED_SIZE/1024/1024 || 'MB' USER_SPECIFIED_SIZE,
    OPER_COUNT,
    LAST_OPER_TYPE,
    LAST_OPER_MODE,
    LAST_OPER_TIME,
    GRANULE_SIZE
from v$sga_dynamic_components;  

prompt

col dummy noprint
compute sum of mb on dummy
break on dummy skip 1

col name for a35
select decode(name, 
              'Maximum SGA Size', 1, 
              'Granule Size', 2,
              'Startup overhead in Shared Pool', 3, 
              'Startup NUMA Shared Pool memory', 3, 
              4) dummy,
       name,
       round(bytes/1024/1024) mb
from v$sgainfo
order by dummy, mb desc;

clear breaks

col name for a20
col type for a15
col value for a20
set verify off

select name
       , display_value value
from v$parameter
where name in ('sga_max_size', 'sga_target', 'memory_max_target', 'memory_target')
order by name;

prompt
set head on feed on
