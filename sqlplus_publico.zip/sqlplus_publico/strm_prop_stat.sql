col propagation_name for a30
col status for a20

select propagation_name, status
from dba_propagation
order by status, propagation_name;
