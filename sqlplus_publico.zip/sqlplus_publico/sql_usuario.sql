set verify off
set feedback off

accept usuario prompt 'Usuario: '

COL	SQL	FOR	A100

SELECT first_load_time Hora, SQL_TEXT SQL
FROM V$SQL, DBA_USERS
WHERE PARSING_SCHEMA_ID = USER_ID
and username = '&usuario'
ORDER BY first_load_time;

undef &usuario

CLEAR COL

set verify on
set feedback on

