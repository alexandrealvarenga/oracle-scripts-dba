store set %temp%\sqlenv replace

set heading off
set feedback off
set verify off

accept vw prompt "View: "
accept owner prompt "Owner: "

set linesize 500

column codigo_fonte format a500

select dbms_metadata.get_ddl('MATERIALIZED_VIEW', upper('&vw'), upper('&owner')) codigo_fonte
from dual;

select 'grant '||privilege||' on '||owner||'.'||table_name||' to '||grantee||';'
from dba_tab_privs
where table_name=upper('&vw')
and owner=upper('&owner');

prompt

@%temp%\sqlenv.sql
