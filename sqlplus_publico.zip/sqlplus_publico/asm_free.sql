col PERCENT_USED for 999.99
col type for a10
select name, 100-((usable_file_mb/decode(total_mb, 0, 1, total_mb))*100) PERCENT_USED, state, free_mb, usable_file_mb, (total_mb-usable_file_mb) used_mb, total_mb, ceil(total_mb/1024) total_gb, type
from v$asm_diskgroup_stat
order by 1, 2;
