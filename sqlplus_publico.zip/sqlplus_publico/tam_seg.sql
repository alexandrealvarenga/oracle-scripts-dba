set echo off verify off

column segment_name format a30
column partition_name format a30
col owner for a30
col segment_type for a30

accept seg_name prompt 'Segmento: '

break on report
compute sum of MB on report

select owner, segment_name, partition_name ,segment_type,bytes/(1048576) MB
from dba_segments
where segment_name like upper('%&seg_name%')
order by owner asc, mb desc
/

--undef seg_name
