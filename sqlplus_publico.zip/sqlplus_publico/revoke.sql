col cmd for a100
set head off

--select 'revoke '||granted_role||' from SYSTEM;' cmd
--from dba_role_privs 
--where granted_role not in ('USUARIO', 'DBA', 'ABD_ACCENTURE', 'MGMT_USER', 'CONNECT', 'RESOURCE', 'SELECT_CATALOG_ROLE')
--and granted_role not like 'CPD%'
--and grantee = 'SYSTEM'
--union all
--select 'revoke '||privilege||' on '||owner||'.'||table_name||' from '||grantee||';' cmd
--from dba_tab_privs
--where grantee = 'SYSTEM'
--and owner <> 'SYS'
--union all
select 'alter user '||client||' revoke connect through '||proxy||';'
from proxy_users
where proxy = 'ORADBA';

set head on
