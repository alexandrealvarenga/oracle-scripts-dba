set verify off feed off heading off serveroutput on format wrapped echo off

accept ow prompt 'Informe o owner dos objetos : '
accept dtinfo prompt 'Data do bloqueio (YYMMDD): '
accept dir prompt 'Pasta do spool: '

spool &dir\rename_&ow._&dtinfo..sql

col num_obj new_val wnum_obj noprint
select count(*) num_obj from dba_objects where owner = upper('&ow')
and (OBJECT_TYPE IN ('TABLE', 'VIEW', 'SEQUENCE') OR (OWNER <> 'PUBLIC' AND OBJECT_TYPE = 'SYNONYM'));

declare
   w_dtinfo    varchar2(9) := '_B&dtinfo';
   w_sufixoi   varchar2(10);
   w_sufixo    varchar2(10);
   w_obtype    varchar2(1);
   w_newname   varchar2(50);
begin
   w_sufixoi := 1;
      for r_owner in (select distinct owner from dba_objects where owner = upper('&ow') order by 1)
      loop
         for r_objtype in (select distinct object_type from dba_objects where owner = r_owner.owner and (OBJECT_TYPE IN ('TABLE', 'VIEW', 'SEQUENCE') OR (OWNER <> 'PUBLIC' AND OBJECT_TYPE = 'SYNONYM')))
         loop
            w_sufixoi := 0;
            for r_object_name in (select object_type, object_name from dba_objects
                                  where  owner       = r_owner.owner
                                  and    object_type = r_objtype.object_type
            )
            loop
               if    r_object_name.object_type = 'PROCEDURE' then
                  w_obtype := 'P';
               elsif r_object_name.object_type = 'PACKAGE' then
                  w_obtype := 'K';
               elsif r_object_name.object_type = 'FUNCTION' then
                  w_obtype := 'F';
               elsif r_object_name.object_type = 'TABLE' then
                  w_obtype := 'T';
               elsif r_object_name.object_type = 'VIEW' then
                  w_obtype := 'V';
               elsif r_object_name.object_type = 'SEQUENCE' then
                  w_obtype := 'S';
               end if;
               if length(r_object_name.object_name) > 17 then
                  w_sufixoi := w_sufixoi + 1;
                  w_sufixo := substr('0000'||w_sufixoi, -4);
                  w_newname := substr(r_object_name.object_name, 1, 17) || w_dtinfo || w_obtype || w_sufixo;
               else
                  w_newname := r_object_name.object_name || w_dtinfo;
               end if;
               dbms_output.put_line('-- '||rpad(r_owner.owner, 20, ' ')||' '||rpad(r_object_name.object_name, 32, ' ')||' '||rpad(r_objtype.object_type, 20, ' ')||' '||rpad('RENAME '||CHR(34)||r_object_name.object_name||CHR(34)||' TO '||CHR(34)||w_newname||CHR(34)||';', 80, ' ')||' '||rpad('RENAME '||CHR(34)||w_newname||CHR(34)||' TO '||CHR(34)||r_object_name.object_name||CHR(34)||';', 80, ' '));
            end loop;
         end loop;
      end loop;
end;
/

prompt 
prompt spool &dir\rename_&ow._&dtinfo..log
prompt 

prompt
prompt @s ###INSTANCIA###
prompt

prompt
prompt alter user &ow identified by ksa13vtR account unlock;;
prompt

prompt
prompt conn &ow/ksa13vtR@###INSTANCIA###
prompt

prompt ## Inserir bloco do rename ##

begin
    for i in 1..&wnum_obj
    loop
        dbms_output.put_line('');
    end loop;
end;
/

prompt
prompt @s ###INSTANCIA###
prompt

prompt
select 'alter user '||username||' identified by values '''||password||''' account lock;'
from dba_users
where username = upper('&ow');
prompt

prompt
prompt spool off
prompt

spool off

set verify on feed on head on
