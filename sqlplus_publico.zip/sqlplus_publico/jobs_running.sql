set verify off

SELECT * FROM dba_jobs_running;

set verify on
