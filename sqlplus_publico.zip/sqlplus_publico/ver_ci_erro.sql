
accept periodo_particao prompt '       Entrar periodo_particao : '


 select 'analyze TABLE ' || TABLE_OWNER || '.' || table_name || ' partition (' || partition_name || ') estimate  statistics;'
      from all_tab_partitions
     where table_NAME IN
           ('IND_CLIENTE', 'OSD_INSTALACAO', 'OSD_CLIENTE_INSTALACAO')
       and partition_name like UPPER('%&periodo_particao%')
 ;


    select 'analyze index ' || INDEX_OWNER || '.' || index_name || '  partition (' || partition_name || ') estimate  statistics;'
      from all_ind_partitions
     where index_name in
           (select index_name
              from all_indexes
             where table_name in
                   ('OSD_INSTALACAO', 'OSD_CLIENTE_INSTALACAO', 'IND_CLIENTE'))
       and partition_name like UPPER('%&periodo_particao%')
;

