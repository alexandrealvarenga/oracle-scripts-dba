set term off
store set %temp%\sqlenv replace
set term on
rem #####################################################################
rem
rem Name:   rbs.sql
rem Author: Bernard van Aalst
rem Date:   05-01-2000
rem Purpose:   Show all rollback segments, including their:
rem      - Size
rem      - Optimal size
rem      - Nr. of extents, max extents, size of next extent
rem      - Being Public or Private
rem      - Nr. of active transactions
rem
rem #####################################################################

set feed on
BREAK ON tablespace_name
COL tablespace_name FOR A12 heading 'Tablespace'
COL segment_name    FOR A10 heading 'Segment'
COL pub             FOR A3  heading 'Pub|lic'
COL status          FOR A8  heading 'Status'
COL extents         FOR A4  heading '#|ext'
COL max_extents     FOR A6  heading 'Max #|ext'
COL next_extent     FOR A6  heading 'Next|ext'
COL xacts           FOR A4  heading 'Act|tx'
COL optsize         FOR A7  heading 'Optimal|size'
PROMPT Rollback segments (sizes in Mb)
select rbs.tablespace_name
,      rbs.segment_name
,      DECODE( rbs.owner, 'PUBLIC', ' Y ', ' N ') "Pub"
,      rbs.status
,      TO_CHAR( rst.xacts, 999) xacts
,      TO_CHAR( smt.bytes / 1048576, 99999.9) "Size"
,      TO_CHAR( rst.optsize / 1048576, 9999.9) optsize
,      TO_CHAR( rbs.next_extent / 1048576, 999.9) next_extent
,      TO_CHAR( smt.extents, 999) extents
,      DECODE( SIGN( rbs.max_extents - 10000)
             , 1, ' Unltd'
             , TO_CHAR( rbs.max_extents, 99999)
             ) max_extents
from   dba_rollback_segs rbs
,      dba_segments smt
,      v$rollname rnm
,      v$rollstat rst
where  rbs.segment_name = rnm.name
and    rbs.segment_name = smt.segment_name
and    smt.segment_type = any ('ROLLBACK', 'TYPE2 UNDO')
and    rnm.usn = rst.usn
order by 1
/
cl bre
cl col
@%temp%\sqlenv.sql
set term on;