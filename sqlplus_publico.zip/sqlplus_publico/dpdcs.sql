set verify off
set lines 400

accept l_owner prompt 'Owner: '
accept l_name prompt 'Name: '
accept l_type prompt 'Type: '

col ref_object for a80
col referenced_type for a30
col referenced_link_name for a30
col dependency_type for a15

with my_deps as (
    select /*+ materialize */ owner, name, type, referenced_owner, referenced_name, referenced_type, referenced_link_name, dependency_type
    from dba_dependencies
) 
select lpad(' ', (level-1)*3)||referenced_owner||'.'||referenced_name ref_object, referenced_type, referenced_link_name, dependency_type
from my_deps
start with owner = upper('&l_owner') and name = upper('&l_name') and type = upper('&l_type')
connect by nocycle prior referenced_name = name and prior referenced_owner = owner and prior referenced_type = type
order siblings by owner, name, type;

undef l_owner l_name l_type
clear columns
