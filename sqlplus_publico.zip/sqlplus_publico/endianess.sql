col platform_name for a50
col endian_format for a15
select d.platform_name, endian_format
from v$transportable_platform tp, v$database d
where tp.platform_name = d.platform_name
/
