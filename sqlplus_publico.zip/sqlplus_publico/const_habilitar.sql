set verify off

accept   vo prompt 'Informe o owner das entidades: '

spool C:\temp\const_&vo._habilitar.log

prompt    "Enable de constaints FK"
select   'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' ENABLE CONSTRAINT '||CONSTRAINT_NAME||';' c1
from     dba_constraints
where    owner = upper('&Vo')
and      constraint_type = 'R'
/

spool off;
undef vo
set verify on;
