SELECT lh.inst_id inst_lock, lh.SID sid_lock,
       lw.inst_id inst_wait, lw.SID sid_wait,
       DECODE (lh.TYPE,
               'MR', 'Media_recovery',
               'RT', 'Redo_thread',
               'UN', 'User_name',
               'TX', 'Transaction',
               'TM', 'Dml',
               'UL', 'PLSQL User_lock',
               'DX', 'Distrted_Transaxion',
               'CF', 'Control_file',
               'IS', 'Instance_state',
               'FS', 'File_set',
               'IR', 'Instance_recovery',
               'ST', 'Diskspace Transaction',
               'IV', 'Libcache_invalidation',
               'LS', 'LogStaartORswitch',
               'RW', 'Row_wait',
               'SQ', 'Sequence_no',
               'TE', 'Extend_table',
               'TT', 'Temp_table',
               'Nothing-'
              ) waiter_lock_type,
       DECODE (lw.request,
               0, 'None',
               1, 'NoLock',
               2, 'Row-Share',
               3, 'Row-Exclusive',
               4, 'Share-Table',
               5, 'Share-Row-Exclusive',
               6, 'Exclusive',
               'Nothing-'
              ) waiter_mode_req
FROM   gv$lock lw, gv$lock lh
WHERE  lh.id1 = lw.id1
AND    lh.id2 = lw.id2
AND    lh.request = 0
AND    lw.lmode = 0
AND    (lh.id1, lh.id2) IN (
                           SELECT id1, id2
                           FROM   gv$lock
                           WHERE  request = 0
                           INTERSECT
                           SELECT id1, id2
                           FROM   gv$lock
                           WHERE  lmode = 0);
