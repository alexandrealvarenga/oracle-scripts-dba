set feed off

COLUMN APPLY_NAME HEADING 'Apply|Process Name' FORMAT A20
COLUMN SOURCE_DATABASE HEADING 'Source|Database' FORMAT A15
COLUMN APPLIED_MESSAGE_NUMBER HEADING 'Applied|Message' FORMAT 999999999999999999
COLUMN OLDEST_MESSAGE_NUMBER HEADING 'Oldest|Message|Number' FORMAT 999999999999999999
COLUMN APPLY_TIME HEADING 'Apply Time' FORMAT A30
COLUMN APPLIED_MESSAGE_CREATE_TIME HEADING 'Applied Message|Create Time' FORMAT A20
COLUMN OLDEST_TRANSACTION_ID HEADING 'Oldest|Transaction ID' FORMAT A22
COLUMN STATUS FOR a10

select p.APPLY_NAME,
       a.STATUS,
       p.SOURCE_DATABASE,
       p.APPLIED_MESSAGE_NUMBER,
       p.OLDEST_MESSAGE_NUMBER,
       p.APPLY_TIME,
       p.APPLIED_MESSAGE_CREATE_TIME,
       p.OLDEST_TRANSACTION_ID
from dba_apply_progress p
join dba_apply a on a.apply_name = p.apply_name
order by a.status desc,p.apply_name;

column SID Heading 'Session|ID' format 9999999
column HWM_MESSAGE_NUMBER Heading 'High-Watermark|Message|Number' format 99999999999999999
column HWM_MESSAGE_CREATE_TIME Heading 'High-Watermark|Message|Create Time' format A20
column LWM_MESSAGE_NUMBER Heading 'Low-Watermark|Message|Number' format 99999999999999999
column LWM_MESSAGE_CREATE_TIME Heading 'Low-Watermark|Message|Create Time' format A20
column HWM_TIME Heading 'High-Watermark|Time' format A20
column LWM_TIME Heading 'Low-Watermark|Time' format A20
column STARTUP_TIME Heading 'Startup Time' format 99999999999999999
column ELAPSED_SCHEDULE_TIME Heading 'Elapsed Schedule|Time (Seconds)' format 99999999999999999

select SID,
       SERIAL#,
       STATE,
       APPLY#,
       APPLY_NAME,
       TOTAL_APPLIED,
       TOTAL_WAIT_DEPS,
       TOTAL_WAIT_COMMITS,
       TOTAL_ADMIN,
       TOTAL_ASSIGNED,
       TOTAL_RECEIVED,
       TOTAL_IGNORED,
       TOTAL_ROLLBACKS,
       TOTAL_ERRORS,
       LWM_TIME,
       LWM_MESSAGE_NUMBER,
       LWM_MESSAGE_CREATE_TIME,
       HWM_TIME,
       HWM_MESSAGE_NUMBER,
       HWM_MESSAGE_CREATE_TIME,
       STARTUP_TIME,
       ELAPSED_SCHEDULE_TIME/100 ELAPSED_SCHEDULE_TIME
from gv$streams_apply_coordinator;

set feedback on

-- SID                      NUMBER          Session ID of the coordinator's session
-- SERIAL#                  NUMBER          Serial number of the coordinator's session
-- STATE                    VARCHAR2(21)    State of the coordinator:
-- APPLY#                   NUMBER          Apply process number. An apply process is an Oracle background process, prefixed by ap.
-- APPLY_NAME               VARCHAR2(30)    Name of the apply process
-- TOTAL_APPLIED            NUMBER          Total number of transactions applied by the apply process since the apply process was last started
-- TOTAL_WAIT_DEPS          NUMBER          Number of times since the apply process was last started that an apply server waited to apply a logical change record (LCR) in a transaction until another apply server applied a transaction because of a dependency between the transactions
-- TOTAL_WAIT_COMMITS       NUMBER          Number of times since the apply process was last started that an apply server waited to commit a transaction until another apply server committed a transaction to serialize commits
-- TOTAL_ADMIN              NUMBER          Number of administrative jobs issued since the apply process was last started
-- TOTAL_ASSIGNED           NUMBER          Number of transactions assigned to apply servers since the apply process was last started
-- TOTAL_RECEIVED           NUMBER          Total number of transactions received by the coordinator process since the apply process was last started
-- TOTAL_IGNORED            NUMBER          Number of transactions which were received by the coordinator but were ignored because they had been previously applied
-- TOTAL_ROLLBACKS          NUMBER          Number of transactions which were rolled back due to unexpected contention
-- TOTAL_ERRORS             NUMBER          Number of transactions applied by the apply process that resulted in an apply error since the apply process was last started
-- LWM_TIME                 DATE            Time when the message with the lowest message number was recorded. The creation time of the message with the lowest message number was also recorded at this time.
-- LWM_MESSAGE_             NUMBER          Number of the message corresponding to the low-watermark. That is, messages with a commit message number less than or equal to this message number have definitely been applied, but some messages with a higher commit message number also may have been applied.
-- LWM_MESSAGE_CREATE_TIME  DATE            For captured messages, creation time at the source database of the message corresponding to the low-watermark. For user-enqueued messages, time when the message corresponding to the low-watermark was enqueued into the queue at the local database.
-- HWM_TIME                 DATE            Time when the message with the highest message number was recorded. The creation time of the message with the highest message number was also recorded at this time.
-- HWM_MESSAGE_NUMBER       NUMBER          Number of the message corresponding to the high-watermark. That is, no messages with a commit message number greater than this message number have been applied.
-- HWM_MESSAGE_CREATE_TIME  DATE            For captured messages, creation time at the source database of the message corresponding to the high-watermark. For user-enqueued messages, time when the message corresponding to the high-watermark was enqueued into the queue at the local database.
-- STARTUP_TIME             DATE            Time when the apply process was last started
-- ELAPSED_SCHEDULE_TIME    NUMBER          Time elapsed (in hundredths of a second) scheduling messages since the apply process was last started

