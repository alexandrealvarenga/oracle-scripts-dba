SET HEADING OFF term on autotrace off timing off

-- alter session set tracefile_identifier=LUCAS_stats;
-- alter session set events '10053 trace name context forever, level 1';

-- alter session set sqltune_category=LUCAS;

EXPLAIN PLAN SET STATEMENT_ID = 'LUCAS' into SYS.PLAN_TABLE$ FOR
WITH FIRST_ZONA_VA AS
  (SELECT T.ID, CZ.VALUE CLASSIFICACAO_ZONA, z.nome NOME_LIMITE_ZONA, z.tipo, ROW_NUMBER() over (partition BY t.id
                                                                                                 ORDER BY t.id) rn
   FROM NOVOSIT_MAPPING_ELETRICIDADE.ET_TOWER t
   LEFT JOIN NOVOSIT_MAPPING_LANDBASE.LB_ZONA Z ON SDO_ANYINTERACT(Z.LIMITE,T.LOCATION) = 'TRUE'
   LEFT JOIN NOVOSIT_MAPPING_LANDBASE.ENUM_CLASSIFICACAO_ZONA CZ ON z.classificacao = CZ.STORED_VALUE
   WHERE T.LOCATION IS NOT NULL),
     FIRST_BAIRRO AS
  (SELECT T.ID,
          B.CODIGO,
          B.NOME,
          ROW_NUMBER() over (partition BY t.id
                             ORDER BY t.id) rn
   FROM NOVOSIT_MAPPING_ELETRICIDADE.ET_TOWER t
   LEFT JOIN NOVOSIT_MAPPING_LANDBASE.LB_BAIRRO B ON SDO_ANYINTERACT(B.LIMITE,T.LOCATION) = 'TRUE'),
     AREA_PRESERVACAO AS
  (SELECT T.ID,
          p.id area_id ,
               p.nome,
               ROW_NUMBER() over (partition BY t.id
                                  ORDER BY t.id) rn
   FROM NOVOSIT_MAPPING_ELETRICIDADE.ET_TOWER T
   LEFT JOIN NOVOSIT_MAPPING_LANDBASE.LB_AREA_PRESERVACAO P ON SDO_ANYINTERACT(p.LIMITE,T.LOCATION) = 'TRUE')
SELECT T.ID,
       r.nome REGIONAL,
       m.codigo COD_MUNICIPIO,
       m.nome NOME_MUNICIPIO,
       Z.NOME_LIMITE_ZONA,
       CASE z.tipo
           WHEN 1 THEN 'URBANO'
           ELSE 'RURAL'
       END TIPO_ZONA,
       Z.CLASSIFICACAO_ZONA,
       p.area_id AREA_PRES_AMB,
       l.id AREA_REST_LEGAL,
       h.id AREA_PAT_HIS,
       SDO_GEOM.SDO_CENTROID(T.LOCATION, 0.005).SDO_POINT.x COORDENADA_X,
       SDO_GEOM.SDO_CENTROID(T.LOCATION, 0.005).SDO_POINT.y COORDENADA_Y,
       ba.codigo COD_BAIRRO,
       ba.nome NOME_BAIRRO,
       t.edp_installation_local LOCAL_INSTALACAO_SAP,
       T.EDP_NGE NGE,
       T.EDP_OLD_NUMBER NUMERACAO_ANTIGA,
       TT.CODE TIPO_DE_TORRE,
       TT.TOWER_TYPE TIPO_TORRE,
       TT.MATERIAL_TYPE TIPO_MATERIAL,
       TT.Effort ESFORCO,
       TT.HEIGHT ALTURA,
       T.EDP_COD_CAT_TECHNICAL_TYPE TIPO_TECNICO,
       T.EDP_COD_CAT_BASE_TYPE TIPO_BASE,
       T.EDP_COD_CAT_CONDUCTOR_FIXATION TIPO_FIXACAO_CONDUTOR,
       T.EDP_COD_CAT_ARRESTER_FIXATION TIPO_FIXACAO_PARA_RAIOS,
       CASE t.edp_vandalism_area_
           WHEN '1' THEN 'Sim'
           ELSE 'N�o'
       END AREA_VANDALISMO,
       t.EDP_CONFIG1_AV CONFIG_CADEIAS_1_3_AVANTE,
       T.EDP_CONFIG2_AV CONFIG_CADEIAS_2_4_AVANTE,
       T.EDP_CONFIG1_RE CONFIG_CADEIAS_1_3_RE,
       T.EDP_CONFIG2_RE CONFIG_CADEIAS_2_4_RE,
       T.EDP_GLASS_QTT QTD_ISOLADOR_VIDRO,
       T.EDP_PORCELAIN_QTT QTD_ISOLADOR_POLIMERICO,
       T.EDP_PORCELAIN_QTT QTD_ISOLADOR_PORCELANA,
       CASE OWT.VALUE
           WHEN 'Pr�prio' THEN 'S'
           ELSE 'N'
       END PROPRIEDADE_EMPRESA,
       T.OWNER_NAME PROPRIETARIO,
       T.EDP_ANEEL_CONJ CONJUNTO_ANEEL,
       T.EDP_ANEEL_CODE CODIGO_ANEEL,
       T.EDP_NUMBER NUMERO,
       T.SPAN_AHEAD VAO_PARA_FRENTE,
       T.SPAN_BACK VAO_PARA_TRAS,
       T.DATE_INSTALLED DATA_INSTALACAO,
       T.location_description LOCAL_REFERENCIA,
       T.REMARKS OBSERVACOES,
       ET.QTDE_NO_ESTRUTURAL_TRANSM,
       ED.QTDE_NO_ESTRUTURAL_DISTR,
       USU.QTDE_USO_MUTUO,
       SDO_GEOM.SDO_CENTROID(SDO_CS.TRANSFORM(T.LOCATION, 0.005, 4326), 0.005).SDO_POINT.X COORDENADA_X_LATLONG,
       SDO_GEOM.SDO_CENTROID(SDO_CS.TRANSFORM(T.LOCATION, 0.005, 4326), 0.005).SDO_POINT.Y COORDENADA_Y_LATLONG,
       TO_NUMBER((TO_char(ADD_MONTHS(SYSDATE, -1),'MM')),'99') AS "MES",
       TO_NUMBER((TO_char(ADD_MONTHS(SYSDATE, -1),'YYYY')),'9999') AS "ANO"
FROM NOVOSIT_MAPPING_ELETRICIDADE.ET_TOWER T
JOIN NOVOSIT_MAPPING_ELETRICIDADE.EDP_CAT_TOWER_TYPE TT ON UPPER(t.EDP_COD_CAT_TOWER_TYPE) = TT.CODE
LEFT JOIN NOVOSIT_MAPPING_LANDBASE.lb_regional r ON SDO_ANYINTERACT(r.limite, t.location) = 'TRUE'
LEFT JOIN NOVOSIT_MAPPING_LANDBASE.lb_municipio m ON SDO_ANYINTERACT(m.LIMITE, t.location) = 'TRUE'
LEFT JOIN FIRST_ZONA_VA Z ON Z.ID = T.ID
AND Z.RN=1
LEFT JOIN AREA_PRESERVACAO P ON P.ID = T.ID
AND p.rn = 1
LEFT JOIN NOVOSIT_MAPPING_LANDBASE.lb_area_restricao_legal l ON SDO_ANYINTERACT(l.LIMITE, t.location) = 'TRUE'
LEFT JOIN NOVOSIT_MAPPING_LANDBASE.lb_patrimonio_historico h ON SDO_ANYINTERACT(h.area, t.location) = 'TRUE'
LEFT JOIN FIRST_BAIRRO BA ON BA.ID = T.ID
AND BA.RN = 1
JOIN NOVOSIT_MAPPING_ELETRICIDADE.ENUM_ED_OWNER OWT ON T.OWNER_TYPE = OWT.STORED_VALUE
LEFT JOIN
  (SELECT ET.fk_et_tower,
          COUNT(*) QTDE_NO_ESTRUTURAL_TRANSM
   FROM NOVOSIT_MAPPING_ELETRICIDADE.ET_STRUCTURE_NODE ET
   GROUP BY ET.fk_et_tower) ET ON T.ID = ET.fk_et_tower
LEFT JOIN
  (SELECT Ed.Fk_Et_Tower,
          Count(*) Qtde_No_Estrutural_Distr
   FROM Novosit_Mapping_Eletricidade.Ed_Structure_Node Ed
   GROUP BY Ed.Fk_Et_Tower) Ed ON Ed.Fk_Et_Tower = T.Id
LEFT JOIN
  (SELECT ED.fk_et_tower,
          COUNT(*) QTDE_USO_MUTUO
   FROM NOVOSIT_MAPPING_ELETRICIDADE.ET_FOREIGN_ATTACHMENT ED
   GROUP BY Ed.Fk_Et_Tower) Usu ON Usu.Fk_Et_Tower = T.Id
/


-- alter session set events '10053 trace name context off';



SELECT * FROM TABLE(dbms_xplan.display('SYS.PLAN_TABLE$', 'LUCAS', 'ADVANCED ALLSTATS LAST -PROJECTION'));
rollback;

-- SELECT LPAD( ' ', 2 * (level-1)) ||
--   operation                                                           ||
--   DECODE( options,      NULL, '', ' (' || options || ') of'         ) ||
--   DECODE( object_owner, NULL, '', ' '  || object_owner || '.'       ) ||
--   DECODE( object_name,  NULL, '',         object_name               ) ||
--   DECODE( object_type,  NULL, '', ' (' || object_type || ')'        ) ||
--   DECODE( cost,         NULL, '', ' cost=' || TO_CHAR( cost)        ) ||
--   DECODE( cardinality,  NULL, '', ' rows=' || TO_CHAR( cardinality) ) q_plan
-- FROM plan_table
-- WHERE statement_id = 'c0135418'
-- CONNECT BY PRIOR id = parent_id
-- AND statement_id = 'c0135418'
-- START WITH id = 1
-- ORDER BY id
-- /
-- ROLLBACK
-- /
SET HEADING ON

