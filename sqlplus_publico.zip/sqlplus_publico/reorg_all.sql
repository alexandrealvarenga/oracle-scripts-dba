----------------------------------------------------------
-- Levantamento de tabelas com necessidade de reorg
-- 
--
-- Criado por: Alexandre Soares (c0092973@vale.com) - 23/08/2012
-- Alteracoes:
-- 	19/09/2012 - Lucas Lellis - lucas.lellis@accenture.com
--					- Parametros de input
--					- Geracao de relatorio
--					- Ordenacao por blocos FS4
--					- Inclusao do TABLE PARTITION
--					- Inclusao dos comandos de shrink
----------------------------------------------------------

set serveroutput on echo off feed off verify off

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

accept sz prompt 'Informe o tamanho m�nimo dos objetos (MB - def = 100): '
prompt

spool %temp%\reorg_all_&wdt..txt


DECLARE
    TYPE t_storage IS RECORD (
    	l_free_blks          NUMBER,
		l_total_blocks       NUMBER,
		l_total_bytes        NUMBER,
		l_unused_blocks      NUMBER,
		l_unused_bytes       NUMBER,
		l_lastusedextfileid  NUMBER,
		l_lastusedextblockid NUMBER,
		l_last_used_block    NUMBER,
		l_segment_space_mgmt VARCHAR2(255),
		l_unformatted_blocks NUMBER,
		l_unformatted_bytes  NUMBER,
		l_fs1_blocks         NUMBER,
		l_fs1_bytes          NUMBER,
		l_fs2_blocks         NUMBER,
		l_fs2_bytes          NUMBER,
		l_fs3_blocks         NUMBER,
		l_fs3_bytes          NUMBER,
		l_fs4_blocks         NUMBER,
		l_fs4_bytes          NUMBER,
		l_full_blocks        NUMBER,
		l_full_bytes         NUMBER,
		c_tab                VARCHAR2(50),
    	c_own                VARCHAR2(50),
    	c_seg_type				VARCHAR2(30),
    	c_part_name				VARCHAR2(30)
    );
    
    TYPE tab_storage IS TABLE OF t_storage;
    
    v_info_storage tab_storage := tab_storage();
    r_info_storage t_storage;
    
    i				number := 0;
    min_size 	number := 100;
    teste 		boolean := false;
    
    -- inline procedure to print out numbers nicely formatted
    -- with a simple label
    PROCEDURE p(p_label IN VARCHAR2,
                p_num   IN NUMBER) IS
    BEGIN
        dbms_output.put_line(rpad(p_label, 40, '.') || to_char(p_num, 'fm999G999G999G999D00'));
    END;

	 PROCEDURE insort_desc(p_storage_info_col IN OUT tab_storage, p_storage IN t_storage) IS
	 	 i number := 1;
	 BEGIN
	 	 p_storage_info_col.extend;
	 	 
	 	 i := p_storage_info_col.count - 1;
		 		
		 while (i > 0) and (p_storage_info_col(i).l_fs4_blocks < p_storage.l_fs4_blocks) loop
		 	p_storage_info_col(i+1) := p_storage_info_col(i);
		 	i := i - 1;
		 end loop;
		 p_storage_info_col(i+1) := p_storage;
	 END;

    -- Test statements here
BEGIN
	 if (trim('&sz') is null) then
		 min_size := 100;
	 else
		 min_size := '&sz';
	 end if;

	 FOR c_tabelas IN (SELECT owner
                            ,segment_name
                            ,partition_name
                            ,segment_type
                        FROM dba_segments
                        where segment_type IN ('TABLE', 'TABLE PARTITION')
                        and bytes/1024/1024 > nvl(min_size,'100'))
    LOOP
        BEGIN
            r_info_storage.c_tab := c_tabelas.segment_name;
				r_info_storage.c_own := c_tabelas.owner;
				r_info_storage.c_seg_type := c_tabelas.segment_type;
				r_info_storage.c_part_name := c_tabelas.partition_name;
				
				select ts.segment_space_management
				into r_info_storage.l_segment_space_mgmt
				from dba_segments seg, dba_tablespaces ts
				where seg.segment_name = r_info_storage.c_tab
				and (seg.partition_name = r_info_storage.c_part_name or r_info_storage.c_part_name is null)
				and seg.owner = r_info_storage.c_own
				and segment_type IN ('TABLE', 'TABLE PARTITION')
				and seg.tablespace_name = ts.tablespace_name;
				
				IF r_info_storage.l_segment_space_mgmt = 'AUTO'  THEN
				    dbms_space.space_usage(r_info_storage.c_own, r_info_storage.c_tab, r_info_storage.c_seg_type, r_info_storage.l_unformatted_blocks, 
				                           r_info_storage.l_unformatted_bytes, r_info_storage.l_fs1_blocks, r_info_storage.l_fs1_bytes, 
				                           r_info_storage.l_fs2_blocks, r_info_storage.l_fs2_bytes, r_info_storage.l_fs3_blocks, 
				                           r_info_storage.l_fs3_bytes, r_info_storage.l_fs4_blocks,
				                           r_info_storage.l_fs4_bytes, r_info_storage.l_full_blocks, r_info_storage.l_full_bytes, r_info_storage.c_part_name);
				ELSE
				    dbms_space.free_blocks(segment_owner => r_info_storage.c_own, segment_name => r_info_storage.c_tab, segment_type => r_info_storage.c_seg_type, freelist_group_id => 0, free_blks => r_info_storage.l_free_blks);
				END IF;
				-- and then the unused space API call to get the rest of the
				-- information
				dbms_space.unused_space(segment_owner => r_info_storage.c_own, segment_name => r_info_storage.c_tab, segment_type => r_info_storage.c_seg_type, 
				       total_blocks => r_info_storage.l_total_blocks, 
				       total_bytes => r_info_storage.l_total_bytes,unused_blocks => r_info_storage.l_unused_blocks, 
				       unused_bytes => r_info_storage.l_unused_bytes, last_used_extent_file_id => r_info_storage.l_lastusedextfileid, 
				       last_used_extent_block_id => r_info_storage.l_lastusedextblockid,
                   last_used_block => r_info_storage.l_last_used_block, partition_name=>r_info_storage.c_part_name);

				insort_desc(v_info_storage, r_info_storage);
							
       END;      
    END LOOP;
    
    IF v_info_storage.count > 0 THEN
		 FOR i in v_info_storage.first..v_info_storage.last
		 LOOP
				dbms_output.put_line('---------------------------------------------------------------------------');
				dbms_output.put_line('SEGMENT_NAME ---> ' || v_info_storage(i).c_tab);
				dbms_output.put_line('SEGMENT_TYPE ---> ' || v_info_storage(i).c_seg_type);
				IF v_info_storage(i).c_part_name is not null THEN
					dbms_output.put_line('PARTITION_NAME ---> ' || v_info_storage(i).c_part_name);
				END IF;
				p('Unformatted Blocks ', v_info_storage(i).l_unformatted_blocks);
				p('FS1 Blocks (0-25) ', v_info_storage(i).l_fs1_blocks);
				p('FS2 Blocks (25-50) ', v_info_storage(i).l_fs2_blocks);
				p('FS3 Blocks (50-75) ', v_info_storage(i).l_fs3_blocks);
				p('FS4 Blocks (75-100)', v_info_storage(i).l_fs4_blocks);
				p('Full Blocks ', v_info_storage(i).l_full_blocks);                
				p('Free Blocks (MSSM)', v_info_storage(i).l_free_blks);
				p('Total Blocks', v_info_storage(i).l_total_blocks);
				p('Total Bytes', v_info_storage(i).l_total_bytes);
				p('Total MBytes', trunc(v_info_storage(i).l_total_bytes / 1024 / 1024));
				p('Unused Blocks', v_info_storage(i).l_unused_blocks);
				p('Unused Bytes', v_info_storage(i).l_unused_bytes);
				p('Last Used Ext FileId', v_info_storage(i).l_lastusedextfileid);
				p('Last Used Ext BlockId', v_info_storage(i).l_lastusedextblockid);
				p('Last Used Block', v_info_storage(i).l_last_used_block);

				dbms_output.put_line(chr(13));
				IF v_info_storage(i).c_seg_type = 'TABLE' THEN
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' enable row movement;');
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' shrink space compact;');
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' shrink space;');
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' disable row movement;');
				ELSIF v_info_storage(i).c_seg_type = 'TABLE PARTITION' THEN
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' enable row movement;');
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' modify partition '||v_info_storage(i).c_part_name||' shrink space compact;');
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' modify partition '||v_info_storage(i).c_part_name||' shrink space;');
					dbms_output.put_line('alter table '||v_info_storage(i).c_own||'.'||v_info_storage(i).c_tab||' disable row movement;');
				END IF;
		 END LOOP;
	 ELSE
	 	 dbms_output.put_line('Nao ha tabelas acima de '||min_size||'MB');
	 END IF;
END;
/

spool off

prompt
prompt ed %temp%\reorg_all_&wdt..txt
prompt
