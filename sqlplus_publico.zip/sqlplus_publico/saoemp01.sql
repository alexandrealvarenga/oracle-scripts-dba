--
-- Lucas Pimentel Lellis 
-- conecta � inst�ncia com usu�rio SAOEMP01.
-- Data: 01/06/2011
-- Adaptado do script criado por Geovani Mazioli
--

SET ECHO OFF

col owner       for a15
col object_name     for a30
col SUBOBJECT_NAME  for a10
col OBJECT_ID       for 9999999
col DATA_OBJECT_ID  for 9999999
col OBJECT_TYPE     for a15
col CREATED     for a8
col LAST_DDL        for a8
col TIMESTAMP       for a20
col STATUS      for a10


set term off

conn saoemp01/WmATmj.444ASacc@&1
undef 1

SET LINESIZE 1000
SET LONG 10000
SET PAGESIZE 50000

SET TERM ON FEED ON

@@banner.sql

@@instancia.sql

SET FEEDBACK ON