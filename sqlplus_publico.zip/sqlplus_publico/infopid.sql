set verify off echo off
col program for a40
col terminal for a30

accept v_pid prompt 'PID: '

select s.sid, s.serial#, s.username, s.sql_id, s.program, s.terminal, s.osuser
from v$session s
join v$process p on p.addr = s.paddr
where to_number(spid) = &v_pid;
