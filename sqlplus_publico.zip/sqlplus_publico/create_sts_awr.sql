------------------------------------------------------------------------
-- Cria um SQL Tuning Set com os (n) piores SQLs de um usuario no
-- AWR ordenado por elapsed_time total
--
-- Criado por: Lucas Lellis - lucas.lellis@dxc (06/02/2019)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

set verify off feed off echo off lines 200 serveroutput on size 1000000

set pages 10

select snap_id, to_char(BEGIN_INTERVAL_TIME, 'DD/MM/YYYY HH24:MI') "Snap Started"
from dba_hist_snapshot
where INSTANCE_NUMBER = sys_context('userenv', 'instance')
and dbid = (select dbid from v$database)
order by snap_id;

accept usernm prompt 'Username: '
accept qtd_sql prompt 'Qtd de SQLs: '
accept snap_ini prompt 'Snapshot inicial: '
accept snap_fim prompt 'Snapshot final: '

col epoch_time new_val w_epoch_time noprint

-- Ref: http://shafiqissani.wordpress.com/2010/09/30/how-to-get-the-current-epoch-time-unix-timestamp/
SELECT trim(trunc((SYSDATE - TO_DATE('01-01-1970 00:00:00', 'DD-MM-YYYY HH24:MI:SS')) * 24 * 60 * 60)) epoch_time
FROM DUAL;

DECLARE
    l_cursor    DBMS_SQLTUNE.sqlset_cursor;
    l_usernm    varchar2(256) := upper('&usernm');
    l_qtd_sql   integer := &qtd_sql;
    l_snap_ini  integer := &snap_ini;
    l_snap_fim  integer := &snap_fim;
BEGIN
    if (l_usernm = '' or l_usernm is null) or
       (l_qtd_sql = '' or l_qtd_sql is null) or
       (l_snap_ini = '' or l_snap_ini is null) or
       (l_snap_fim = '' or l_snap_fim is null) then
       dbms_output.put_line('Parametro(s) nao informado(s)');
    else
        DBMS_SQLTUNE.create_sqlset(sqlset_name => 'STS_&w_epoch_time');

        OPEN l_cursor FOR
            SELECT VALUE(a)
            FROM   TABLE(
                DBMS_SQLTUNE.SELECT_WORKLOAD_REPOSITORY(
                    begin_snap     => l_snap_ini,
                    end_snap       => l_snap_fim,
                    basic_filter   => 'parsing_schema_name = upper('''||l_usernm||''')',
                    attribute_list => 'ALL',
                    result_limit   => l_qtd_sql,
                    ranking_measure1 => 'elapsed_time',
                    ranking_measure2 => 'executions',
                    recursive_sql    => 'NO_RECURSIVE_SQL')
                ) a;

        DBMS_SQLTUNE.load_sqlset(sqlset_name     => 'STS_&w_epoch_time',
                                 populate_cursor => l_cursor);

        dbms_output.put_line(chr(10)||'STS Criado: STS_&w_epoch_time'||chr(10)||chr(10));
    end if;
END;
/

select created, statement_count
from user_sqlset
where name = 'STS_&w_epoch_time';

@%temp%\sqlenv
prompt
