store set %temp%\sqlenv replace

set echo off head off feed off verify off

accept v_tab prompt 'Tabela: '

column drop_cmd format a80

select 'drop index '||i.owner||'.'||i.index_name||';' drop_cmd
from dba_indexes i
where i.table_name like upper('&v_tab')
and i.index_name not in (
	select c.constraint_name
	from dba_constraints c
	where i.index_name = c.constraint_name
	and c.constraint_type = 'P'
	and c.owner = i.owner)
order by i.owner, i.index_name;

prompt

undef v_tab

@%temp%\sqlenv.sql