set verify off

accept DIR prompt 'Diretorio dos scripts: '
accept V_OWNER prompt 'Owner: '

spool "&DIR\drop_objects_&V_OWNER..sql"

prompt spool "&DIR\drop_objects_&V_OWNER..log"
prompt

SET SERVEROUTPUT ON SIZE 1000000 FEED OFF
BEGIN
	FOR c_obj IN (SELECT owner, synonym_name
		              FROM dba_synonyms
		              WHERE table_owner = upper('&V_OWNER')
		              ORDER BY synonym_name) LOOP
			IF c_obj.owner = 'PUBLIC' THEN
				dbms_output.put_line('drop public synonym '||c_obj.synonym_name||';');
			ELSE
				dbms_output.put_line('drop synonym '||c_obj.owner||'.'||c_obj.synonym_name||';');
			END IF;
		              
	END LOOP;
	
	FOR c_obj IN (SELECT owner, object_name, object_type 
				  FROM   dba_objects
				  WHERE  owner = upper('&V_OWNER')
				  AND object_type IN ('TABLE', 'VIEW', 'PACKAGE', 'PROCEDURE', 'FUNCTION', 'SEQUENCE')
				  ORDER BY DECODE(object_type, 'TABLE', 2, 1), object_type, object_name) LOOP
		BEGIN
			IF c_obj.object_type = 'TABLE' THEN
				dbms_output.put_line('DROP ' || c_obj.object_type || ' ' || c_obj.owner || '.' || '"' || c_obj.object_name || '" CASCADE CONSTRAINTS PURGE;');
			ELSE
				dbms_output.put_line('DROP ' || c_obj.object_type || ' ' ||c_obj.owner || '.' || '"' || c_obj.object_name || '";');
			END IF;
		END;
	END LOOP;             
END;
/

prompt
prompt spool off
prompt

SET FEED ON

spool off
