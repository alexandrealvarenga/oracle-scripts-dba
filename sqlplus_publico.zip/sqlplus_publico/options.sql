-- List features/options installed:
 col comp_id format a12
 col version format a10
 col comp_name format a40
 col status format a10
 set pages 30
 SELECT substr(comp_id,1,12)Comp_ID, Status,
  substr(Version,1,10)Version,
  substr(Comp_Name,1,40)Comp_Name
 FROM DBA_Registry
 ORDER by 1,2;
 