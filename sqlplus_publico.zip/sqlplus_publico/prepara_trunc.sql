-- ####################################################################################
-- # Script: prepara_trunc.sql
-- # Objetivo: Gerar scripts para desabilitar e habilitar as constraints de um owner,
-- # para prepar�-lo para ser truncado
-- ####################################################################################

set verify off
set head off
set pagesize 0
set linesize 500
set feedback off
accept   vo prompt 'Informe o owner das entidades: '
accept   dir prompt 'Diretorio de spool: '
set term off


spool "&dir\01_dis_cons.sql"
prompt spool "&dir\01_dis_cons.log"
prompt  --Disable constraints
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
select 'alter table '||owner||'.'||table_name||' disable constraint '||constraint_name||';'
from dba_constraints where status = 'ENABLED' and r_owner = upper('&vo') and constraint_type = 'R'
/
prompt spool off
spool off

spool "&dir\06_en_cons.sql"
prompt spool "&dir\06_en_cons.log"
prompt --Enable constraints
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
select 'alter table '||owner||'.'||table_name||' enable constraint '||constraint_name||';'
from dba_constraints where status = 'ENABLED' and r_owner = upper('&vo') and constraint_type = 'R'
/
prompt spool off
spool off

spool "&dir\02_dis_trig.sql"
prompt spool "&dir\02_dis_trig.log"
prompt --Disable triggers
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
select 'alter trigger '||owner||'.'||trigger_name||' disable;'
from dba_triggers where owner = upper('&vo')
/
prompt spool off
spool off

spool "&dir\05_en_trig.sql"
prompt spool "&dir\05_en_trig.log"
prompt --Enable triggers
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
select 'alter trigger '||owner||'.'||trigger_name||' enable;'
from dba_triggers where owner = upper('&vo')
/
prompt spool off
spool off

spool "&dir\04_gr_seq.sql"
prompt @"%SQLPATH%\reset_seq_owner.sql"
spool off

spool "&dir\03_trunc.sql"
prompt spool "&dir\03_trunc.log"
prompt --Truncates
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
select 'truncate table '||owner||'.'||table_name||';'
from dba_tables
where owner = upper('&vo')
/
prompt spool off
spool off
set term on
prompt
prompt Arquivos gerados sob o diretorio: &dir
undef vo
undef dir
set verify on
set feedback on
set head on

SELECT * FROM v$instance;

