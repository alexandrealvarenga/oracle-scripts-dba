set pagesize 0
set linesize 6000
col info format a40
break on info skip 3
accept ow prompt 'Informe o owner: '
accept dird prompt 'Informe o diretorio de destino: '

set echo on
set term off

spool &dird\&ow..sql

select name || ' - ' || type info, text
from   dba_source
where  owner = upper ('&ow')
order  by owner, name, type, line
/

spool off
undef ow

