set verify off
set head off
set pagesize 0
set linesize 500
set feedback off
accept   vo prompt 'Informe o owner das entidades: '
accept   dblink prompt 'DB Link: '
accept   vscn prompt 'SCN: '
accept   dir prompt 'Diretorio de spool: '
set term off

spool "&dir\insert.sql"

prompt ALTER SESSION SET DB_FILE_MULTIBLOCK_READ_COUNT=128;;

select 'TRUNCATE TABLE '||OWNER||'.'||TABLE_NAME||';'||CHR(10)||
		 'INSERT /*+ APPEND PARALLEL ('||TABLE_NAME||', 2) */'||CHR(10)||
       'INTO '||OWNER||'.'||TABLE_NAME||CHR(10)||
       'SELECT /*+ FULL ('||TABLE_NAME||') PARALLEL ('||TABLE_NAME||', 2) */ * '||CHR(10)||
       'FROM '||OWNER||'.'||TABLE_NAME||'@&dblink as of scn &vscn;' ||CHR(10)||
       'COMMIT;' CMD
from   dba_tables
where  owner = upper('&vo')
order  by table_name
/

spool off

set term on
prompt
prompt Arquivos gerados sob o diretorio: &dir
undef vo
undef dir
set verify on
set feedback on
set head on
