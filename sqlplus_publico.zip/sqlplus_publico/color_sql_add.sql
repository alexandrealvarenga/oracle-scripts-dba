set echo on verify on

exec dbms_workload_repository.add_colored_sql('&SQL_ID');

set echo off verify off