-- Ref.: http://www.runningoracle.com/product_info.php?products_id=330
col username for a30
col status for a30 word_wrapped
col logon for a30 word_wrapped
col osuser for a30 word_wrapped
col machine for a30 word_wrapped
col program for a30 word_wrapped
col module for a30 word_wrapped
col action for a30 word_wrapped
SELECT  r.NAME "RB Segment Name", 
        dba_seg.size_mb,
        DECODE(TRUNC(SYSDATE - LOGON_TIME), 0, NULL, TRUNC(SYSDATE - LOGON_TIME) || ' Days' || ' + ') || 
        TO_CHAR(TO_DATE(TRUNC(MOD(SYSDATE-LOGON_TIME,1) * 86400), 'SSSSS'), 'HH24:MI:SS') LOGON, 
        v$session.SID, 
        v$session.SERIAL#, 
        p.SPID, 
        v$session.process,
        v$session.USERNAME, 
        v$session.STATUS, 
        v$session.OSUSER, 
        v$session.MACHINE, 
        v$session.PROGRAM, 
        v$session.module, 
        action 
FROM v$lock l, v$process p, v$rollname r, v$session, 
    (SELECT segment_name, ROUND(bytes/(1024*1024),2) size_mb FROM dba_segments 
    WHERE segment_type = 'TYPE2 UNDO' ORDER BY bytes DESC) dba_seg 
    WHERE l.SID = p.pid(+) AND 
    v$session.SID = l.SID AND 
    TRUNC (l.id1(+)/65536)=r.usn AND 
    l.TYPE(+) = 'TX' AND 
    l.lmode(+) = 6 
    AND r.NAME = dba_seg.segment_name
    --AND v$session.username = 'SYSTEM'
    --AND status = 'INACTIVE'
ORDER BY size_mb DESC;