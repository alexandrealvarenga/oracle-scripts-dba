set lines 500 serveroutput off pages 9999 verify off head off

select *
from table(
    dbms_xplan.display_cursor(
        null,
        null,
        'ADVANCED LAST ALLSTATS -PROJECTION -ALIAS -OUTLINE'
    )
);

