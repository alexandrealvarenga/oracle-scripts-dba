set lines 180 serveroutput off pages 9999 head off

select *
from table(
    dbms_xplan.display_awr(
        '&1',
        null,
        null,
        'ADVANCED'
    )
);

set lines 1000 head on serveroutput on