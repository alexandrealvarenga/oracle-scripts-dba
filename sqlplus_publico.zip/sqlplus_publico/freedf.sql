/* freedf.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Espaco livre em cada datafile
 * Utilizacao: @freedf
 *             @freedf filesystem|tablespace
 *
 * Exemplos: @freedf
 *           @freedf /u01
 *           @freedf carga
 *
 */


break on filesystem skip page
col file_name for a80 word_wrapped
col tablespace_name for a30
col free_mb for 999G999G999G999
col occ_mb for 999G999G999G999
col total_mb for 999G999G999G999
compute sum of free_mb on filesystem
col filesystem for a30 word_wrapped

set verify off

set feed off
col sep new_val lsep noprint
select REGEXP_SUBSTR(value, '[/\]') sep from v$parameter where name = 'control_files';
set feed on

-- Defines first parameter's default value
set feed off term off
col p1 new_value 1
select null p1 from dual where  1=2;
select nvl('&1','%') p1 from dual;
set feed on term on

select substr(d.file_name, 1, instr(d.file_name, '&lsep', -1)) filesystem,
       d.tablespace_name,
       d.file_name,
       d.file_id,
       d.bytes/1024/1024 total_mb,
       d.bytes/1024/1024 - sum(f.bytes/1024/1024) occ_mb,
       sum(f.bytes/1024/1024) free_mb
from dba_data_files d
join dba_free_space f on d.file_id = f.file_id
where lower(d.file_name) like lower('&1%') or lower(d.tablespace_name) like lower('&1')
group by d.file_name, d.tablespace_name, d.file_id, d.bytes
order by filesystem, free_mb desc;

clear breaks computes columns
undef p1 lsep
undef 1
