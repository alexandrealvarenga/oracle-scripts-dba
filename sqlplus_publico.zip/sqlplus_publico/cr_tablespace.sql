set serverout on size 1000000
set head off echo off feedback off
set pagesize 0
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000

accept Tablespace prompt "Tablespace: "

set pause off
declare
    nome       dba_data_files.tablespace_name%type;
    arq        dba_data_files.file_name%type;
    tam        dba_data_files.bytes%type;
    status     dba_data_files.status%type;
    kbytes     smallint;
    ult_nome   dba_data_files.tablespace_name%type := ' ';
--
    cursor c_tbs is
      select tablespace_name,file_name,bytes,status
      from dba_data_files
      where tablespace_name = upper('&tablespace')
      order by tablespace_name;
begin
--    dbms_output.enable(50000);
--
    kbytes := 0;
--
    open c_tbs;
--
    loop
        fetch c_tbs into nome, arq, tam, status;
--
        exit when c_tbs%notfound;
--
        kbytes := tam/1024;
--
        if ult_nome <> nome then
           dbms_output.put_line('CREATE TABLESPACE '||nome||'  DATAFILE');
           dbms_output.put_line(''''||arq||''''||'  SIZE  '||kbytes||' K ONLINE; ');
        else
           dbms_output.put_line('ALTER TABLESPACE '||nome||'  ADD  DATAFILE');
           dbms_output.put_line(''''||arq||''''||'  SIZE  '||kbytes||' K ONLINE; ');
        end if;
--
        ult_nome := nome;
    end loop;
--
    close c_tbs;
end;
/

undef tablespace
