set verify off
accept usuario prompt 'Usuario: '
SELECT * FROM dba_role_privs WHERE grantee LIKE upper('%&usuario%');
