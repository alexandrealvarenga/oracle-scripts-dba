col PERCENT_USED for 999.99
select inst_id,name, 100-((free_mb/total_mb)*100) PERCENT_USED, 
       free_mb, total_mb 
from gv$asm_diskgroup;
