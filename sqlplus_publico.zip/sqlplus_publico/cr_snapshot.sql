set echo off
--
--accept Owner char prompt 'Informe o Owner dos snapshots ou tecle ENTER para todos: '
--
set linesize 80 pagesize 0 space 0
set termout off feedback off verify off heading off
set long 150000
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000

--
  SELECT 'create snapshot '||snp.owner||'.'||snp.name||CHR(10)||
         ' pctfree '||tab.pct_free||CHR(10)||
         ' pctused '||tab.pct_used||CHR(10)||
         ' initrans '||tab.ini_trans||CHR(10)||
         ' maxtrans '||tab.max_trans||CHR(10)||
         ' tablespace '||tab.tablespace_name||CHR(10)||
         ' storage(initial '||tab.initial_extent/1024||'K'||CHR(10)||
         '         next    '||tab.next_extent/1024||'K)'||CHR(10)||
         ' refresh '||snp.type||CHR(10)||
         ' with '||snp.refresh_method||CHR(10)||
         ' next '||snp.next||CHR(10)||
         ' as',
         query
  FROM dba_snapshots snp,
       dba_tables    tab
  WHERE snp.owner NOT IN ('SYS','SYSTEM')
  AND   snp.owner = tab.owner
  AND   snp.name  = SUBSTR(tab.table_name,LENGTH(snp.name)*(-1),LENGTH(snp.name))
  ORDER BY snp.owner, snp.name
/

--
undef Owner
set pagesize 20 space 1
set termout on feedback on verify on heading on
