set verify off
accept usuario prompt 'Usuario: '
accept tabela prompt 'Tabela.: '
SELECT GRANTEE,OWNER,TABLE_NAME,GRANTOR,PRIVILEGE,GRANTABLE, 'grant '||privilege||' on '||owner||'.'||table_name||' to "'||grantee||decode(grantable,'YES','" with grant option','"')||';' 
FROM dba_tab_privs 
WHERE grantee LIKE upper('%&usuario%') AND table_name LIKE upper('&tabela')
ORDER BY grantee, owner, table_name;
