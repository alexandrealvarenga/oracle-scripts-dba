set verify off
set pagesize 0
set serveroutput on size 1000000
set feedback off
set head off
set heading off
col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;
accept ow prompt "Informe o owner         : "
accept ob prompt "Informe o objeto(parte) : "
accept sg prompt "QTD de extents (>=)     : "
--spool c:\temp\alocx_&wdt._&ow..out
declare
   v_total_blocks number;
   v_total_bytes number;
   v_unused_blocks number;
   v_unused_bytes number;
   v_file_id number;
   v_block_id number;
   v_last_block number;
   v_used number;
   v_owner varchar2(32);
   v_segment varchar2(80);
   v_tablespace varchar2(80);
   v_type varchar2(80);
   v_max_extents     number;
   v_max_extents_t   varchar2(11);
   v_part_name			varchar2(30);
   w_tot_t           number;
   w_tot_b_t_a       number;
   w_tot_b_t_u       number;
   w_tot_i           number;
   w_tot_b_i_a       number;
   w_tot_b_i_u       number;
   w_reorg           varchar2(250);
   v_ext number;
   cursor table_c is
      select owner, segment_name, segment_type, extents, tablespace_name, partition_name
      from   sys.dba_segments
      where  segment_type in ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
      and    owner like upper(nvl('&ow', '%'))
      and    segment_name like upper(nvl('&ob', '%'))
      and    extents >= nvl('&sg',0)
      and    segment_name not like 'BIN$%==$0'
      order  by owner, segment_type DESC, segment_name;

   cursor index_c (p_owner varchar2, p_table varchar2) is
      select seg.owner, seg.segment_name, seg.segment_type, seg.extents, seg.tablespace_name
      from   sys.dba_segments seg
      ,      sys.dba_indexes  ind
      where  seg.segment_type  in ('INDEX', 'INDEX PARTITION', 'INDEX_SUBPARTITION')
      and    seg.owner         = ind.owner
      and    seg.segment_name  = ind.index_name
      and    ind.table_owner   = p_owner
      and    ind.table_name    = p_table
      and    segment_name not like 'BIN$%==$0'
      order  by seg.owner, seg.segment_type DESC, seg.segment_name;

begin
   w_tot_t        := 0;
   w_tot_b_t_a    := 0;
   w_tot_b_t_u    := 0;
   w_tot_i        := 0;
   w_tot_b_i_a    := 0;
   w_tot_b_i_u    := 0;
   v_total_bytes  := 0;
   v_unused_bytes := 0;
   dbms_output.put_line(chr(10)||'Owner         Type             Tablespace     Segment                            Alocado   Utilizado Percent   MAX   Extents'||chr(10)
                               ||'                                                                                (Kbytes)    (Kbytes)     (%) Extents'                );
   dbms_output.put_line(         '------------- ---------------- -------------- ------------------------------ ----------- ----------- ------- ------- -------');
   open table_c;
   fetch table_c into v_owner, v_segment, v_type, v_ext, v_tablespace, v_part_name;
   while table_c%FOUND loop
      dbms_space.unused_space(v_owner, v_segment, v_type, v_total_blocks, v_total_bytes,
                              v_unused_blocks, v_unused_bytes, v_file_id, v_block_id, v_last_block, v_part_name);
      v_used := (v_total_bytes - v_unused_bytes)/1024;
      v_max_extents   := 0;
      v_max_extents_t := 0;
      w_tot_t        := (w_tot_t) + 1;
      w_tot_b_t_a    := (w_tot_b_t_a) + (v_total_bytes);
      w_tot_b_t_u    := (w_tot_b_t_u) + (v_used);
      select   max_extents
      into     v_max_extents
      from     sys.dba_tables
      where    owner      = v_owner
      and      table_name = v_segment;
      if v_max_extents = 2147483645 then
         v_max_extents_t := ' UNLIMIT';
      else
         v_max_extents_t := to_char(v_max_extents, '9999999');
      end if;
      w_reorg := '';
      w_reorg := 'ALTER TABLE '||v_owner||'.'||v_segment||' MOVE TABLESPACE '||v_tablespace||' STORAGE (INITIAL '||trunc((v_total_bytes/1024)*1.3)||' k NEXT '||trunc((v_total_bytes/1024)*0.1)||' k PCTINCREASE 0 MINEXTENTS 1 MAXEXTENTS 121);';
--      dbms_output.put_line(w_reorg);
      w_reorg := '';
      dbms_output.put_line(rpad(v_owner, 14)                                           ||
                           rpad(v_type, 17)                                            ||
                           rpad(v_tablespace, 15)                                      ||
                           rpad(v_segment, 30)                                         ||
                           to_char(v_total_bytes/1024, '99999999999')                  ||
                           to_char(v_used, '99999999999')                              ||
                           to_char(((v_used/(v_total_bytes/1024))*100), '9999D99')     ||
                           v_max_extents_t                                             ||
                           to_char(v_ext, '9999999')                                   ||
                           w_reorg);

      open index_c (v_owner, v_segment);
      fetch index_c into v_owner, v_segment, v_type, v_ext, v_tablespace;
      while index_c%FOUND loop
         dbms_space.unused_space(v_owner, v_segment, v_type, v_total_blocks, v_total_bytes,
                                 v_unused_blocks, v_unused_bytes, v_file_id, v_block_id, v_last_block);
         v_used := (v_total_bytes - v_unused_bytes)/1024;
         v_max_extents := 0;
         w_tot_i        := (w_tot_i) + 1;
         w_tot_b_i_a    := (w_tot_b_i_a) + (v_total_bytes);
         w_tot_b_i_u    := (w_tot_b_i_u) + (v_used);
         select   max_extents
         into     v_max_extents
         from     sys.dba_indexes
         where    owner      = v_owner
         and      index_name = v_segment;
         dbms_output.put_line(rpad(v_owner, 14)                                           ||
                              rpad(v_type, 17)                                            ||
                              rpad(v_tablespace, 15)                                      ||
                              rpad(' ' ||v_segment, 30)                                   ||
                              to_char(v_total_bytes/1024, '99999999999')                  ||
                              to_char(v_used, '99999999999')                              ||
                              to_char(((v_used/(v_total_bytes/1024))*100), '9999D99')     ||
                              v_max_extents_t                                             ||
                              to_char(v_ext, '9999999')                                   );

         fetch index_c into v_owner, v_segment, v_type, v_ext, v_tablespace;
      end loop;
      close index_c;
      fetch table_c into v_owner, v_segment, v_type, v_ext, v_tablespace, v_part_name;
   end loop;
   close table_c;
   dbms_output.put_line('--------------------------------------------------------------------------------------------------------------------');
   if w_tot_b_t_a <> 0 then
      dbms_output.put_line(' *** Resumo: Tables                                                   '||to_char(w_tot_t, '999999')||to_char(w_tot_b_t_a/1024, '99999999999')||to_char(w_tot_b_t_u, '99999999999')||to_char(((w_tot_b_t_u/(w_tot_b_t_a/1024))*100), '9999D99'));
   else
      dbms_output.put_line(' *** Resumo: Tables                                                   '||to_char(0, '999999')||to_char(0, '99999999999')||to_char(0, '99999999999')||to_char(((0)*100), '9999D99'));
   end if;
   if w_tot_b_i_a <> 0 then
      dbms_output.put_line(' *** Resumo: Indexes                                                  '||to_char(w_tot_i, '999999')||to_char(w_tot_b_i_a/1024, '99999999999')||to_char(w_tot_b_i_u, '99999999999')||to_char(((w_tot_b_i_u/(w_tot_b_i_a/1024))*100), '9999D99'));
   else
      dbms_output.put_line(' *** Resumo: Indexes                                                  '||to_char(0, '999999')||to_char(0, '99999999999')||to_char(0, '99999999999')||to_char(((0)*100), '9999D99'));
   end if;
   end;
/
--undef ow
--undef ob
--undef sg
set verify on
set pagesize 50000
--set serveroutput off
set feedback on
set head on
set heading on;
