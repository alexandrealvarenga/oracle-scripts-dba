col acl for a50 word_wrapped
col host for a30

select *
from dba_network_acls
order by host, lower_port, upper_port;

col principal for a30
col start_date for a20
col end_date for a20

SELECT acl,
       principal,
       privilege,
       is_grant,
       start_date,
       end_date
FROM   dba_network_acl_privileges
order by acl, principal;

clear columns
