col path for a50
select g.name dg_name, d.name disk_name, d.os_mb, d.header_status, d.path
from v$asm_disk_stat d,
     v$asm_diskgroup_stat g
where d.group_number = g.group_number (+)
order by g.name, d.name, d.os_mb, d.path;