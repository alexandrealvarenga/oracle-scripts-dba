set verify off
col kill format a60
col "Evento" format a35
col "Classe" for a40
col "Secs" heading 'Seconds|In Wait'
col p1text for a40
col p2text for a40
col p3text for a40
col p1 for 999999999999999
col p2 for 999999999999999
col p3 for 999999999999999
select substr(b.username,1,10)        "User",
       substr(a.sid,1,4)              "Sid",
       substr(c.spid,1,9)             "OS Pid",
       substr(a.event,1,29)           "Evento",
       substr(a.wait_class, 1, 40)	  "Classe",
       a.seconds_in_wait              "Secs",
       substr(b.status,1,4)           "Status",
       b.logon_time                   "Start Session",
       a.p1text,
		 a.p1,
		 a.p2text,
		 a.p2,
		 a.p3text,
       a.p3,
       substr(b.program,1,30)          "Programa",
       'ALTER SYSTEM DISCONNECT SESSION ' || CHR(39) || a.SID ||','||b.SERIAL# || CHR(39) || ' IMMEDIATE;' kill
from v$session_wait a, v$session b, v$process c
where a.event not in ('SQL*Net message from client','SQL*Net message to client')
and a.sid = b.sid
and decode(nvl(c.background, 0), 0, ' ', 'B') <> 'B'
and c.addr=b.paddr (+)
and c.spid is not null
and a.wait_class <> 'Idle'
and b.sid = &1;
set verify on
