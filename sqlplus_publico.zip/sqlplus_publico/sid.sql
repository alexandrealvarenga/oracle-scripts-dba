SET VERIFY OFF
SET HEAD ON
set feed off

CLEAR COL
COL   COMMAND  FORMAT A90
accept SID1 char prompt 'Informe o SID: '
SELECT
         'Matar a sess�o    :  ALTER SYSTEM KILL SESSION ' || CHR(39) || SID ||','||SERIAL# || CHR(39) || ';'        || chr(10) ||
         'Trace ON          :  EXEC SYS.DBMS_SYSTEM.SET_SQL_TRACE_IN_SESSION ('|| SID ||', '||SERIAL# ||', TRUE)'    || chr(10) ||
         'Trace OFF         :  EXEC SYS.DBMS_SYSTEM.SET_SQL_TRACE_IN_SESSION ('|| SID ||', '||SERIAL# ||', FALSE)'   COMMAND
FROM     V$SESSION
WHERE    V$SESSION.SID = &SID1
UNION
SELECT   'Session ID        : '||SID                  || chr(10) ||
         'Process ID (Unix) : '||SPID                 || '       ( ps -ef|grep '||spid||'|grep -v grep )' || chr(10) ||
         'User SO           : '||OSUSER               || chr(10) ||
         'User Oracle       : '||V$SESSION.USERNAME   || chr(10) ||
         'Status            : '||STATUS               || chr(10) ||
         'Schema            : '||SCHEMANAME           || chr(10) ||
         'Program           : '||V$SESSION.PROGRAM    || chr(10) ||
         'Tempo conex�o     : '||lpad(floor(((sysdate-logon_time)*86400)/(3600)) ||':'|| lpad(floor((((sysdate-logon_time)*86400) - (floor(((sysdate-logon_time)*86400)/(3600))*3600))/60), 2, '0') ||':'||lpad(mod((((sysdate-logon_time)*86400) - (floor(((sysdate-logon_time)*86400)/(3600))*3600)),60), 2, '0'), 10, ' ')  || chr(10) ||
         'Idle Time         : '||lpad(trim(to_char(floor(last_call_et/(3600)),9000)||':'||trim(to_char(floor((last_call_et - (floor(last_call_et/(3600))*3600))/60),900))||':'||trim(to_char(mod((last_call_et - (floor(last_call_et/(3600))*3600)),60),900))), 10, ' ') COMMAND
FROM   V$SESSION, V$PROCESS
WHERE  ADDR = PADDR
AND    V$SESSION.SID = &SID1
/
cl col
UNDEF SID1
SET HEAD ON
SET VERIFY ON;
set feed on
