rem   name       : FREE2.sql 
rem   date       : 01-01-1998
rem   description: Shows free space for each tablespace (size and percent).
rem   compatible : v7.1 upwards
col name     format A16         head "Tablespace Name"
col pct_used format 999.9       head "Pct|Used"
col Kbytes   format 999,999,999 head "KBytes"
col used     format 999,999,999 head "Used"
col free     format 999,999,999 head "Free"
col max_free format 999,999,999 head "Max size|free chunk"
col File_name format A46        head "Data File Name"
break   on report
compute sum of kbytes on report
compute sum of free on report
compute sum of used on report
set linesize 1000
set head on
set feed off
set verify off
accept ts char prompt 'Entre parte do nome do tablespace: '

select   nvl(FULL.tablespace_name,nvl(FREE.tablespace_name,'UNKOWN')) Name
        ,kbytes_used                    Kbytes
        ,kbytes_used-nvl(kbytes_free,0) Used
        ,nvl(kbytes_free,0)             Free
        ,((kbytes_used-nvl(kbytes_free,0)) / kbytes_used)*100 Pct_used
        ,nvl(max_free,0)                Max_free
        ,nvl(FULL.file_name,'UNKOWN') File_name
from 
     ( select  sum(bytes)/1024    Kbytes_free
              ,max(bytes)/1024    max_free
              ,tablespace_name
       from    sys.DBA_FREE_SPACE
       group by tablespace_name ) FREE,
     ( select  sum(bytes)/1024    Kbytes_used
              ,tablespace_name
              ,file_name
       from    sys.DBA_DATA_FILES
       group by tablespace_name,file_name ) FULL
where  FREE.tablespace_name (+) = FULL.tablespace_name
and FULL.tablespace_name like upper('%&ts%')
order by  name;


select 'alter database datafile '''||file_name||''' resize' RESIZE
from   sys.DBA_DATA_FILES 
where  tablespace_name like UPPER('%&ts%')
order by tablespace_name;

select 'alter database datafile '''||file_name||''' autoextend '||decode(autoextensible,'YES','off','on')||';' AUTOEXTEND
from   sys.DBA_DATA_FILES 
where  tablespace_name like UPPER('%&ts%') 
order by tablespace_name;

prompt
undef ts
set verify on
set feed on
