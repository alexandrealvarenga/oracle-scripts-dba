set lines 500 serveroutput off pages 9999 verify off head off
col elapsed_time_secs for 9999999999990.00
col avg_time_secs for 9999999999990.00

select *
from table(
    dbms_xplan.display_cursor(
        '&1',
        null,
        'ADVANCED LAST ALLSTATS +ADAPTIVE -PROJECTION -ALIAS -OUTLINE'
    )
);

set head on

col parsing_schema_name for a20
col executions for 9999999999
col child_number for 999999999999
col invalidations for 9999999999999
col first_load_time for a19
select parsing_schema_name, executions, elapsed_time/1e6 elapsed_time_secs, (elapsed_time/1e6)/decode(executions, 0, 1, executions) avg_time_secs, plan_hash_value, child_number, invalidations, first_load_time
from v$sql where sql_id = '&1';

undef 1

set lines 1000 serveroutput on