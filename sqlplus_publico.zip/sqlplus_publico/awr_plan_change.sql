----------------------------------------------------------------------------------------
--
-- File name:   awr_plan_changes.sql
--
-- Purpose:     Show all different plans for a SQL statement.
--
-- Author:      Kerry Osborne
--
-- Usage:       This scripts prompts for two values, and the last of them can be left blank.
--
--              sql_id:  only include statements that have been executed on the specified number of last days.
--                          (the default is 7 days)
--              num_days:  only include statements that have been executed on the specified number of last days.
--                          (the default is 7 days)
--
-- See http://kerryosborne.oracle-guy.com/2008/10/unstable-plans/ for more info.
---------------------------------------------------------------------------------------


store set %temp%\sqlenv replace

set lines 155
col execs for 999G999G999
col avg_etime for 999G999D999
col avg_lio for 999G999G999D9
col begin_interval_time for a30
col node for 99999
break on plan_hash_value on startup_time skip 1
SELECT ss.snap_id, ss.instance_number node, begin_interval_time, sql_id, plan_hash_value,
       nvl(executions_delta,0) execs,
       (elapsed_time_delta/decode(nvl(executions_delta,0),0,1,executions_delta))/1000000 avg_etime,
       (buffer_gets_delta/decode(nvl(buffer_gets_delta,0),0,1,executions_delta)) avg_lio
FROM DBA_HIST_SQLSTAT S,
     DBA_HIST_SNAPSHOT SS
WHERE sql_id = nvl('&sql_id','')
  AND ss.snap_id = S.snap_id
  AND ss.instance_number = S.instance_number
  AND ss.begin_interval_time > trunc(sysdate) - nvl(to_number('&num_days'), 7)
  AND executions_delta > 0
ORDER BY 1, 2, 3
/

clear breaks

@%temp%\sqlenv
prompt
