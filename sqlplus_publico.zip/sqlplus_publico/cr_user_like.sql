rem  **************************************************************************
rem
rem  NAME:  TB_RCT.sql
rem
rem  HISTORY:
rem  Date             Who              What
rem  ________  ___________________  __________________________________________
rem  02/25/91  R. Gaydos            Created
rem  03/18/92  Gary Dodge           Improved format, changed SPOOL file name
rem
rem  FUNCTION:  Build a script to re-create user
rem
rem  **************************************************************************
accept var_user prompt 'Usuario: '
set arraysize 10
set verify off
set heading off
set feedback off

--set termout off echo off feedback off pagesize 0 heading off verify off
REM  

select 'create user "'||username||'" identified by values '''||password||''''||' default tablespace '||DEFAULT_TABLESPACE||' temporary tablespace '||temporary_tablespace || ';'
from dba_users
where username like upper('%&var_user%');

SELECT 'ALTER USER "'||username||'" '||DECODE(profile, 'DEFAULT', ';', ' profile '||profile||';')
from dba_users
where username like upper('%&var_user%');

select 'grant '||granted_role||' to "'||grantee||'";'
from dba_role_privs
where grantee like upper('%&var_user%');

--select 'grant '||privilege||' to "'||grantee||'";'
--from dba_sys_privs  
--where grantee like upper('%&var_user%');

--select 'grant '||privilege||' on '||owner||'.'||table_name||' to '||grantee||';'
--from dba_tab_privs
--where grantee like upper('%&var_user%') 
--/
 
--set termout on feedback 15 verify on pagesize 20 linesize 80 space 1 heading on

set feedback on     
set verify on
set heading on
