col sid_serial for a20
col username for a30
col osuser for a30
col inst_id for 9999999
col program for a20
col module for a40
col tablespace for a30

prompt ==> Por instance <==

SELECT A.inst_id, A.tablespace_name tablespace, D.mb_total,
SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM gv$sort_segment A,
(
SELECT B.inst_id, B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
FROM gv$tablespace B, gv$tempfile C
WHERE B.ts#= C.ts# and B.inst_id = C.inst_id
GROUP BY B.inst_id, B.name, C.block_size
) D
WHERE A.tablespace_name = D.name
  AND A.inst_id = D.inst_id
GROUP by A.inst_id, A.tablespace_name, D.mb_total;

prompt ==> Por sessao <==

SELECT T.inst_id, S.sid || ',' || S.serial# sid_serial, TBS.tablespace_name tablespace, S.username, S.osuser, P.spid, S.module,
P.program, SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, COUNT(*) statements
FROM gv$sort_usage T, gv$session S, dba_tablespaces TBS, gv$process P
WHERE T.session_addr = S.saddr
AND T.inst_id = S.inst_id
AND S.paddr = P.addr
AND S.inst_id = P.inst_id
AND T.tablespace = TBS.tablespace_name
GROUP BY T.inst_id, S.sid, S.serial#, TBS.tablespace_name, S.username, S.osuser, P.spid, S.module,
P.program, TBS.block_size, T.tablespace
ORDER BY T.inst_id, sid_serial;