store set %temp%\sqlenv replace

-- Purpose:     (v$sql where sql_profile is not null)
col sql_text for a60 wrap
set verify off
set pagesize 999
set lines 165
col username format a13
col prog format a22
col sid format 999
col child_number format 99999 heading CHILD
col ocategory format a10
col avg_etime format 9G999G990D00
col avg_pio format 9G999G990D00
col avg_lio format 999G999G999
col etime format 9G999G990D00
col sql_profile for a30

select sql_id, child_number, plan_hash_value plan_hash, sql_profile, executions execs,
(elapsed_time/1000000)/decode(nvl(executions,0),0,1,executions) avg_etime,
buffer_gets/decode(nvl(executions,0),0,1,executions) avg_lio,
sql_text
from v$sql s
where upper(sql_text) like upper(nvl('&sql_text',sql_text))
and sql_text not like '%from v$sql where sql_text like nvl(%'
and sql_id like nvl('&sql_id',sql_id)
and sql_profile like nvl('&sql_profile_name',sql_profile)
and sql_profile is not null
order by 1, 2, 3
/

@%temp%\sqlenv
prompt
