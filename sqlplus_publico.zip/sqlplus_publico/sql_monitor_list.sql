/* sql_monitor_list.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Gera uma lista das queries monitoradas.
 * Utilizacao: @sql_monitor_list
 *
 */

store set %temp%\sqlenv replace

SET LONG 1000000
SET LONGCHUNKSIZE 1000000
SET LINESIZE 1000
SET PAGESIZE 0
SET TRIM ON
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET TERM ON
SET VERIFY OFF
SET HEADING OFF

accept ACT_SINCE prompt 'Queries ativas ha x segundos (default 3600): ' default 3600

SELECT DBMS_SQLTUNE.REPORT_SQL_MONITOR_LIST(
    active_since_sec => &ACT_SINCE,
    report_level => 'BASIC' ) AS report
FROM dual;

@%temp%\sqlenv
prompt
