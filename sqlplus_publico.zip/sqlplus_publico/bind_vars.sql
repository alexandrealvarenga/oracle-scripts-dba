col child_number for 999999999999
col name for a30
col position for 99999999
col datatype_string for a30
col max_length for 999999999
col was_captured for a12
col value_string for a60 word_wrapped

select child_number, name, position, datatype_string, max_length, was_captured, last_captured, value_string
from v$sql_bind_capture
where sql_id = '&1'
order by child_number, position;

undef 1
clear columns