--Esse scrips monitora todos os CURSORES que est�o sendo executados no banco de dados, 
�timo para melhorar processos de banco e melhorar aplica��es.

SELECT a.user_name,
       a.sid,
       a.sql_text
FROM   v$open_cursor a
	Where a.user_name NOT IN ('SYS','DBSNMP','HA_CLUSTER')
ORDER BY 1,2
/
