/* INFOSQL_AWR.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Informações de um SQL agrupadas por plan_hash_value, obtidas a partir do AWR
 * Utilizacao: @infosql_awr sql_id num_dias
 *            
 * Exemplos: @infosql_awr 17kapq4za0qdp 7
 *
 */

set verify off head off
col info for a150

select
    '----------------------------------------------------------------------------------------------------'||chr(10)||
    'SNAPSHOT                 : '||to_char(sn.begin_interval_time, 'DD/MM/RR HH24:MI:SS')                 ||' - '||to_char(sn.end_interval_time, 'DD/MM/RR HH24:MI:SS')||chr(10)||
    'Plan Hash Value          : '||st.plan_hash_value                                                     ||chr(10)||
    'Executions               : '||st.executions_delta                                                    ||chr(10)||
    'Parse Calls              : '||st.parse_calls_delta                                                   ||chr(10)||
    'Fetches                  : '||st.fetches_delta                                                       ||chr(10)||
    'Disk Reads               : '||st.disk_reads_delta                                                    ||chr(10)||
    'Buffer Gets              : '||st.buffer_gets_delta                                                   ||chr(10)||
    'Rows Processed           : '||st.rows_processed_delta                                                ||chr(10)||
    'Sorts                    : '||st.sorts_delta                                                         ||chr(10)||
    'End Of Fetch Count       : '||st.end_of_fetch_count_delta                                            ||chr(10)||
    'Loads                    : '||st.loads_delta                                                         ||chr(10)||
    'Invalidations            : '||st.invalidations_delta                                                 ||chr(10)||
    'Cpu Time (s)             : '||trunc(st.cpu_time_delta/1e6)                                           ||chr(10)||
    'Elapsed Time (s)         : '||trunc(st.elapsed_time_delta/1e6)                                       ||chr(10)||
    'Application Wait Time (s): '||trunc(st.APWAIT_DELTA/1e6)                                             ||chr(10)||
    'Concurrency Wait Time (s): '||trunc(st.CCWAIT_DELTA/1e6)                                             ||chr(10)||
    'Cluster Wait Time (s)    : '||trunc(st.CLWAIT_DELTA/1e6)                                             ||chr(10)||
    'User I/O Wait Time (s)   : '||trunc(st.iowait_delta/1e6)                                             ||chr(10)||
    '----------------------------------------------------------------------------------------------------'||chr(10) info
from dba_hist_sqlstat st
join dba_hist_snapshot sn on st.snap_id = sn.snap_id and st.dbid = sn.dbid and st.instance_number = sn.instance_number
where sn.dbid = (select dbid from v$database)
  and sn.instance_number = sys_context('USERENV','INSTANCE')
  and sn.begin_interval_time >= (systimestamp - numtodsinterval(&2,'DAY'))
  and st.sql_id = '&1'
order by sn.snap_id, st.elapsed_time_delta, st.cpu_time_delta;

undef 1 2
clear columns

set head on