set serveroutput off

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

spool %temp%\strm_prt_err_&wdt..log

DECLARE
	

	CURSOR c IS
		SELECT LOCAL_TRANSACTION_ID,
		SOURCE_DATABASE,
		MESSAGE_NUMBER,
		MESSAGE_COUNT,
		ERROR_NUMBER,
		ERROR_MESSAGE
		FROM DBA_APPLY_ERROR
		ORDER BY SOURCE_DATABASE, SOURCE_COMMIT_SCN;
		i NUMBER;
	txnid VARCHAR2(30);
	source VARCHAR2(500);
	msgno NUMBER;
	msgcnt NUMBER;
	errnum NUMBER := 0;
	errno NUMBER;
	errmsg VARCHAR2(255);
	lcr sys.ANYDATA;
	r NUMBER;
	
	output_file utl_file.file_type;
	
	PROCEDURE print_any(data IN ANYDATA, output_file utl_file.file_type) IS
		tn VARCHAR2(61);
		str VARCHAR2(4000);
		chr VARCHAR2(1000);
		num NUMBER;
		dat DATE;
		rw RAW(4000);
		res NUMBER;
	BEGIN
		IF data IS NULL THEN
			UTL_FILE.PUT_LINE(output_file, 'NULL value');
			RETURN;
		END IF;
		tn := data.GETTYPENAME();
		IF tn = 'SYS.VARCHAR2' THEN
			res := data.GETVARCHAR2(str);
			UTL_FILE.PUT_LINE(output_file, SUBSTR(str,0,253));
		ELSIF tn = 'SYS.CHAR' then
			res := data.GETCHAR(chr);
			UTL_FILE.PUT_LINE(output_file, SUBSTR(chr,0,253));
		ELSIF tn = 'SYS.VARCHAR' THEN
			res := data.GETVARCHAR(chr);
			UTL_FILE.PUT_LINE(output_file, chr);
		ELSIF tn = 'SYS.NUMBER' THEN
			res := data.GETNUMBER(num);
			UTL_FILE.PUT_LINE(output_file, num);
		ELSIF tn = 'SYS.DATE' THEN
			res := data.GETDATE(dat);
			UTL_FILE.PUT_LINE(output_file, dat);
		ELSIF tn = 'SYS.RAW' THEN
			-- res := data.GETRAW(rw);
			-- UTL_FILE.PUT_LINE(output_file, SUBSTR(DBMS_LOB.SUBSTR(rw),0,253));
			UTL_FILE.PUT_LINE(output_file, 'BLOB Value');
		ELSIF tn = 'SYS.BLOB' THEN
			UTL_FILE.PUT_LINE(output_file, 'BLOB Found');
		ELSE
			UTL_FILE.PUT_LINE(output_file, 'typename is ' || tn);
		END IF;
	END;
	
	PROCEDURE print_lcr (lcr IN ANYDATA, output_file utl_file.file_type)
	IS
	   typenm     VARCHAR2 (61);
	   ddllcr     SYS.lcr$_ddl_record;
	   proclcr    SYS.lcr$_procedure_record;
	   rowlcr     SYS.lcr$_row_record;
	   res        NUMBER;
	   newlist    SYS.lcr$_row_list;
	   oldlist    SYS.lcr$_row_list;
	   ddl_text   CLOB;
	   ext_attr   ANYDATA;
	BEGIN
	   typenm := lcr.gettypename ();
	   UTL_FILE.PUT_LINE(output_file, 'type name: ' || typenm);
	
	   IF (typenm = 'SYS.LCR$_DDL_RECORD')
	   THEN
	      res := lcr.getobject (ddllcr);
	      UTL_FILE.PUT_LINE(output_file,    'source database: '
	                            || ddllcr.get_source_database_name
	                           );
	      UTL_FILE.PUT_LINE(output_file, 'owner: ' || ddllcr.get_object_owner);
	      UTL_FILE.PUT_LINE(output_file, 'object: ' || ddllcr.get_object_name);
	      UTL_FILE.PUT_LINE(output_file, 'is tag null: ' || ddllcr.is_null_tag);
	      DBMS_LOB.createtemporary (ddl_text, TRUE);
	      ddllcr.get_ddl_text (ddl_text);
	      UTL_FILE.PUT_LINE(output_file, 'ddl: ' || ddl_text);
	      -- Print extra attributes in DDL LCR
	      ext_attr := ddllcr.get_extra_attribute ('serial#');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'serial#: ' || ext_attr.accessnumber ());
	      END IF;
	
	      ext_attr := ddllcr.get_extra_attribute ('session#');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'session#: ' || ext_attr.accessnumber ());
	      END IF;
	
	      ext_attr := ddllcr.get_extra_attribute ('thread#');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'thread#: ' || ext_attr.accessnumber ());
	      END IF;
	
	      ext_attr := ddllcr.get_extra_attribute ('tx_name');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file,    'transaction name: '
	                               || ext_attr.accessvarchar2 ()
	                              );
	      END IF;
	
	      ext_attr := ddllcr.get_extra_attribute ('username');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'username: ' || ext_attr.accessvarchar2 ());
	      END IF;
	
	      DBMS_LOB.freetemporary (ddl_text);
	   ELSIF (typenm = 'SYS.LCR$_ROW_RECORD')
	   THEN
	      res := lcr.getobject (rowlcr);
	      UTL_FILE.PUT_LINE(output_file,    'source database: '
	                            || rowlcr.get_source_database_name
	                           );
	      UTL_FILE.PUT_LINE(output_file, 'owner: ' || rowlcr.get_object_owner);
	      UTL_FILE.PUT_LINE(output_file, 'object: ' || rowlcr.get_object_name);
	      UTL_FILE.PUT_LINE(output_file, 'is tag null: ' || rowlcr.is_null_tag);
	      UTL_FILE.PUT_LINE(output_file, 'command_type: ' || rowlcr.get_command_type);
	      oldlist := rowlcr.get_values ('old');
	
	      FOR i IN 1 .. oldlist.COUNT
	      LOOP
	         IF oldlist (i) IS NOT NULL
	         THEN
	            UTL_FILE.PUT_LINE(output_file, 'old(' || i || '): '
	                                  || oldlist (i).column_name
	                                 );
	            print_any (oldlist (i).DATA, output_file);
	         END IF;
	      END LOOP;
	
	      newlist := rowlcr.get_values ('new', 'n');
	
	      FOR i IN 1 .. newlist.COUNT
	      LOOP
	         IF newlist (i) IS NOT NULL
	         THEN
	            UTL_FILE.PUT_LINE(output_file, 'new(' || i || '): '
	                                  || newlist (i).column_name
	                                 );
	            print_any (newlist (i).DATA, output_file);
	         END IF;
	      END LOOP;
	
	      -- Print extra attributes in row LCR
	      ext_attr := rowlcr.get_extra_attribute ('row_id');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'row_id: ' || ext_attr.accessurowid ());
	      END IF;
	
	      ext_attr := rowlcr.get_extra_attribute ('serial#');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'serial#: ' || ext_attr.accessnumber ());
	      END IF;
	
	      ext_attr := rowlcr.get_extra_attribute ('session#');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'session#: ' || ext_attr.accessnumber ());
	      END IF;
	
	      ext_attr := rowlcr.get_extra_attribute ('thread#');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'thread#: ' || ext_attr.accessnumber ());
	      END IF;
	
	      ext_attr := rowlcr.get_extra_attribute ('tx_name');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file,    'transaction name: '
	                               || ext_attr.accessvarchar2 ()
	                              );
	      END IF;
	
	      ext_attr := rowlcr.get_extra_attribute ('username');
	
	      IF (ext_attr IS NOT NULL)
	      THEN
	         UTL_FILE.PUT_LINE(output_file, 'username: ' || ext_attr.accessvarchar2 ());
	      END IF;
	   ELSE
	      UTL_FILE.PUT_LINE(output_file, 'Non-LCR Message with type ' || typenm);
	   END IF;
	END;
	
	
	BEGIN
		output_file := utl_file.fopen('C0135418_DPUMP','streams_errors.log', 'W');
	
		FOR r IN c LOOP
			errnum := errnum + 1;
			msgcnt := r.MESSAGE_COUNT;
			txnid := r.LOCAL_TRANSACTION_ID;
			source := r.SOURCE_DATABASE;
			msgno := r.MESSAGE_NUMBER;
			errno := r.ERROR_NUMBER;
			errmsg := r.ERROR_MESSAGE;
			UTL_FILE.PUT_LINE(output_file, '*************************************************');
			UTL_FILE.PUT_LINE(output_file, '----- ERROR #' || errnum);
			UTL_FILE.PUT_LINE(output_file, '----- Local Transaction ID: ' || txnid);
			UTL_FILE.PUT_LINE(output_file, '----- Source Database: ' || source);
			UTL_FILE.PUT_LINE(output_file, '----Error in Message: '|| msgno);
			UTL_FILE.PUT_LINE(output_file, '----Error Number: '||errno);
			UTL_FILE.PUT_LINE(output_file, '----Message Text: '||errmsg);
			FOR i IN 1..msgcnt LOOP
				UTL_FILE.PUT_LINE(output_file, '--message: ' || i);
				lcr :=sys.DBMS_APPLY_ADM.GET_ERROR_MESSAGE(i, txnid);
				print_lcr(lcr, output_file);
			END LOOP;
		END LOOP;
		
		utl_file.fclose(output_file);
	END;
/


spool off

prompt Log disponivel em: %temp%\strm_prt_err_&wdt..log
prompt

set serveroutput off
