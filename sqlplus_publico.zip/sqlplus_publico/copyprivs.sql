--
-- Geovani Mazioli da Silva 
-- Copia as permiss�es de um usu�rio para outro.
-- Data: 18/07/2008
--

set verify off
set heading off
set feedback off

accept ori prompt 'Usuario Origem.: '
accept des prompt 'Usuario Destino: '

spool c:\temp\privs_&ori._&des..txt

SELECT 'GRANT '|| granted_role ||' to &des;'
FROM dba_role_privs
WHERE grantee LIKE UPPER ('%&ori%');

SELECT 'GRANT '|| privilege ||' on '|| owner ||'.'|| table_name ||' to &des;'
FROM dba_tab_privs
WHERE grantee LIKE UPPER ('%&ori%');

spool off

prompt
prompt	@C:\TEMP\privs_&ori._&des..txt

set feedback on     
set verify on
set heading on

