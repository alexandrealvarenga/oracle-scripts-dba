-- Ref: http://gavinsoorma.com/2012/11/ash-and-awr-performance-tuning-scripts/

col sql_id for a13
col plan_hash_value for 999999999999999
col executions for 999G999G999
col crows for 9G999G999G999
col cpu_mins for 9G999G999G999
col ela_mins for 9G999G999G999
col avg_elapsed_secs for 9G999G999G999D99
col display for a100
define p_sqlid = &1

select sql_id, plan_hash_value, executions, crows, cpu_mins, ela_mins, avg_elapsed_secs,
    'select * from table(dbms_xplan.display_awr(''&p_sqlid'', '||plan_hash_value||', '||dbid||', ''ALL''))' display
from (
    select
      SQL_ID
    , PLAN_HASH_VALUE
    , sum(EXECUTIONS_DELTA) EXECUTIONS
    , sum(ROWS_PROCESSED_DELTA) CROWS
    , trunc(sum(CPU_TIME_DELTA)/1000000/60) CPU_MINS
    , trunc(sum(ELAPSED_TIME_DELTA)/1000000/60)  ELA_MINS
    , (sum(ELAPSED_TIME_DELTA)/1000000)/sum(decode(EXECUTIONS_DELTA, 0, 1, EXECUTIONS_DELTA)) AVG_ELAPSED_SECS
    , d.dbid
    from DBA_HIST_SQLSTAT s
    join v$database d on s.dbid = d.dbid
    where SQL_ID in (
    '&p_sqlid')
    group by SQL_ID , PLAN_HASH_VALUE, d.dbid)
order by SQL_ID, CPU_MINS;

undef 1 p_sqlid
clear columns
