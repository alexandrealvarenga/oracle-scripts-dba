/* check_parts.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Listagem de particoes de tabelas de sistema
 * Utilizacao: @check_parts
 * 
 * Pre-requisitos: Definir a variavel dir com o diretorio de spool.
**/

define dir=c:\temp

set echo off verify off

col nome_arquivo new_val l_nome_arquivo noprint

select 'particoes_'||name||'_'||to_char(sysdate,'YYYYMMDD_HH24MISS') nome_arquivo
from v$database;

col table_owner for a30
col table_name for a30
col partition_name for a30
col high_value for a100 word_wrapped
col tablespace_name for a30

break on table_owner on table_name skip page

spool &dir\&l_nome_arquivo..txt

select table_owner, table_name, partition_name, high_value, tablespace_name
from (
    select table_owner, table_name, partition_name, high_value, tablespace_name,
           row_number() over (partition by table_owner, table_name order by partition_position desc) rn
    from dba_tab_partitions
    where table_owner not in (
            'ADAMS', 'ANONYMOUS', 'APPQOSSYS','AURORA$ORB$UNAUTHENTICATED',
            'AWR_STAGE', 'BLAKE', 'CLARK', 'CSMIG', 'CTXSYS',
            'DBSNMP', 'DEMO', 'DIP', 'DMSYS', 'DSSYS', 'EXFSYS',
            'HR', 'JONES', 'LBACSYS', 'MDSYS', 'OE', 'ORACLE_OCM', 'ORADBA','ORDDATA',
            'ORDPLUGINS', 'ORDSYS', 'OUTLN', 'PERFSTAT', 'SCOTT',
            'SH', 'SYS', 'SYSTEM', 'TRACESVR', 'TSMSYS', 'USU_NAGIOS', 'WMSYS', 'XDB'
    )
) parts
where rn <= 13
order by table_owner, table_name, rn;

spool off

prompt host &dir\&l_nome_arquivo..txt
prompt

set pages 9999
undef dir l_nome_arquivo nome_arquivo
 