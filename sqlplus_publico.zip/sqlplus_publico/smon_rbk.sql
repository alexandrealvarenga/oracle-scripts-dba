-- Ref: http://www.runningoracle.com/product_info.php?products_id=330
SELECT  usn, 
        state, 
        undoblockstotal "Total", 
        undoblocksdone "Done", 
        undoblockstotal-undoblocksdone "ToDo",
        case 
            when undoblockstotal <> undoblocksdone then
                DECODE(cputime,0,'unknown',SYSDATE+(((undoblockstotal-undoblocksdone) / (undoblocksdone / cputime)) / 86400))
            else
                null
        end "Finish at"
FROM v$fast_start_transactions;