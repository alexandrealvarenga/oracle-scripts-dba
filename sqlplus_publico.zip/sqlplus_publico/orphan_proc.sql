-- Ref.: How To Find The Process Identifier (pid, spid) After The Corresponding Session Is Killed? (Doc ID 387077.1)

col background for a10
select spid, program, terminal, username, background from v$process 
    where program!= 'PSEUDO'
    and addr not in (select paddr from v$session)
    and addr not in (select paddr from v$bgprocess)
    and addr not in (select paddr from v$shared_server)
order by background nulls first, program, lpad(spid, 24);