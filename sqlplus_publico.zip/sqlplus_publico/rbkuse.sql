set term off
store set %temp%\sqlenv replace
set term on
set verify off
col RBS format a15 trunc
col SID format 9990
col USER format a10 trunc
col COMMAND format a60 trunc
col status format a6 trunc
col ACTION format a32 trunc
col CLIENT_INFO format a34 trunc
accept us prompt 'Informe o usu�rio (ORACLE): '
SELECT r.name "RBS", s.sid, s.serial#, s.username "USER", t.status ST_TRAN, s.status ST_SES, start_time st, action, client_info,
       --t.cr_get, t.phy_io, t.used_ublk, t.noundo,
       substr(s.program, 1, 78) "COMMAND"
FROM   sys.v_$session s, sys.v_$transaction t, sys.v_$rollname r
WHERE  t.addr = s.taddr
  and  t.xidusn = r.usn
  and  upper(username) like upper('%&us%')
ORDER  BY t.cr_get, t.phy_io
/
set verify on
@%temp%\sqlenv.sql
set term on;