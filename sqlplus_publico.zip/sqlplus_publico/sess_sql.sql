set verify off
accept username prompt 'Username: ' default '%'

select s.username, s.sid, s.serial#, s.status, s.sql_id, s.sql_child_number, q.plan_hash_value, s.state, s.event
from v$session s
join v$sql q on s.sql_id = q.sql_id and s.sql_address = q.address and s.sql_child_number = q.child_number
where username like '&username'
order by s.username, s.status, s.sid;

undef username
