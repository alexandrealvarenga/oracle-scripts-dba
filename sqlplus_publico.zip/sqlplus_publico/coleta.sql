--
-- Geovani Mazioli da Silva 
-- coleta informa��es da Inst�ncia.
-- Data: 17/07/2008
--

spool c:\temp\dados_instancia.txt

set pagesize 10000
set feedback off
set verify off

prompt ############## VERSAO DO BANCO ##############

select * from v$version;


prompt 
prompt 
prompt ############## INSTANCIA ##############

COL	"Inst"	FORMAT	9
COL	"Nome"	FORMAT	A8
COL	"Host"	FORMAT	A16
COL	status	FORMAT	A9
COL	blocked	FORMAT	A8
COL	startup_time FORMAT	A19

SELECT 
instance_number Inst
,instance_name Nome
,host_name Host
,TO_CHAR (startup_time,'dd/mm/yyyy hh24:mm:ss') startup_time
,status
,logins
,database_status
FROM v$instance;

CLEAR COL


prompt 
prompt 
prompt ############## V$PARAMETER ##############

COL	name	FORMAT A30
COL	type	FORMAT 9999
COL	value	FORMAT A20
COL	description	FORMAT A60

SELECT 
name
, type
, value
, description 
FROM v$parameter;

CLEAR COL


prompt 
prompt 
prompt ############## TAMANHO (MB) ALOCADO PARA A INSTANCIA ##############

select sum(bytes)/1024/1024 as "Tamanho (MB)" from dba_data_files;


prompt 
prompt 
prompt ############## TAMANHO (MB) UTILIZADO PELA INSTANCIA ##############

select sum(bytes)/1024/1024 as "Tamanho (MB)" from dba_segments;


prompt 
prompt 
prompt ############## TAMANHO (MB) OCUPADO POR ESQUEMA/TIPO DE OBJETO ##############

select owner as "ESQUEMA", segment_type as "TIPO DE OBJETO", sum(bytes)/1024/1024 as "TAMANHO (MB)"
from dba_segments
group by owner, segment_type
order by owner;


prompt 
prompt 
prompt ############## NOME DO OWNER, TIPOS DE OBJETOS E QUANTIDADE DELES ##############

col owner format a20
break on owner skip 1
select owner, object_type, count(*)
from   dba_objects
where  object_name not like 'TMP%'
group  by owner, object_type
order  by owner, object_type;


prompt 
prompt 
prompt ############## TODAS TABLESPACES ##############

select tablespace_name as "TABLESPACE", block_size as "BLOCO DE DADOS", status as "STATUS", 
allocation_type as "TIPO DE ALOCACAO", segment_space_management as "GER.SEGMENTO"
from dba_tablespaces
ORDER BY tablespace;


prompt 
prompt 
prompt ############## TABLESPACES ##############

select decode(grouping(tablespace_name),0,null,1,'TOTAL (MB) =') as "1",
tablespace_name as "TABLESPACE", segment_type as "TIPO DE OBJETO", sum(bytes)/1024/1024 as "TAMANHO (MB)"
from dba_segments
group by rollup(tablespace_name, segment_type)
order by tablespace_name;


prompt 
prompt 
prompt ############## CONTAS DE USUARIOS ##############

COL	status	FOR	A20
COL	quantidade	FOR	9999999999

SELECT DISTINCT 
account_status as STATUS, count(account_status) as QUANTIDADE
FROM DBA_USERS
GROUP BY ACCOUNT_STATUS;

clear col


prompt 
prompt 
prompt ############## PARAMETROS NLS ##############

COL	parameter 	FOR	A25
COL	value		FOR	A50

SELECT * from V$NLS_PARAMETERS;

clear col

set feedback on
set verify on

spool off
