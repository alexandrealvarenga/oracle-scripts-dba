col username for a30
col os_username for a30
col returncode for 99999999999
col userhost for a30
col failed_logins for 999G999G999G999G990

SELECT username,
       os_username,
       RETURNCODE,
       userhost,
       trunc(TIMESTAMP),
       count(*) failed_logins
FROM dba_audit_trail
WHERE returncode <> 0
  AND TIMESTAMP > trunc(sysdate - &num_days)
GROUP BY username,
         os_username,
         RETURNCODE,
         userhost,
         trunc(TIMESTAMP)
ORDER BY 5;

undef num_days
clear columns