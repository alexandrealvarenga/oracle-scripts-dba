/* oem_open_events.sql
 *
 * Autor:      Lucas Pimentel Lellis
 * Descricao:  Lista os events abertos no OEM
 * Utilizacao: @oem_open_events
 *
 */


set lines 1000
col event_class for a30
col severity for a10
col msg for a100 word_wrapped
col target_type for a30
col target_name for a60
col event_name for a50
col cmd for a200 word_wrapped
col link for a120
with stateless_events as (
    select distinct target_type, metric_name||':'||metric_column evt_name
    from sysman.mgmt_metrics mtr
    where statefull = 0
)
select evl.event_class,
       evl.severity,
       evl.msg,
       evl.CREATION_DATE,
       evl.LAST_UPDATED_DATE,
       tgt.target_type,
       tgt.target_name,
       evl.event_name,
       case
           when evl.event_name in (
                select evt_name
                from stateless_events se
                where se.target_type = tgt.target_type
           )
           then
                'emcli clear_stateless_alerts -older_than=0 -target_type='||chr(39)||tgt.target_type||chr(39)||' -target_name='||chr(39)||tgt.target_name||chr(39)||' -metric_internal_name='||chr(39)||tgt.target_type||':'||evl.event_name||chr(39)
           else
                'emcli collect_metric -target_type='||chr(39)||tgt.target_type||chr(39)||' -target_name='||chr(39)||tgt.target_name||chr(39)||' -metric_name='||chr(39)||substr(evl.event_name, 1, instr(evl.event_name, ':')-1)||chr(39)
        end cmd,
        'https://'||decode(sys_context('userenv', 'db_name'), 'PBAND25', '22.228.56.10', 'PESCE25', '22.228.56.9') ||':7803/em/faces/core-event-console-detailEvent?issueID='||evl.EVENT_SEQ_ID link
from sysman.gc$events_latest evl
left outer join sysman.gc$target tgt on evl.target_guid = tgt.target_guid
where evl.open_status = 1
and evl.event_class in ('metric_alert', 'mntr_disruption', 'target_availability', 'high_availability')
order by evl.last_updated_date
/
