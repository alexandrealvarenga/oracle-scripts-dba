clear breaks computes columns
column dummy noprint
compute sum of percent_space_used on dummy
col file_type for a40
break on dummy
select null dummy, FILE_TYPE, PERCENT_SPACE_USED, PERCENT_SPACE_RECLAIMABLE, NUMBER_OF_FILES, CON_ID
from V$FLASH_RECOVERY_AREA_USAGE
order by file_type;
clear breaks computes columns