--
-- Geovani Mazioli da Silva 
-- Concede acesso a todas tabelas de um determinado owner para um usu�rio.
-- Data: 17/07/2008
--

set verify off
set heading off
set feedback off

accept vper char prompt 'Permissao(se mais de 1, separar com vergula): '
accept vown char prompt 'Owner.: '
accept vgra char prompt 'Grantee: '

spool c:\temp\grant_table_&vown._to_.gra

SELECT 'GRANT &vper on &vown'||'.'||object_name||' to &vgra;' FROM dba_objects WHERE owner='&vown' and object_type = 'TABLE';

spool off

prompt 
prompt Script gerado no arquivo c:\temp\granttable_&vown._to_&vgra..gra
prompt 
prompt @c:\temp\grant_table_&vown._to_.gra
prompt 

undef &vgra
undef &vper
undef &vown

set feedback on
set heading on
set verify on
