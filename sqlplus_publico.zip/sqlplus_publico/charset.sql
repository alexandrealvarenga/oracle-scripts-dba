col parameter for a30
col value for a40

prompt ## DATABASE ##
SELECT * FROM NLS_DATABASE_PARAMETERS;

prompt ## SESSION ##
SELECT * FROM NLS_SESSION_PARAMETERS;
