set verify off
set lines 400

accept l_owner prompt 'Owner: '
accept l_name prompt 'Name: '
accept l_type prompt 'Type: '

col path for a400

with my_deps as (
    select /*+ materialize */ owner, name, type, referenced_owner, referenced_name, referenced_type, referenced_link_name, dependency_type
    from dba_dependencies
)
select ltrim(sys_connect_by_path(owner||'.'||name, ' <- '), ' <- ') path
from my_deps
start with referenced_owner = upper('&l_owner') and referenced_name = upper('&l_name') and referenced_type = upper('&l_type')
connect by nocycle prior name = referenced_name and prior owner = referenced_owner and prior type = referenced_type
order siblings by owner, name, type;

undef l_owner l_name l_type
clear columns
