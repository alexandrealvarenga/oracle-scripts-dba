set term off
store set %temp%\sqlenv replace
set term on
set lines 120
alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';
col host_name for a15
col instance_name for a10
col startup_time for a18
col user for a12
col version for a10
col status for a10
col FSO for a3
col FSOH for a3
select distinct decode(instr(host_name,'.'),0,host_name,
       substr(host_name,1,instr(host_name,'.')-1)) host_name,
       instance_name ,user,
       i.status,to_char(startup_time, 'dd/mm/yy hh24:mi:ss') startup_time,
       version, logins, d.open_mode
from gv$instance i, gv$database d;

select distinct d.protection_mode DG_PROTECTION,database_role,controlfile_type CF_TYPE,SWITCHOVER_STATUS,dataguard_broker DGBROKER,GUARD_STATUS,force_logging FORCE_LOGGINGL
from gv$instance i, gv$database d;

col timestamp for 99999999999
col message for a100

PROMPT *** CHECAGEM DE MENSAGENS DE ERRO ***
SELECT timestamp,MESSAGE FROM V$DATAGUARD_STATUS;
--where message not like '%Standby%redo%logfile%selected%for%thread%sequence%';

SELECT PROCESS, STATUS, THREAD#, SEQUENCE#, BLOCK#, BLOCKS FROM V$MANAGED_STANDBY;

-- PROMPT *** CHECAGEM DO DATABASE INCARNATION ***
-- SELECT INCARNATION#, RESETLOGS_ID, STATUS FROM V$DATABASE_INCARNATION ;

PROMPT *** ULTIMO LOG APLICADO ***
SELECT THREAD#, MAX(SEQUENCE#) AS "LAST_APPLIED_LOG"
FROM GV$LOG_HISTORY
GROUP BY THREAD#
order by THREAD#;

-- PROMPT *** LOGS AINDA NAO RECEBIDAS PELO STDY ***
-- SELECT LOCAL.THREAD#, LOCAL.SEQUENCE# FROM 
-- (SELECT THREAD#, SEQUENCE# FROM V$ARCHIVED_LOG WHERE DEST_ID=1) LOCAL 
--  WHERE LOCAL.SEQUENCE# NOT IN 
-- (SELECT SEQUENCE# FROM V$ARCHIVED_LOG WHERE DEST_ID=2 AND 
-- THREAD# = LOCAL.THREAD#
-- and local.THREAD# = 1); 
col "Qtd SWT" format 999999999
select to_char(trunc(FIRST_TIME), 'dd/mm/yyyy') Data
,      count(*) "Qtd SWT"
from   gv$loghist
where  first_time >= trunc(sysdate-3)
group  by trunc(FIRST_TIME);
@%temp%\sqlenv
set term on
