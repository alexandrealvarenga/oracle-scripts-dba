col state for a60
set lines 180
col logminer_id for 999999999999

select extract_name, logminer_id, state, sga_used/1024/1024 sga_used_mb, sga_allocated/1024/1024 sga_allocated_mb
from v$goldengate_capture
order by capture_name;