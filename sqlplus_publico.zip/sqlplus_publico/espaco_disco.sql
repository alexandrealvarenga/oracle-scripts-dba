set serveroutput on size 1000000 echo off feed off
exec dbms_java.set_output(1000000)

declare
	type type_tab_fs 	is table of varchar2(200);
	tab_fs 				type_tab_fs := type_tab_fs();
	oper_system			v$database.platform_name%type;
	total number;
	usado number;
	mount_point varchar2(200) := ' ';
	mount_point_anterior varchar2(200) := ' ';
begin
	select upper(platform_name)
	into oper_system
	from v$database;
	
	select distinct substr(file_name, 0, instr(file_name, '/', -1))
	bulk collect into tab_fs
	from (
		select file_name
		from dba_data_files
		union all
		select file_name
		from dba_temp_files
		union all
		select member file_name
		from v$logfile
		union all
		select name file_name
		from v$controlfile
	)
	order by 1;

	dbms_output.put_line('Sist. Oper.: ' || oper_system || chr(10));
	for i in tab_fs.first..tab_fs.last loop
		if instr(tab_fs(i), '+') > 0 then
			dbms_output.put_line('==> O filesystem '||tab_fs(i)||' eh ASM.');
		else	
			sarbox_disk_space(tab_fs(i), oper_system, total, usado, mount_point);

			if (mount_point <> mount_point_anterior) then
				dbms_output.put_line('Mount Point: ' || mount_point);
				dbms_output.put_line('Total (MB):  ' || to_char((total/1024), 'FM9999999999999999.00'));
				dbms_output.put_line('Usado (MB):  ' || to_char((usado/1024), 'FM9999999999999999.00'));
				dbms_output.put_line('Livre (MB):  ' || to_char(((total - usado)/1024), 'FM9999999999999999.00'));
				dbms_output.put_line('Perc. Usado: ' || to_char(usado * 100/total, 'FM99.99') || chr(10));
				mount_point_anterior := mount_point;
			end if;
		end if;
	end loop;
end;
/

set feed on
