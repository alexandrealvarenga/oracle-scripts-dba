set serveroutput on size 1000000
set heading off feedback off echo off
set pagesize 0
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000
set pause off
declare
    nome_banco v$database.name%type;
    nome_data  v$datafile.name%type;
    tam_data   v$datafile.bytes%type;
    n_logs     smallint;
    n_dats     smallint;
    n_grps     smallint;
    dsize      smallint;
    cont       smallint;
    cont1      smallint;
    texto      char(1);
    texto1     char(1);
--
    cursor c1_log is
    select distinct lf.group#, bytes/1024 kbytes
    from   v$logfile lf, v$log l
    where  lf.group# = l.group#
    order by lf.group#;
--
    cursor c2_log (grupo number) is
    select member
    from   v$logfile
    where  group# = grupo;
--
    cursor c1_dats is
    select  name,bytes
    from v$datafile where status = 'SYSTEM';
begin
--    dbms_output.enable(20000);
    dsize := 0;
    cont1 := 0;
--
    select name
    into   nome_banco
    from   v$database;
--
    dbms_output.put_line('CREATE DATABASE '||'"'||nome_banco||'"');
    dbms_output.put_line('LOGFILE');
--
    select count(*)
    into n_grps
    from v$log;
--
    for log1 in c1_log loop
        cont   := 0;
        texto1 := ',';
--
        dbms_output.put_line('GROUP '|| to_char(log1.group#) || '( ');
--
        select count(*)
        into   n_logs
        from   v$logfile
        where  group# = log1.group#;
--
        for log2 in c2_log (log1.group#) loop
            texto := ',';
            cont  := cont + 1;
--
            if cont = n_logs then
                texto := ' ';
            end if;
--
            dbms_output.put_line('''' || log2.member || '''' || texto);
        end loop;
--
        cont1 := cont1 + 1;
--
        if cont1 = n_grps then
            texto1 := ' ';
        end if;
--
        dbms_output.put_line(') SIZE ' || to_char(log1.kbytes) || ' K'||texto1);
    end loop;
--
    open c1_dats;
--
    fetch c1_dats into nome_data, tam_data;
--
    dsize := tam_data/1024;
--
    dbms_output.put_line('DATAFILE');
        dbms_output.put_line('''' ||nome_data|| '''' ||
                             ' SIZE '|| to_char(dsize) || ' K' || texto);
--
    close c1_dats;
--
    dbms_output.put_line('MAXLOGFILES 254');
    dbms_output.put_line('MAXLOGMEMBERS 5');
    dbms_output.put_line('MAXDATAFILES 254');
    dbms_output.put_line('ARCHIVELOG');
    dbms_output.put_line('CHARACTER SET "WE8ISO8859P1"');
end;
/
set serveroutput off
set heading on feedback on echo on
set pagesize 20
set pause on
