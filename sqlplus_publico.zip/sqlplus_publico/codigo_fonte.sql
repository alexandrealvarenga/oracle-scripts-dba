--
-- Geovani Mazioli da Silva 
-- verifica c�digo fonte de uma procedure/function.
-- Data: 17/07/2008
--

set verify off
set pagesize 50000
set feedback off
set heading off

accept own prompt 'Owner.: '
accept obj prompt 'Objeto: '
accept tip prompt 'Tipo..: '

spool c:\temp\&own._&obj..txt

SELECT text
FROM dba_source
WHERE owner = upper ('&own') AND
	name = upper ('&obj') AND
	type LIKE upper ('%&tip%');

spool off

prompt
prompt	Arquivo "&own._&obj..txt" criado em C:\TEMP

undef &own
undef &obj
undef &tip

set verify on
set feedback on
set heading on
