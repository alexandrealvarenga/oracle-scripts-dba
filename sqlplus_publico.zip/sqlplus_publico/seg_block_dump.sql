/* SEG_BLOCK_DUMP.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Identificacao de um segmento pelo file# e block#, utilizando dump de bloco
 * Utilizacao: @seg_block_dump file# block#
 *
 * Exemplo: @seg_block_dump 7 11039
 *
 * Baseado em http://dioncho.wordpress.com/2009/07/06/object-name-from-file-and-block/
 * Privilegios necessarios: alter system, create any directory, drop any directory,
 *                          execute on utl_file
 */

set serveroutput on echo off verify off

declare
    l_file_num number := &1;
    l_block_num number := &2;
    
    l_temp_line varchar2(4000);
    l_temp_str varchar2(4000);
    l_temp_int integer;
    
    l_epoch_time number(20);
    l_exec_id varchar2(200);
    l_process_id number(10);
    
    l_owner dba_objects.owner%type;
    l_object_name dba_objects.object_name%type;
    l_object_type dba_objects.object_type%type;
    
    l_trace_dir_location varchar2(200);
    l_trace_file_name varchar2(200);
    l_trace_file_map_name varchar2(200); -- Apenas para 11g
    l_trace_file_id_orig varchar2(200);
    l_trace_file_handle utl_file.file_type;
    
begin
    select value into l_trace_file_id_orig from v$parameter where lower(name) = 'tracefile_identifier';
    select value into l_trace_dir_location from v$parameter where lower(name) = 'user_dump_dest';
    
    l_epoch_time := (SYSDATE - TO_DATE('01-01-1970 00:00:00', 'DD-MM-YYYY HH24:MI:SS')) * 24 * 60 * 60;
    l_exec_id := sys_context('USERENV','SESSION_USER')||'_'||l_epoch_time;
    
    select sys_context('USERENV','INSTANCE_NAME')||'_ora_'||p.spid||'_'||l_exec_id||'.trc',
           sys_context('USERENV','INSTANCE_NAME')||'_ora_'||p.spid||'_'||l_exec_id||'.trm'
    into l_trace_file_name, l_trace_file_map_name
    from v$process p join v$session s on p.addr = s.paddr
    where s.sid = sys_context('USERENV','SID');
    
    execute immediate 'create directory '||l_exec_id||' as '''||l_trace_dir_location||'''';
    
    execute immediate 'alter session set tracefile_identifier='''||l_exec_id||'''';
    execute immediate 'alter system dump datafile '||l_file_num||' block '||l_block_num;
    
    l_trace_file_handle := utl_file.fopen(l_exec_id, l_trace_file_name, 'R',4000);    
    loop
        begin
            utl_file.get_line(l_trace_file_handle, l_temp_line);
        
            if regexp_like(l_temp_line, 'buffer tsn:') then
                dbms_output.put_line('---------------------------------------------');
                l_temp_str := regexp_substr(l_temp_line, '[[:digit:]]+/[[:digit:]]+');
                dbms_output.put_line(rpad('dba = ',20)|| l_temp_str);
            end if;

            if regexp_like(l_temp_line, 'type: 0x([[:xdigit:]]+)=([[:print:]]+)') then
                l_temp_str := substr(regexp_substr(l_temp_line, '=[[:print:]]+'), 2);
                dbms_output.put_line(rpad('type = ',20)|| l_temp_str);
            end if;
            
            if regexp_like(l_temp_line, 'seg/obj:') then
                l_temp_str := substr(regexp_substr(l_temp_line, 'seg/obj: 0x[[:xdigit:]]+'),12);
                l_temp_int := to_number(l_temp_str, rpad('X',length(l_temp_str),'X'));
                select owner, object_name, object_type
                into l_owner, l_object_name, l_object_type
                from dba_objects where object_id = l_temp_int or data_object_id = l_temp_int;
                dbms_output.put_line(rpad('owner = ',20)|| l_owner);
                dbms_output.put_line(rpad('name = ',20)|| l_object_name);
                dbms_output.put_line(rpad('obj type = ',20)|| l_object_type);
                dbms_output.put_line('---------------------------------------------');
                exit;
            end if;
            
            
        exception
            when no_data_found then
                exit;
        end;
    end loop;
    
    utl_file.fclose(l_trace_file_handle);
    
    -- Retorna o tracefile identifier para o valor original
    execute immediate 'alter session set tracefile_identifier='''||l_trace_file_id_orig||'''';
    
    begin
        utl_file.fremove(l_exec_id, l_trace_file_map_name);
    exception
        when others then null; -- Esse arquivo so eh gerado no 11g
    end;
    begin
        utl_file.fremove(l_exec_id, l_trace_file_name);
    exception
        when others then
            raise_application_error(-20001, 'Nao foi possivel excluir o arquivo de trace '||l_trace_file_name||chr(10)||dbms_utility.format_error_stack);
    end;
    begin
        execute immediate 'drop directory '||l_exec_id;
    exception
        when others then
            raise_application_error(-20002, 'Nao foi possivel excluir o diretorio '||l_exec_id||chr(10)||dbms_utility.format_error_stack);
    end;
end;
/
