SELECT sql_text, last_load_time, parsing_schema_id, module, elapsed_time
FROM V$SQL
WHERE TO_DATE(FIRST_LOAD_TIME,'YYYY-MM-DD/HH24:MI:SS') >= TRUNC(SYSDATE)
ORDER BY TO_DATE(FIRST_LOAD_TIME,'YYYY-MM-DD/HH24:MI:SS') DESC;
