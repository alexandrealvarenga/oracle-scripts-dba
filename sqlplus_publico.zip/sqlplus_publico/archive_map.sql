set lines 180; 
set pages 10; 

prompt ## Instance ##

col "Total" for 9999 justify right
col "00" for 9999 justify right
col "01" for 9999 justify right
col "02" for 9999 justify right
col "03" for 9999 justify right
col "04" for 9999 justify right
col "05" for 9999 justify right
col "06" for 9999 justify right
col "07" for 9999 justify right
col "08" for 9999 justify right
col "09" for 9999 justify right
col "10" for 9999 justify right
col "11" for 9999 justify right
col "12" for 9999 justify right
col "13" for 9999 justify right
col "14" for 9999 justify right
col "15" for 9999 justify right
col "16" for 9999 justify right
col "17" for 9999 justify right
col "18" for 9999 justify right
col "19" for 9999 justify right
col "20" for 9999 justify right
col "21" for 9999 justify right
col "22" for 9999 justify right
col "23" for 9999 justify right


SELECT 
to_char(trunc(first_time), 'DD/MM/YYYY') day,
count(first_time) "Total",
sum(decode(to_char(first_time,'HH24'),'00',1,0)) "00",
sum(decode(to_char(first_time,'HH24'),'01',1,0)) "01",
sum(decode(to_char(first_time,'HH24'),'02',1,0)) "02",
sum(decode(to_char(first_time,'HH24'),'03',1,0)) "03",
sum(decode(to_char(first_time,'HH24'),'04',1,0)) "04",
sum(decode(to_char(first_time,'HH24'),'05',1,0)) "05",
sum(decode(to_char(first_time,'HH24'),'06',1,0)) "06",
sum(decode(to_char(first_time,'HH24'),'07',1,0)) "07",
sum(decode(to_char(first_time,'HH24'),'08',1,0)) "08",
sum(decode(to_char(first_time,'HH24'),'09',1,0)) "09",
sum(decode(to_char(first_time,'HH24'),'10',1,0)) "10",
sum(decode(to_char(first_time,'HH24'),'11',1,0)) "11",
sum(decode(to_char(first_time,'HH24'),'12',1,0)) "12",
sum(decode(to_char(first_time,'HH24'),'13',1,0)) "13",
sum(decode(to_char(first_time,'HH24'),'14',1,0)) "14",
sum(decode(to_char(first_time,'HH24'),'15',1,0)) "15",
sum(decode(to_char(first_time,'HH24'),'16',1,0)) "16",
sum(decode(to_char(first_time,'HH24'),'17',1,0)) "17",
sum(decode(to_char(first_time,'HH24'),'18',1,0)) "18",
sum(decode(to_char(first_time,'HH24'),'19',1,0)) "19",
sum(decode(to_char(first_time,'HH24'),'20',1,0)) "20",
sum(decode(to_char(first_time,'HH24'),'21',1,0)) "21",
sum(decode(to_char(first_time,'HH24'),'22',1,0)) "22",
sum(decode(to_char(first_time,'HH24'),'23',1,0)) "23"
from
v$log_history h
join v$instance i on i.thread# = h.thread#
GROUP by trunc(first_time)
order by trunc(first_time);

prompt ## Cluster ##

SELECT 
to_char(trunc(first_time), 'DD/MM/YYYY') day,
count(first_time) "Total",
sum(decode(to_char(first_time,'HH24'),'00',1,0)) "00",
sum(decode(to_char(first_time,'HH24'),'01',1,0)) "01",
sum(decode(to_char(first_time,'HH24'),'02',1,0)) "02",
sum(decode(to_char(first_time,'HH24'),'03',1,0)) "03",
sum(decode(to_char(first_time,'HH24'),'04',1,0)) "04",
sum(decode(to_char(first_time,'HH24'),'05',1,0)) "05",
sum(decode(to_char(first_time,'HH24'),'06',1,0)) "06",
sum(decode(to_char(first_time,'HH24'),'07',1,0)) "07",
sum(decode(to_char(first_time,'HH24'),'08',1,0)) "08",
sum(decode(to_char(first_time,'HH24'),'09',1,0)) "09",
sum(decode(to_char(first_time,'HH24'),'10',1,0)) "10",
sum(decode(to_char(first_time,'HH24'),'11',1,0)) "11",
sum(decode(to_char(first_time,'HH24'),'12',1,0)) "12",
sum(decode(to_char(first_time,'HH24'),'13',1,0)) "13",
sum(decode(to_char(first_time,'HH24'),'14',1,0)) "14",
sum(decode(to_char(first_time,'HH24'),'15',1,0)) "15",
sum(decode(to_char(first_time,'HH24'),'16',1,0)) "16",
sum(decode(to_char(first_time,'HH24'),'17',1,0)) "17",
sum(decode(to_char(first_time,'HH24'),'18',1,0)) "18",
sum(decode(to_char(first_time,'HH24'),'19',1,0)) "19",
sum(decode(to_char(first_time,'HH24'),'20',1,0)) "20",
sum(decode(to_char(first_time,'HH24'),'21',1,0)) "21",
sum(decode(to_char(first_time,'HH24'),'22',1,0)) "22",
sum(decode(to_char(first_time,'HH24'),'23',1,0)) "23"
from
v$log_history h
GROUP by trunc(first_time)
order by trunc(first_time);

clear columns
set pages 9999