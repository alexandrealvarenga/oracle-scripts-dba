set linesize 80
desc &1
set linesize 500