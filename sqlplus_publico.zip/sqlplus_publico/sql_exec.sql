/* sql_exec.sql
 *
 * Autor:      Lucas Pimentel Lellis
 * Descricao:  Lista os SQL em execucao pelas sessoes ativas
 * Utilizacao: @sql_exec
 *
 * Ref.: https://jarneil.wordpress.com/2010/06/08/joining-vsession-and-vsql-in-11gr2/
 */


col sid for 999999999999
col serial# for 999999999999
col sql_id for a15
col plan_hash_value for 999999999999
col osuser for a30 word_wrapped
col username for a30

SELECT /*+ ordered */
       ss.sid,
       ss.SERIAL#,
       sql.sql_id,
       sql.plan_hash_value,
       ss.OSUSER,
       ss.username,
       substr(sql.sql_text, 1, 60) sql_text
FROM V$SESSION ss, V$SQL sql
where (ss.SQL_ADDRESS = sql.ADDRESS
   and ss.SQL_HASH_VALUE = sql.HASH_VALUE
   and ss.SQL_CHILD_NUMBER = sql.CHILD_NUMBER)
and ss.status = 'ACTIVE'
and sql.sql_id like '&sql_id'
and sql.plan_hash_value like '&plan_hash_value'
and lower(sql.sql_text) like '&sql_text'
ORDER BY 1;

clear columns