set verify off
accept usuario prompt 'Usuario: '
SELECT * FROM dba_sys_privs WHERE grantee LIKE upper('%&usuario%');
