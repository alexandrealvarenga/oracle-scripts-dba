-------------------------------------------------------------------------------
--       Nome : baselines.sql
--      Autor : Lucas Pimentel Lellis (lucas.lellis@cgi.com)
-- Finalidade : Mostrar os SQL Plan Baselines de um banco
-------------------------------------------------------------------------------

col sql_handle for a30
col plan_name for a30
col origin for a14
col parsing_schema_name for a30
col enabled for a7
col accepted for a8
col fixed for a5
col elapsed_secs for 999G999G999G990D00
col avg_elapsed_secs for 999G999G999G990D00
col sql_text for a100 trunc
col description for a100 trunc

break on sql_handle skip page

select parsing_schema_name, sql_handle, plan_name, creator, origin,
       enabled, accepted, fixed, executions, elapsed_time/1e6 elapsed_secs,
       (elapsed_time/1e6)/decode(nvl(executions, 1), 0, 1, nvl(executions, 1)) avg_elapsed_secs, to_char(created, 'DD/MM/YYYY HH24:MI:SS') created,
       sql_text, description
from dba_sql_plan_baselines
where upper(sql_text) like upper(nvl('&sql_text', '%'))
  and parsing_schema_name like upper(nvl('&parsing_schema_name', '%'))
order by sql_handle, fixed desc, enabled desc, accepted desc, created, avg_elapsed_secs;

clear columns breaks
undef sql_text parsing_schema_name
