------------------------------------------------------------------------
-- Gera arquivo txt com o �ltimo resultado da SYS_AUTO_SQL_TUNING_TASK
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (24/03/2017)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

accept l_dir default '%TEMP%' prompt 'Diret�rio de destino (default - %TEMP%): '

set long 2000000000 longchunksize 8192000 lines 32767 trimspool on feed off term off head off
col recommendations for a32767

col nome_arquivo new_val l_nome_arquivo noprint
select lower(sys_context('userenv','instance_name'))||'_sql_'||to_char(sysdate, 'yyyymmddhh24miss') nome_arquivo from dual;

spool "&l_dir\&l_nome_arquivo..txt"

SELECT DBMS_AUTO_SQLTUNE.report_auto_tuning_task AS recommendations FROM dual;

spool off

prompt
@%temp%\sqlenv
prompt
prompt host "&l_dir\&l_nome_arquivo..txt"
prompt

undef l_dir l_nome_arquivo
clear columns
