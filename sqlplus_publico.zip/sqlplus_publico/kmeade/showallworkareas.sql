--
-- show work areas in use
--

col SQL_EXEC_START  noprint
col SQL_EXEC_ID noprint
col WORKAREA_ADDRESS noprint
col OPERATION_TYPE        format a20 trunc
col active_time noprint
col expected_size noprint

select * from gv$sql_workarea_active;
