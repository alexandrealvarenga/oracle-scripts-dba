--
-- dump the most recent plan from the plan_table
--
-- usage is: @SHOWPLAN11G
--

select * from table(dbms_xplan.display('PLAN_TABLE',NULL,'ADVANCED'));
