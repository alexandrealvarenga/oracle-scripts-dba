select * from gv$sql_workarea_active where (inst_id,sid) in (select inst_id,sid from gv$session where username = user);
