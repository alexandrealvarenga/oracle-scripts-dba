col owner for a30
col segment_name for a30
col partition_name for a30
col segment_type for a30
col tablespace_name for a30

select /*+ ORDERED */ owner, segment_name, partition_name, segment_type, tablespace_name, block_id, blocks+block_id-1 last_block
from dba_extents
where file_id = &1
and &2 between block_id and block_id + blocks - 1;

undef 1 2
clear columns
