------------------------------------------------------------------------
-- Gera arquivo txt com o �ltimo resultado da auto-task do ADDM
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (24/03/2017)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

accept l_dir default '%TEMP%' prompt 'Diret�rio de destino (default - %TEMP%): '

set long 2000000000 longchunksize 8192000 lines 32767 trimspool on feed off term off newpage none head off

col nome_arquivo new_val l_nome_arquivo noprint
select lower(sys_context('userenv','instance_name'))||'_addm_'||to_char(sysdate, 'yyyymmddhh24miss') nome_arquivo
from dual;

spool "&l_dir\&l_nome_arquivo..txt"

select dbms_advisor.get_task_report(l_task_name, 'TEXT', 'ALL', 'ALL', 'SYS')
from (
  select task_name l_task_name
  from dba_advisor_tasks
  where advisor_name = 'ADDM'
  and task_name like 'ADDM:'||(select dbid from v$database)||'_'||sys_context('userenv','instance')||'%'
  order by task_id desc
)
where rownum < 2;

spool off

prompt
@%temp%\sqlenv
prompt
prompt host "&l_dir\&l_nome_arquivo..txt"
prompt

undef l_dir l_nome_arquivo
clear columns breaks computes
