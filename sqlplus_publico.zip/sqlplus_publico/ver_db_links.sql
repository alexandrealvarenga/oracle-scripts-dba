------------------------------------------------------------------------
-- Lista db links da base
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (09/08/2018)
------------------------------------------------------------------------

col owner for a30
col db_link for a60
col username for a30
col host for a60

select owner, db_link, username, host, to_char(created, 'DD/MM/YYYY HH24:MI:SS') created
from dba_db_links
where upper(owner) like upper('&owner')
order by owner, db_link;

clear columns
undef owner
