set linesize 400
col TABLE_OWNER for a15


select t.owner
     , t.table_name
     , t.TABLESPACE_NAME
     , to_char(t.last_analyzed,'DD-MM-RRRR HH24:MI:SS') as "ANALYZE"
     , t.blocks hwm
     , t.empty_blocks
	 , s.blocks
	 , s.bytes
     , t.chain_cnt
     , t.num_rows 	 
 from dba_tables t, dba_segments s
 where (t.empty_blocks > 80 or t.chain_cnt > 0)
 and s.segment_name=t.table_name
 and t.partitioned = 'NO'
 and t.owner not in ('SYS','SYSTEM','PERFSTAT','QUEST') 
 and t.table_name not in (
                        select table_name 
                        from dba_tab_columns
                        where data_type in ('RAW','LONG RAW')
 )
order by 1;

select t.table_owner
     , t.table_name
     , t.partition_name     
     , t.TABLESPACE_NAME
     , to_char(t.last_analyzed,'DD-MM-RRRR HH24:MI:SS') as "ANALYZE"
     , t.blocks hwm
     , t.empty_blocks
                , s.blocks
                , s.bytes
     , t.chain_cnt
     , t.num_rows                
 from dba_tab_partitions t, dba_segments s
where (t.empty_blocks > 80 or t.chain_cnt > 0)
and s.partition_name=t.partition_name
  and s.segment_name=t.table_name
and t.table_owner not in ('SYS','SYSTEM','PERFSTAT','QUEST') 
 and t.table_name not in (
                        select table_name 
                        from dba_tab_columns
                        where data_type in ('RAW','LONG RAW')
)
order by 1;




WITH tabelas AS (
select owner,table_name
from dba_tables
where (empty_blocks > 80 or chain_cnt > 0)
and partitioned = 'NO'
and owner not in ('SYS','SYSTEM','PERFSTAT','QUEST') 
and table_name not in (
	               select table_name 
	               from dba_tab_columns
	               where data_type in ('RAW','LONG RAW'))
), indices AS (
select  i.owner, i.index_name
from dba_indexes i, tabelas t
where i.table_owner = t.owner
and i.table_name = t.table_name
), tab_ind AS (
select owner, table_name AS segment_name from tabelas
union all
select owner,index_name AS segment_name from indices
), segmentos AS (
select se.owner, se.segment_type, se.segment_name, se.tablespace_name, se.bytes
from dba_segments se, tab_ind ti
where se.owner = ti.owner
and se.segment_name = ti.segment_name
)
select se.tablespace_name
	  ,max(se.bytes)/1024/1024 as max_segment
	  ,sum(ts.bytes)/1024/1024 as free_ts
	  ,case
	  when max(se.bytes*1.20) > sum(ts.bytes) then to_char(round((max(se.bytes*1.20) - sum(ts.bytes))/1024/1024,0))
	  else 'OK'
	  end extend_tablespace
from segmentos se, dba_free_space ts
where se.tablespace_name=ts.tablespace_name(+) 
group by se.tablespace_name
order by 2;



select round((sum(a.bytes)-sum(b.bytes))/1024/1024/1024,2) Gb_ocup 
     , round(sum(a.bytes)/1024/1024/1024,3) gb_aloc 
                 , round(sum(b.bytes)/1024/1024/1024,3) Gb_free 
                 , round((sum(b.bytes)/sum(a.bytes))*100,3) "%FREE"
from (select sum(bytes) bytes,tablespace_name 
      from dba_data_files 
      group by tablespace_name ) a, 
     ( select sum(bytes) bytes , tablespace_name
       from dba_free_space  
       group by tablespace_name ) b
where a.tablespace_name(+)=b.tablespace_name
/



select sum(total_de_horas), sum(minutos), sum(total_GB) from (
select sum(s.bytes)/15/1024/1024/1024 total_de_horas, sum(s.bytes)/15/1024/1024/1024*60 minutos, sum(bytes)/1024/1024/1024 total_GB
   from dba_tables t, dba_segments s
   where (t.empty_blocks > 80 or t.chain_cnt > 0)
   and s.segment_name=t.table_name
   and t.partitioned = 'NO'
   and t.owner not in ('SYS','SYSTEM','PERFSTAT','QUEST')
   and t.table_name not in (
                          select table_name
                          from dba_tab_columns
                          where data_type in ('RAW','LONG RAW')
   )
union all
select sum(s.bytes)/15/1024/1024/1024 total_de_horas, sum(s.bytes)/15/1024/1024/1024*60 minutos, sum(bytes)/1024/1024/1024 total_GB     
 from dba_tab_partitions t, dba_segments s
where (t.empty_blocks > 80 or t.chain_cnt > 0)
and s.partition_name=t.partition_name
  and s.segment_name=t.table_name
and t.table_owner not in ('SYS','SYSTEM','PERFSTAT','QUEST') 
 and t.table_name not in (
                        select table_name 
                        from dba_tab_columns
                        where data_type in ('RAW','LONG RAW')
))
;

