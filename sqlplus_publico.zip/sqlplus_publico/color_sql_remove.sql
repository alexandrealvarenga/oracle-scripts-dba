set echo on verify on

exec dbms_workload_repository.remove_colored_sql('&SQL_ID');

set echo off verify off