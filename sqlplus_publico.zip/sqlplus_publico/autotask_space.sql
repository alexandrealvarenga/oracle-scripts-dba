------------------------------------------------------------------------
-- Gera arquivo txt com os �ltimos resultados da SYS_AUTO_SPCADV
--
-- Criado por: Lucas Lellis - lucas.lellis@cgi.com (24/03/2017)
------------------------------------------------------------------------

store set %temp%\sqlenv replace

accept l_dir default '%TEMP%' prompt 'Diret�rio de destino (default - %TEMP%): '

set long 2000000000 longchunksize 8192000 lines 32767 trimspool on feed off term off newpage none

col nome_arquivo new_val l_nome_arquivo noprint
select lower(sys_context('userenv','instance_name'))||'_space_'||to_char(sysdate, 'yyyymmddhh24miss') nome_arquivo
from dual;

col language new_val l_language noprint
col territory new_val l_territory noprint
col charset new_val l_charset noprint

-- DBMS_SPACE.ASA_RECOMMENDATIONS Fails With ORA-06502 (Doc ID 1380978.1)
begin
    for r_param in (select parameter, value from nls_database_parameters
                    where parameter in ( 'NLS_LANGUAGE', 'NLS_TERRITORY')) loop
        execute immediate 'alter session set '||r_param.parameter||'='''||r_param.value||'''';
    end loop;
end;
/

col task_id for 9999999
col tablespace_name for a30
col segment_owner for a30
col segment_name for a30
col segment_type for a30
col partition_name for a30
col allocated_mb for 999G999G999G990D00
col used_mb for 999G999G999G990D00
col reclaimable_mb for 999G999G999G990D00
col recommendations for a100 word_wrapped
col c1 for a100 word_wrapped
col c2 for a100 word_wrapped
col c3 for a100 word_wrapped

break on report
compute sum of allocated_mb on report
compute sum of used_mb on report
compute sum of reclaimable_mb on report

spool "&l_dir\&l_nome_arquivo..txt"

select task_id, tablespace_name, segment_owner, segment_name, segment_type, partition_name,
       allocated_mb, used_mb,reclaimable_mb, recommendations, c1, c2, c3
from (
  select task_id, tablespace_name, segment_owner, segment_name, segment_type, partition_name,
         allocated_space/1024/1024 allocated_mb, used_space/1024/1024 used_mb,
         reclaimable_space/1024/1024 reclaimable_mb, recommendations, c1, c2, c3,
         row_number() over (partition by tablespace_name, segment_owner, segment_name, segment_type, partition_name order by task_id desc) rn
  from table(dbms_space.asa_recommendations(all_runs => 'TRUE', show_manual => 'FALSE'))
)
where rn = 1
order by reclaimable_mb desc, allocated_mb;

prompt
prompt
prompt -- ** Script **
prompt

begin
    for c_obj in (select adv.segment_owner, adv.segment_name, adv.partition_name, adv.segment_type, tab.row_movement, adv.c1, adv.c2, adv.c3
                  from (select task_id, tablespace_name, segment_owner, segment_name, segment_type, partition_name,
                        allocated_mb, used_mb,reclaimable_mb, recommendations, c1, c2, c3
                        from (
                          select task_id, tablespace_name, segment_owner, segment_name, segment_type, partition_name,
                                 allocated_space/1024/1024 allocated_mb, used_space/1024/1024 used_mb,
                                 reclaimable_space/1024/1024 reclaimable_mb, recommendations, c1, c2, c3,
                                 row_number() over (partition by tablespace_name, segment_owner, segment_name, segment_type, partition_name order by task_id desc) rn
                          from table(dbms_space.asa_recommendations(all_runs => 'TRUE', show_manual => 'FALSE'))
                        )
                        where rn = 1
                        order by task_id desc, reclaimable_mb desc, allocated_mb) adv,
                       dba_tables tab
                  where adv.segment_owner = tab.owner(+)
                    and adv.segment_name = tab.table_name(+)
                    and c1 is not null) loop
        if c_obj.row_movement = 'DISABLED' and c_obj.c1 like '%shrink%' then
            dbms_output.put_line('alter table "'||c_obj.segment_owner||'"."'||c_obj.segment_name||'" enable row row_movement;');
        end if;
        dbms_output.put_line(c_obj.c2||';'||chr(10)||c_obj.c1||';');
        if c_obj.row_movement = 'DISABLED'  and c_obj.c1 like '%shrink%' then
            dbms_output.put_line('alter table "'||c_obj.segment_owner||'"."'||c_obj.segment_name||'" disable row row_movement;');
        end if;
        dbms_output.put(chr(10));
    end loop;
end;
/

spool off

prompt
@%temp%\sqlenv
prompt
prompt host "&l_dir\&l_nome_arquivo..txt"
prompt

undef l_dir l_nome_arquivo
clear columns breaks computes
