/* INFOSQL.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Informações de um SQL agrupadas por plan_hash_value
 * Utilizacao: @infosql sql_id
 *            
 * Exemplos: @infosql 17kapq4za0qdp
 *
 */

set verify off
col info for a100

select
    'Plan Hash Value          : '||plan_hash_value                                   ||chr(10)||
    'Last Active Time         : '||to_char(last_active_time, 'DD/MM/YYYY HH24:MI:SS')||chr(10)||
    'Executions               : '||executions                                        ||chr(10)||
    'Fetches                  : '||fetches                                           ||chr(10)||
    'Parse Calls              : '||parse_calls                                       ||chr(10)||
    'Disk Reads               : '||disk_reads                                        ||chr(10)||
    'Buffer Gets              : '||buffer_gets                                       ||chr(10)||
    'Rows Processed           : '||rows_processed                                    ||chr(10)||
    'Sorts                    : '||sorts                                             ||chr(10)||
    'End Of Fetch Count       : '||end_of_fetch_count                                ||chr(10)||
    'Loads                    : '||loads                                             ||chr(10)||
    'Invalidations            : '||invalidations                                     ||chr(10)||
    'Cpu Time (s)             : '||trunc(cpu_time/1e6)                               ||chr(10)||
    'Elapsed Time (s)         : '||trunc(elapsed_time/1e6)                           ||chr(10)||
    'Application Wait Time (s): '||trunc(application_wait_time/1e6)                  ||chr(10)||
    'Concurrency Wait Time (s): '||trunc(concurrency_wait_time/1e6)                  ||chr(10)||
    'Cluster Wait Time (s)    : '||trunc(cluster_wait_time/1e6)                      ||chr(10)||
    'User I/O Wait Time (s)   : '||trunc(user_io_wait_time/1e6) info
from v$sqlstats s
where s.sql_id = '&1'
order by last_active_time, elapsed_time, cpu_time;

undef 1
clear columns
