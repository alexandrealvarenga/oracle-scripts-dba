--
-- Geovani Mazioli da Silva 
-- Concede acesso a todas procedures e functions de um determinado owner para um usu�rio.
-- Data: 21/08/2008
--

set verify off
set heading off
set feedback off

accept vgra char prompt 'Grantee: '
accept vown char prompt 'Owner..: '

spool c:\temp\grant_function_&vown._to_.gra

SELECT 'GRANT EXECUTE on &vown'||'.'||object_name||' to &vgra;' FROM dba_objects WHERE owner='&vown' and object_type IN ('PROCEDURE','FUNCTION','PACKAGE');

spool off

prompt 
prompt Script gerado no arquivo c:\temp\grant_function_&vown._to_.gra
prompt 
prompt @c:\temp\grant_function_&vown._to_.gra
prompt 

undef &vgra
undef &vown

set feedback on
set heading on
set verify on
