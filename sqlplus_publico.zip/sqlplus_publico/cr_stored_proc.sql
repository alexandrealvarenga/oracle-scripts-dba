set echo off
--
--accept Owner char prompt 'Informe o Owner das procedures ou tecle ENTER para todas: '
--
set linesize 100 pagesize 0 space 0
set termout off feedback off verify off heading off
set long 150000
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000

--
rem decode(substr(rtrim(ltrim(upper(text))), 1, length(type)), type,type,'') ||
rem decode(rtrim(ltrim(upper(substr(text,length(type),length(name))))), name,
rem        owner ||'.'||name,'') ||
rem        substr(text,length(type)+length(name))
--
column dum1 noprint
column dum2 noprint
column dum3 noprint
column dum4 noprint
column dum5 noprint
--
  SELECT owner dum1, type dum2, name dum3, 10 dum4, 0 dum5,
       'Create ' || type || ' ' || owner || '.' || name||' '
  FROM dba_source
  WHERE owner NOT IN ('SYS','SYSTEM')
UNION
  SELECT owner, type, name, 20, line,
       text
  FROM dba_source
  WHERE owner NOT IN ('SYS','SYSTEM')
UNION
  SELECT owner, type, name, 30, 1,
        '/'
  FROM dba_source
  WHERE owner NOT IN ('SYS','SYSTEM')
UNION
  SELECT owner, type, name, 30, 1,
        '/**********************************************************/'
  FROM dba_source
  WHERE owner NOT IN ('SYS','SYSTEM')
ORDER BY 1,2,3,4,5
/
--
undef Grantee
set linesize 80 pagesize 20 space 1
set termout on feedback on verify on heading on
