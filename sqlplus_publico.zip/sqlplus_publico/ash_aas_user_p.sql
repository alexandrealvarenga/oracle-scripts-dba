/* ASH_AAS_USER_P.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Listagem dos principais SIDs e usuarios por periodo e evento, em formato de pivot table
 * Utilizacao: @ash_aas_user_p intervalo dt_inicial dt_final [evento] (intervalo em minutos, data no formato YYYYMMDDHH24MI)
 *             @ash_aas_user_p intervalo last periodo_minutos [evento]
 * Obs.:       Parametros entre colchetes sao opcionais
 *
 * Exemplos: @ash_aas_user_p 1 201404291000 201404291005 'db file sequential read'
 *           @ash_aas_user_p 5 last 60 'db file%'
 *           @ash_aas_user_p 1 201404291000 201404291005
 *           @ash_aas_user_p 5 last 60
 *
 * Baseado no script ash_graph_waits_histash.sql de Kyle Hailey, em https://github.com/khailey/ashmasters
 * Ref.: http://www.oraclerealworld.com/ash-masters/
 */

store set %temp%\sqlenv replace

set verify off echo off lines 180 pages 20 serveroutput on

set feed off
alter session set nls_timestamp_format='DD/MM/RR HH24:MI';
set feed on

define C_SMP_INT_ASH=1                  -- Intervalo de amostragem da view V$ACTIVE_SESSION_HISTORY (em segundos)
define C_SMP_INT_ASH_HIST=10            -- Intervalo de amostragem da view DBA_HIST_ACTIVE_SESS_HISTORY (em segundos)
define C_SMP_WIDTH=14                   -- Largura do display do sample time
define C_USER_WIDTH=14                  -- Largura do display do username
define C_PCT_WIDTH=8                    -- Largura do display de percentagem
define C_AAS_FMT=9990.00                -- Formato de display do AAS
define C_PCT_FMT=990.00                 -- Formato de display da porcentagem
define C_DT_INPUT_FMT=YYYYMMDDHH24MI    -- Formato de input de data
define C_TSTP_FMT=YYYYMMDDHH24MISSFF    -- Formato de conversao de timestamp para varchar

-- Define o valor default do quarto parametro, que eh opcional
set feed off term off
col p4 new_value 4
select null p4 from dual where  1=2;
select nvl('&4','%') p4 from dual;
set feed on term on

define p_smp_int=&1
define p_ini_date=&2
define p_end_date=&3
define p_event="&4"

variable smp_period number
variable smp_int number
variable ini_date varchar2(20)
variable end_date varchar2(20)
variable scan_history number
variable event_name varchar2(100)
variable ash_min_time varchar2(30)

set feed off
declare
    l_ash_min_time timestamp := null;
    l_cpu_count number := 0;
    l_smp_period_interval interval day to second;
begin
    :smp_int := &p_smp_int;
    :ini_date := upper('&p_ini_date');
    :event_name := '&p_event';

    if (:ini_date = 'LAST') then
        :ini_date := to_char((systimestamp - &p_end_date/60/24), '&C_DT_INPUT_FMT');
        :end_date := to_char(systimestamp, '&C_DT_INPUT_FMT');
    else
        :ini_date := '&p_ini_date';
        :end_date := '&p_end_date';
    end if;

    l_smp_period_interval := to_timestamp(:end_date, '&C_DT_INPUT_FMT') - to_timestamp(:ini_date, '&C_DT_INPUT_FMT');
    :smp_period := 24*60*extract(day from l_smp_period_interval) + 60*extract(hour from l_smp_period_interval) + extract(minute from l_smp_period_interval);

    if :smp_int > :smp_period then
        :smp_int := :smp_period;
        dbms_output.put_line('Sampling Interval - corrected: '||:smp_int);
    end if;

    -- Ajusta o horario de inicio caso o intervalo nao seja multiplo do periodo analisado
    if mod(:smp_period, :smp_int) <> 0 then
        :smp_period := ceil(:smp_period/:smp_int) * :smp_int;
        :ini_date := to_char((to_date(:end_date, '&C_DT_INPUT_FMT') - :smp_period/60/24), '&C_DT_INPUT_FMT');

        dbms_output.put_line('Analyzed Period - corrected: '||to_date(:ini_date, '&C_DT_INPUT_FMT')
                        ||' - '||to_date(:end_date, '&C_DT_INPUT_FMT'));
    end if;


    select min(sample_time)
    into l_ash_min_time
    from v$active_session_history;
     -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
     -- Ref: http://optimizermagic.blogspot.com.br/2008/06/why-are-some-of-tables-in-my-query.html
    if (to_timestamp(:ini_date, 'YYYYMMDDHH24MI') < l_ash_min_time) then
       :scan_history := 1;
    else
       :scan_history := 2;
    end if;
    :ash_min_time := to_char(l_ash_min_time, '&C_TSTP_FMT');

    select value
    into l_cpu_count
    from v$parameter
    where upper(name) = 'CPU_COUNT';

    dbms_output.put_line(chr(10)||'CPU Count: '||l_cpu_count
                       ||chr(10)||'AAS - Average Active Sessions');
end;
/
set feed on

col sample for a&C_SMP_WIDTH

col "|USER-1st" for a&C_USER_WIDTH trunc
col "|USER-2nd" for a&C_USER_WIDTH trunc
col "|USER-3rd" for a&C_USER_WIDTH trunc
col "|USER-4th" for a&C_USER_WIDTH trunc

col "AAS-Sample" for &C_AAS_FMT
col "AAS-1st" for &C_AAS_FMT
col "AAS-2nd" for &C_AAS_FMT
col "AAS-3rd" for &C_AAS_FMT
col "AAS-4th" for &C_AAS_FMT

col "(%)-1st|" for a&C_PCT_WIDTH justify right
col "(%)-2nd|" for a&C_PCT_WIDTH justify right
col "(%)-3rd|" for a&C_PCT_WIDTH justify right
col "(%)-4th|" for a&C_PCT_WIDTH justify right

with
t1 as
(
    select /*+ OPT_ESTIMATE(TABLE, D, ROWS=100) */
           to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level, 'minute')*:smp_int dt,
           to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level-1, 'minute')*:smp_int next_dt
    from dual d
    connect by level <= (:smp_period/:smp_int)
),
events as
(
    select trunc(sample_time, 'MI') sample_time, user_id, sum(&C_SMP_INT_ASH) cnt
    from v$active_session_history h
    where (h.sample_time >= to_date(:ini_date, '&C_DT_INPUT_FMT') and h.sample_time < to_date(:end_date, '&C_DT_INPUT_FMT'))
      and lower(nvl(h.event, 'ON CPU')) like lower(:event_name)
    group by trunc(sample_time, 'MI'), user_id
    union all
    select /*+
                NO_MERGE(C)
                NO_MERGE(S)
                NO_MERGE(D)
                LEADING(C S D)
                OPT_ESTIMATE(TABLE S ROWS=1000)
                OPT_ESTIMATE(TABLE D ROWS=50000)
                OPT_ESTIMATE(TABLE D.ASH ROWS=50000)
                OPT_ESTIMATE(TABLE D.SN ROWS=1500)
                OPT_ESTIMATE(TABLE D.EVT ROWS=1000)
                LEADING(D.SN D.ASH D.EVT)
                USE_HASH(D.SN D.ASH D.EVT)
           */
           trunc(sample_time, 'MI') sample_time, user_id, sum(&C_SMP_INT_ASH_HIST) cnt
    from dba_hist_wr_control c,
         dba_hist_snapshot s,
         dba_hist_active_sess_history d
    where 1 = :scan_history -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
      /* JOINS - INICIO */
      and s.dbid = c.dbid
      and d.snap_id = s.snap_id
      and s.dbid = d.dbid
      and s.instance_number = d.instance_number
      /* JOINS - FIM */
      and s.end_interval_time > (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') - c.snap_interval)     -- Considera snapshots adjacentes, pois o sample_time
      and s.begin_interval_time < (to_timestamp(:end_date, '&C_DT_INPUT_FMT') + c.snap_interval)   -- pode ser menor do que o begin_interval_time
      and (d.sample_time >= to_timestamp(:ini_date, '&C_DT_INPUT_FMT') and d.sample_time < to_timestamp(:end_date, '&C_DT_INPUT_FMT'))
      and d.sample_time < to_timestamp(:ash_min_time, '&C_TSTP_FMT')
      and s.instance_number = sys_context('USERENV', 'INSTANCE')
      and s.dbid = (select dbid from v$database)
      and lower(nvl(d.event, 'ON CPU')) like lower(:event_name)
    group by trunc(sample_time, 'MI'), user_id
)
select sample,
       nvl(round(sum(aas), 2), 0) "AAS-Sample",
       '|'||max(decode(rn, 1, u.username, null)) "|USER-1st",
       round(max(decode(rn, 1, aas, null)), 2) "AAS-1st",
       lpad(to_char(max(decode(rn, 1, pct, null)), '&C_PCT_FMT')||'|', &C_PCT_WIDTH, ' ') "(%)-1st|",
       '|'||max(decode(rn, 2, u.username, null)) "|USER-2nd",
       round(max(decode(rn, 2, aas, null)), 2) "AAS-2nd",
       lpad(to_char(max(decode(rn, 2, pct, null)), '&C_PCT_FMT')||'|', &C_PCT_WIDTH, ' ') "(%)-2nd|",
       '|'||max(decode(rn, 3, u.username, null)) "|USER-3rd",
       round(max(decode(rn, 3, aas, null)), 2) "AAS-3rd",
       lpad(to_char(max(decode(rn, 3, pct, null)), '&C_PCT_FMT')||'|', &C_PCT_WIDTH, ' ') "(%)-3rd|",
       '|'||max(decode(rn, 4, u.username, null)) "|USER-4th",
       round(max(decode(rn, 4, aas, null)), 2) "AAS-4th",
       lpad(to_char(max(decode(rn, 4, pct, null)), '&C_PCT_FMT')||'|', &C_PCT_WIDTH, ' ') "(%)-4th|"
from
(
    select t1.dt sample,
           e.user_id,
           sum(cnt)/(60*:smp_int) aas,
           ratio_to_report(sum(cnt)/(60*:smp_int)) over (partition by t1.dt) * 100 pct,
           row_number() over (partition by t1.dt order by sum(cnt)/(60*:smp_int) desc) rn
    from t1
    left outer join events e on e.sample_time >= t1.dt and e.sample_time < t1.next_dt
    group by t1.dt, e.user_id
) t
left outer join dba_users u on t.user_id = u.user_id
group by sample
order by sample
/

undef 1 2 3 4
undef p_smp_int p_ini_date p_end_date p4
undef C_SMP_INT_ASH C_SMP_INT_ASH_HIST C_USER_WIDTH C_NUM_TOP_EVT C_PCT_FMT C_DT_INPUT_FMT C_AAS_FMT C_GRP_WIDTH C_TSTP_FMT C_SMP_WIDTH
clear columns

@%temp%\sqlenv
prompt
