select count(1) Remotas
from cm_conn_period p
where p.discon_reason_id = 0;