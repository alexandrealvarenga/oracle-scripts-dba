REM Filename      : maxshrink.sql
REM Author        : Craig Richards - originally from Asktom.oracle.com
REM Created       :
REM Version       : 1.0
REM Modifications : Lucas Lellis - 2014/06/06 - snapshot of dba_extents; free space threshold; tablespace filter
REM
REM Description   : Displays the size your datafiles can be shrunk to, it also generates the commands for you
REM Examples      : @maxshrink
REM                 @maxshrink d3%
SET VERIFY OFF

DEFINE PCT_THRES=0 -- Minimum free space in percentage

COLUMN tablespace_name FORMAT a30 word_wrapped
COLUMN file_name FORMAT a100 word_wrapped
COLUMN smallest FORMAT 999G990 HEADING "Smallest|Size|Poss."
COLUMN currsize FORMAT 999G990 HEADING "Current|Size"
COLUMN savings  FORMAT 999G990 HEADING "Poss.|Savings"

BREAK ON report

COMPUTE sum of savings on report

COLUMN value new_val blksize noprint
COLUMN exec_dt new_val dt noprint
set feed off
SELECT value FROM v$parameter WHERE name = 'db_block_size'
/
SELECT to_char(sysdate, 'YYYYMMDDHH24MISS') exec_dt FROM dual
/
set feed on

-- Defines first parameter's default value
set feed off term off
col p1 new_value 1
select null p1 from dual where  1=2;
select nvl('&1','%') p1 from dual;
set feed on term on

prompt creating snapshot of dba_extents (it might take a few minutes)...
create global temporary table my_ext_&_USER._&dt
on commit preserve rows
as
SELECT file_id, max(block_id+blocks-1) hwm
 FROM dba_extents
WHERE lower(tablespace_name) like lower('&1')
group by file_id;

SELECT tablespace_name,
       file_name,
       CASE WHEN CEIL( blocks*&&blksize/1024/1024 ) < (NVL(hwm,1)*&&blksize)/1024/1024 / (1-&PCT_THRES/100.0)
           THEN blocks*&&blksize/1024/1024
           ELSE (NVL(hwm,1)*&&blksize)/1024/1024 / (1-&PCT_THRES/100.0)
       END smallest,
       CEIL( blocks*&&blksize/1024/1024 ) currsize,
       CASE WHEN (blocks*&&blksize/1024/1024) < (NVL(hwm,1)*&&blksize)/1024/1024 / (1-&PCT_THRES/100.0)
           THEN 0
           ELSE CEIL( blocks*&&blksize/1024/1024) -
                CEIL( (NVL(hwm,1)*&&blksize)/1024/1024 / (1-&PCT_THRES/100.0) )
       END savings
FROM dba_data_files a,
     ( SELECT file_id, hwm
         FROM my_ext_&_USER._&dt ) b
WHERE a.file_id = b.file_id(+)
  AND lower(a.tablespace_name) like lower('&1')
ORDER BY savings desc
/

COLUMN cmd FORMAT a150 word_wrapped

SELECT 'alter database datafile '''||file_name||''' resize ' ||
       CEIL( (NVL(hwm,1)*&&blksize)/1024/1024 / (1-&PCT_THRES/100.0) )  || 'm;' cmd
FROM dba_data_files a,
     ( SELECT file_id, hwm
         FROM my_ext_&_USER._&dt ) b
WHERE a.file_id = b.file_id(+)
  AND CEIL( blocks*&&blksize/1024/1024) -
      CEIL( (NVL(hwm,1)*&&blksize)/1024/1024 / (1-&PCT_THRES/100.0) ) > 0
  AND lower(a.tablespace_name) like lower('&1')
ORDER BY file_name
/

rollback;
truncate table my_ext_&_USER._&dt;
drop table my_ext_&_USER._&dt purge;

clear columns
clear compute
undef 1 p1
REM End of Script
