set lines 180; 
set pages 999; 


select instance_number, begin_time, end_time, round(((value / 0.75) * 8)/1000000, 0) mbits_per_sec
from (
     select instance_number, begin_time, end_time, value, row_number() over (partition by instance_number order by value desc) rn
     from dba_hist_sysmetric_history 
     where metric_name = 'Redo Generated Per Sec'
     and dbid = (select dbid from v$database)
)
where rn = 1
order by instance_number;

col "Total" for 9999 justify right
col "00" for 9999 justify right
col "01" for 9999 justify right
col "02" for 9999 justify right
col "03" for 9999 justify right
col "04" for 9999 justify right
col "05" for 9999 justify right
col "06" for 9999 justify right
col "07" for 9999 justify right
col "08" for 9999 justify right
col "09" for 9999 justify right
col "10" for 9999 justify right
col "11" for 9999 justify right
col "12" for 9999 justify right
col "13" for 9999 justify right
col "14" for 9999 justify right
col "15" for 9999 justify right
col "16" for 9999 justify right
col "17" for 9999 justify right
col "18" for 9999 justify right
col "19" for 9999 justify right
col "20" for 9999 justify right
col "21" for 9999 justify right
col "22" for 9999 justify right
col "23" for 9999 justify right

SELECT 
to_char(trunc(first_time), 'DD/MM/YYYY') day,
round((((sum(decode(to_char(first_time,'HH24'),'00',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "00",
round((((sum(decode(to_char(first_time,'HH24'),'01',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "01",
round((((sum(decode(to_char(first_time,'HH24'),'02',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "02",
round((((sum(decode(to_char(first_time,'HH24'),'03',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "03",
round((((sum(decode(to_char(first_time,'HH24'),'04',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "04",
round((((sum(decode(to_char(first_time,'HH24'),'05',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "05",
round((((sum(decode(to_char(first_time,'HH24'),'06',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "06",
round((((sum(decode(to_char(first_time,'HH24'),'07',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "07",
round((((sum(decode(to_char(first_time,'HH24'),'08',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "08",
round((((sum(decode(to_char(first_time,'HH24'),'09',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "09",
round((((sum(decode(to_char(first_time,'HH24'),'10',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "10",
round((((sum(decode(to_char(first_time,'HH24'),'11',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "11",
round((((sum(decode(to_char(first_time,'HH24'),'12',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "12",
round((((sum(decode(to_char(first_time,'HH24'),'13',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "13",
round((((sum(decode(to_char(first_time,'HH24'),'14',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "14",
round((((sum(decode(to_char(first_time,'HH24'),'15',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "15",
round((((sum(decode(to_char(first_time,'HH24'),'16',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "16",
round((((sum(decode(to_char(first_time,'HH24'),'17',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "17",
round((((sum(decode(to_char(first_time,'HH24'),'18',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "18",
round((((sum(decode(to_char(first_time,'HH24'),'19',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "19",
round((((sum(decode(to_char(first_time,'HH24'),'20',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "20",
round((((sum(decode(to_char(first_time,'HH24'),'21',1,0))*redo_size/3600) / 0.75) * 8)/1000000, 0) "21",
round((((sum(decode(to_char(first_time,'HH24'),'22',1,0))*314572800/3600) / 0.75) * 8)/1000000, 0) "22",
round((((sum(decode(to_char(first_time,'HH24'),'23',1,0))*314572800/3600) / 0.75) * 8)/1000000, 0) "23"
from
v$log_history h
cross join (select max(bytes) redo_size from v$log) l
GROUP by trunc(first_time), redo_size
order by trunc(first_time);

clear columns
