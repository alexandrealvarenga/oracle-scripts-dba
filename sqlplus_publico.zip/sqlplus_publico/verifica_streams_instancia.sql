column owner format a30
column table_name format a30
column column_name format a30
column data_type format a20
column reason format a39
col auto_filtered format a30

set echo off verify off feed off lines 3000

accept inst prompt 'Instancia: '
accept owner prompt 'Owner: '
accept usuario prompt 'Usuario: '
accept senha prompt 'Senha: ' hide

set term off
conn &usuario/&senha@&inst

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

spool %temp%\relatorio_streams_&inst._&wdt..txt

set head off term on
SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set head on

col srvd new_val servidor noprint
select host_name srvd from v$instance;

set feed on
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando objetos n�o-suportados
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt
select owner, table_name, reason,auto_filtered
from dba_streams_unsupported
where owner = upper('&OWNER');


prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando a existencia de colunas do tipo LOB, LONG e RAW
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt
select owner, table_name, column_name, data_type
from dba_tab_columns
where owner = upper('&OWNER')
and (data_type like '%LOB' or
     data_type like '%RAW' or
     data_type like 'LONG%');
     
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando tabelas sem PK ou indice unico
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt
select table_name
from dba_tables
where owner = upper('&OWNER')
and (table_name not in (select table_name
                        from dba_constraints
                        where constraint_type = 'P')
     and
     table_name not in (select table_name
                        from dba_indexes
                        where uniqueness = 'UNIQUE')
    )
order by table_name;


column Nome format a30
column Valor format a30
column "Valor desejado" format a30
column Acao format a20
set feed off
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando parametros da instancia
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt
prompt >> AQ_TM_PROCESSES
select name Nome, value Valor, '4' "Valor desejado", DECODE(value, 4, 'OK', 'Deve ser alterado') Acao
from v$parameter
where name = 'aq_tm_processes';
prompt

prompt >> GLOBAL_NAMES
select name Nome, value Valor, 'True' "Valor desejado", DECODE(value, 'TRUE', 'OK', 'Deve ser alterado') Acao
from v$parameter
where name = 'global_names';
prompt

prompt >> COMPATIBLE
select name Nome, value Valor, '10.2%' "Valor desejado", 
	CASE
		WHEN value LIKE '10.2%' THEN 'OK'
		ELSE 'Deve ser alterado'
	END Acao
from v$parameter
where name = 'compatible';
prompt

prompt >> JOB_QUEUE_PROCESSES
select name Nome, value Valor, '>=4' "Valor desejado", 
	CASE
		WHEN to_number(value) >= 4 THEN 'OK'
		ELSE 'Deve ser alterado'
	END Acao
from v$parameter
where name = 'job_queue_processes';
prompt

prompt >> _JOB_QUEUE_INTERVAL
select name Nome, value Valor, '1' "Valor desejado", DECODE(value, 1, 'OK', 'Deve ser alterado') Acao
from v$parameter
where name = '_job_queue_interval';
prompt

prompt >> TIMED_STATISTICS
select name Nome, value Valor, 'True' "Valor desejado", DECODE(value, 'TRUE', 'OK', 'Deve ser alterado') Acao
from v$parameter
where name = 'timed_statistics';
prompt

prompt >> STATISTICS_LEVEL
select name Nome, value Valor, 'Typical' "Valor desejado", DECODE(value, 'TYPICAL', 'OK', 'Deve ser alterado') Acao
from v$parameter
where name = 'statistics_level';
prompt

prompt >> SHARED_POOL_SIZE
select name Nome, to_char(value/power(1024, 2))||'M' Valor, '256M' "Valor desejado", 
	CASE
		WHEN value/power(1024, 2) >= 256 THEN 'OK'
		ELSE 'Deve ser alterado'
	END Acao
from v$parameter
where name = 'shared_pool_size';
prompt

prompt >> STREAMS_POOL_SIZE
select name Nome, to_char(value/power(1024, 2))||'M' Valor, '256M' "Valor desejado", 
	CASE
		WHEN value/power(1024, 2) >= 256 THEN 'OK'
		ELSE 'Deve ser alterado'
	END Acao
from v$parameter
where name = 'streams_pool_size';
prompt

prompt >> DB_DOMAIN
select name Nome, value Valor, 'NOT NULL' "Valor desejado", 
	CASE
		WHEN not value is null THEN 'OK'
		ELSE 'Deve ser alterado'
	END Acao
from v$parameter
where name = 'db_domain';
prompt

prompt >> SERVICE_NAMES
select name Nome, value Valor
from v$parameter
where name = 'service_names';
prompt

column SUPPLEMENTAL_LOG_DATA_MIN format a25
column SUPPLEMENTAL_LOG_DATA_PK format a25
column SUPPLEMENTAL_LOG_DATA_UI format a25
prompt
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando nivel de supplemental log
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt
SELECT
  SUPPLEMENTAL_LOG_DATA_MIN,
  SUPPLEMENTAL_LOG_DATA_PK,
  SUPPLEMENTAL_LOG_DATA_UI
FROM
  V$DATABASE;

set feed on
column username format a30
column account_status format a10
column default_tablespace format a30
column temporary_tablespace format a30
prompt
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando usuario STRMADMIN
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt
select username, account_status, default_tablespace, temporary_tablespace
from dba_users
where username = 'STRMADMIN';


set echo off verify off feed off term off head off
conn &USUARIO/&SENHA@producao_orapvt041
set term on

SELECT ('User: ' || user || ' on database ' || global_name || '  Data: ' || TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS'))
FROM global_name;
set head on feed on
prompt
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt >>> Verificando Patchset
prompt >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
prompt

col lbl_hostname for a12
col lbl_productname for a10
col lbl_baseversion for a30
col lbl_oraclehome for a30
col lbl_patchsets for a30
col lbl_interimpatches for a30
col lbl_bugsfixedbyint for a30
col lbl_componentname for a30
col lbl_INSTALL_TIMESTAMP for a30
SELECT lbl_hostname, lbl_productname, lbl_baseversion, lbl_oraclehome,
       lbl_patchsets, lbl_interimpatches, lbl_bugsfixedbyint,
       lbl_componentname,lbl_INSTALL_TIMESTAMP
  FROM (SELECT 'host' AS lbl_targettype, m.INSTALL_TIMESTAMP lbl_INSTALL_TIMESTAMP,m.external_name lbl_productname,
               m.NAME lbl_componentname, m.base_version lbl_baseversion,
               m.patchsets_in_home lbl_patchsets, m.host_name lbl_hostname,
               m.home_name lbl_homename,
               m.home_location || ' (' || m.home_name
               || ')' AS lbl_oraclehome,
               m.interim_patches_in_home lbl_interimpatches,
               m.bugs_fixed_by_interim_patches lbl_bugsfixedbyint
          FROM mgmt$software_components m
         WHERE is_top_level = 'Y'
         order by lbl_INSTALL_TIMESTAMP desc)
 WHERE (NLS_UPPER (lbl_hostname) = NLS_UPPER ('&servidor'))
/

prompt
disc
prompt

spool off
prompt
prompt
prompt Relatorio disponivel em %temp%\relatorio_streams_&inst._&wdt..txt
prompt
prompt
undef usuario
undef senha
undef instancia
undef owner
