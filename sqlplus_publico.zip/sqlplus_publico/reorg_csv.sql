----------------------------------------------------------
-- Levantamento de tabelas com necessidade de reorg
-- 
-- Baseado na procedure show_space do livro
-- Expert Oracle Database Architecture (Tom Kyte)
-- Criado por: Alexandre Soares (c0092973@vale.com) - 23/08/2012
-- Alteracoes:
--  19/09/2012 - Lucas Lellis - lucas.lellis@cgi.com
--                  - Parametros de input
--                  - Geracao de relatorio
--                  - Ordenacao por blocos FS4
--                  - Inclusao do TABLE PARTITION
--                  - Inclusao dos comandos de shrink
--  09/12/2013 - Lucas Lellis - lucas.lellis@cgi.com
--                  - Inclus�o da fragmenta��o m�dia
--                  - Inclus�o da lista de par�metros usados
----------------------------------------------------------
--conn / as sysdba
set serveroutput on echo off feed off verify off linesize 500 trimspool on

alter session set NLS_NUMERIC_CHARACTERS=',.';
alter session set nls_date_format='DD/MM/YYYY HH24:MI:SS';
select sysdate from dual;

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

define ow = "'LF'"
prompt

spool c:\temp\reorg_all_&wdt..txt

DECLARE
	TYPE t_storage IS RECORD (
        l_free_blks          NUMBER DEFAULT 0,
        l_total_blocks       NUMBER DEFAULT 0,
        l_total_bytes        NUMBER DEFAULT 0,
        l_unused_blocks      NUMBER DEFAULT 0,
        l_unused_bytes       NUMBER DEFAULT 0,
        l_lastusedextfileid  NUMBER DEFAULT 0,
        l_lastusedextblockid NUMBER DEFAULT 0,
        l_last_used_block    NUMBER DEFAULT 0,
        l_segment_space_mgmt VARCHAR2(255),
        l_unformatted_blocks NUMBER DEFAULT 0,
        l_unformatted_bytes  NUMBER DEFAULT 0,
        l_fs1_blocks         NUMBER DEFAULT 0,
        l_fs1_bytes          NUMBER DEFAULT 0,
        l_fs2_blocks         NUMBER DEFAULT 0,
        l_fs2_bytes          NUMBER DEFAULT 0,
        l_fs3_blocks         NUMBER DEFAULT 0,
        l_fs3_bytes          NUMBER DEFAULT 0,
        l_fs4_blocks         NUMBER DEFAULT 0,
        l_fs4_bytes          NUMBER DEFAULT 0,
        l_full_blocks        NUMBER DEFAULT 0,
        l_full_bytes         NUMBER DEFAULT 0,
        c_tab                VARCHAR2(50),
        c_own                VARCHAR2(50),
        c_seg_type           VARCHAR2(30),
        c_part_name          VARCHAR2(30)
    );
    l_temp_seg_type	VARCHAR2(30);

    TYPE tab_storage IS TABLE OF t_storage;
    
    v_info_storage tab_storage := tab_storage();
    r_info_storage t_storage;
    
    i               number := 0;
    avg_frag        number(10,4) := 0.0;
    total_mb    	number := 0;
    
    -- inline procedure to print out numbers nicely formatted
    -- with a simple label
    PROCEDURE p(p_label IN VARCHAR2,
                p_num   IN NUMBER) IS
    BEGIN
        dbms_output.put_line(rpad(p_label, 40, '.') || to_char(p_num, 'fm999G999G999G990D00'));
    END;

     PROCEDURE insort_desc(p_storage_info_col IN OUT tab_storage, p_storage IN t_storage) IS
         i number := 1;
     BEGIN
         p_storage_info_col.extend;
         
         i := p_storage_info_col.count - 1;
                
         while (i > 0) and (p_storage_info_col(i).l_fs4_blocks < p_storage.l_fs4_blocks) loop
            p_storage_info_col(i+1) := p_storage_info_col(i);
            i := i - 1;
         end loop;
         p_storage_info_col(i+1) := p_storage;
     END;

    -- Test statements here
BEGIN
	FOR c_tabelas IN (SELECT owner
                            ,segment_name
                            ,partition_name
                            ,segment_type
                        FROM dba_segments
                        where segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION', 'LOBSEGMENT')
                        and upper(owner) in (&ow))
    LOOP
        BEGIN
            r_info_storage.c_tab := c_tabelas.segment_name;
            r_info_storage.c_own := c_tabelas.owner;
            r_info_storage.c_seg_type := c_tabelas.segment_type;
            r_info_storage.c_part_name := c_tabelas.partition_name;
            
            select ts.segment_space_management
            into r_info_storage.l_segment_space_mgmt
            from dba_segments seg, dba_tablespaces ts
            where seg.segment_name = r_info_storage.c_tab
            and (seg.partition_name = r_info_storage.c_part_name or r_info_storage.c_part_name is null)
            and seg.owner = r_info_storage.c_own
            and segment_type = r_info_storage.c_seg_type
            and seg.tablespace_name = ts.tablespace_name;

            IF r_info_storage.c_seg_type = 'LOBSEGMENT' THEN
            	l_temp_seg_type := 'LOB';
            ELSE
            	l_temp_seg_type := r_info_storage.c_seg_type;
            END IF;
            
            IF r_info_storage.l_segment_space_mgmt = 'AUTO'  THEN
                dbms_space.space_usage(
                	segment_owner      => r_info_storage.c_own,
					segment_name       => r_info_storage.c_tab,
					segment_type       => l_temp_seg_type,
					unformatted_blocks => r_info_storage.l_unformatted_blocks,
					unformatted_bytes  => r_info_storage.l_unformatted_blocks,
					fs1_blocks         => r_info_storage.l_fs1_blocks,
					fs1_bytes          => r_info_storage.l_fs1_bytes,
					fs2_blocks         => r_info_storage.l_fs2_blocks,
					fs2_bytes          => r_info_storage.l_fs2_bytes,
					fs3_blocks         => r_info_storage.l_fs3_blocks,
					fs3_bytes          => r_info_storage.l_fs3_bytes,
					fs4_blocks         => r_info_storage.l_fs4_blocks,
					fs4_bytes          => r_info_storage.l_fs4_bytes,
					full_blocks        => r_info_storage.l_full_blocks,
					full_bytes         => r_info_storage.l_full_bytes,
					partition_name     => r_info_storage.c_part_name
                );
            ELSE
                dbms_space.free_blocks(segment_owner => r_info_storage.c_own, segment_name => r_info_storage.c_tab, segment_type => l_temp_seg_type, freelist_group_id => 0, free_blks => r_info_storage.l_free_blks);
            END IF;
            -- and then the unused space API call to get the rest of the
            -- information
            dbms_space.unused_space(segment_owner => r_info_storage.c_own, segment_name => r_info_storage.c_tab, segment_type => l_temp_seg_type, 
                   total_blocks => r_info_storage.l_total_blocks, 
                   total_bytes => r_info_storage.l_total_bytes,unused_blocks => r_info_storage.l_unused_blocks, 
                   unused_bytes => r_info_storage.l_unused_bytes, last_used_extent_file_id => r_info_storage.l_lastusedextfileid, 
                   last_used_extent_block_id => r_info_storage.l_lastusedextblockid,
               	   last_used_block => r_info_storage.l_last_used_block, partition_name=>r_info_storage.c_part_name);

            insort_desc(v_info_storage, r_info_storage);
       END;      
    END LOOP;
    
    dbms_output.put_line('"Owner","Segment Name","Segment Type","Space Mgmt","Partition Name","Total MB","Avg Frag %","Avg Frag MB"');

    IF v_info_storage.count > 0 THEN
         FOR i in v_info_storage.first..v_info_storage.last
         LOOP
                avg_frag := (((v_info_storage(i).l_fs1_blocks/v_info_storage(i).l_total_blocks) * 0.25) +
                            ((v_info_storage(i).l_fs2_blocks/v_info_storage(i).l_total_blocks) * 0.50) +
                            ((v_info_storage(i).l_fs3_blocks/v_info_storage(i).l_total_blocks) * 0.75) +
                            (v_info_storage(i).l_fs4_blocks/v_info_storage(i).l_total_blocks)) * 100;
                total_mb := trunc(v_info_storage(i).l_total_bytes / 1024 / 1024);                
                
                dbms_output.put_line('"'||v_info_storage(i).c_own||'","'||v_info_storage(i).c_tab||'","'||v_info_storage(i).c_seg_type||'","'||r_info_storage.l_segment_space_mgmt||'","'||v_info_storage(i).c_part_name||'","'||to_char(v_info_storage(i).l_total_bytes/1024/1024, 'fm999999999990D00')||'","'||to_char(round(avg_frag, 2), 'fm999999999990D00')||'","'||to_char(total_mb*avg_frag/100, 'fm999999999990D00')||'"'); 
               
         END LOOP;
    END IF;
END;
/

spool off

prompt
prompt ed c:\temp\reorg_all_&wdt..txt
prompt
select sysdate from dual;
prompt
exit
