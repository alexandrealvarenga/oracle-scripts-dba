-- recomp.sql
-- Script para recompilar objetos invalidos no Oracle
-- Autor: Lucas Pimentel Lellis
-- Data:  10/11/2011


set serveroutput on
declare
	PCT_CPU_CORE_MAX	constant number := 0.2;
	PARALLEL_DEG_MIN	constant number := 4;
	
	parallel_degree number;
begin
	select ceil(value * PCT_CPU_CORE_MAX)
	into parallel_degree
	from v$parameter
	where name = 'cpu_count';
	
	if parallel_degree <= PARALLEL_DEG_MIN then
		parallel_degree := PARALLEL_DEG_MIN;
	end if;
	
	dbms_output.put_line('Grau de paralelismo: ' || parallel_degree);
	sys.utl_recomp.recomp_parallel(parallel_degree);
end;
/
set serveroutput on
