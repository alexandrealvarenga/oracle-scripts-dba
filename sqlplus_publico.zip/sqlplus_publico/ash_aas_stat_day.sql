/* ASH_AAS_STAT_DAY.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Contagem de AAS (Average Active Sessions) por periodo e com calculos estatisticos, comparando periodos semalhantes do dia.
 *             O periodo minimo de comparacao eh de &C_MIN_INTERVAL dias e o intervalo de comparacao eh ajustado para dias completos.
 * Utilizacao: @ash_aas_stat intervalo dt_inicial dt_final (intervalo em minutos, data no formato YYYYMMDDHH24MI)
 *             @ash_aas_stat intervalo last periodo_minutos
 *            
 * Exemplos: @ash_aas_stat 1 201404291000 201405011000
 *           @ash_aas_stat 60 last 60*24*2
 *
 * Baseado no script ash_graph_waits_histash.sql de Kyle Hailey, em https://github.com/khailey/ashmasters
 * Ref.: http://www.oraclerealworld.com/ash-masters/
 */

store set %temp%\sqlenv replace

set verify off echo off lines 180 pages 20 serveroutput on

set feed off
alter session set nls_timestamp_format='DD/MM/RR HH24:MI';
set feed on

define C_SMP_INT_ASH=1                  -- Intervalo de amostragem da view V$ACTIVE_SESSION_HISTORY (em segundos)
define C_SMP_INT_ASH_HIST=10            -- Intervalo de amostragem da view DBA_HIST_ACTIVE_SESS_HISTORY (em segundos)
define C_DAY_WIDTH=10                   -- Largura do display do dia
define C_PCT_FMT=999990.00              -- Formato de display do percentil
define C_AAS_FMT=9990.00                -- Formato de display do AAS
define C_DT_INPUT_FMT=YYYYMMDDHH24MI    -- Formato de input de data
define C_TSTP_FMT=YYYYMMDDHH24MISSFF    -- Formato de conversao de timestamp para varchar
define C_PER_WIDTH=7                    -- Largura da coluna de periodo
define C_OVER_THRES_WIDTH=10            -- Largura da coluna do grafico de threshold
define C_MIN_INTERVAL=2                 -- Intervalo minimo (em dias)

define p_smp_int=&1
define p_ini_date=&2
define p_end_date=&3

variable smp_int number
variable smp_period number
variable ini_date varchar2(20)
variable end_date varchar2(20)
variable scan_history number
variable ash_min_time varchar2(30)

set feed off
declare
    l_ash_min_time timestamp := null;
    l_cpu_count number := 0;
    l_smp_period_interval interval day to second;
    l_version number;
    l_orig_ind_date varchar2(50);
begin
    :smp_int := &p_smp_int;
    :ini_date := upper('&p_ini_date');
    
    if (:ini_date = 'LAST') then
        :ini_date := to_char(systimestamp - numtodsinterval(&p_end_date, 'minute'), '&C_DT_INPUT_FMT');
        :end_date := to_char(systimestamp, '&C_DT_INPUT_FMT');
    else
        :ini_date := '&p_ini_date';
        :end_date := '&p_end_date';
    end if;
    l_orig_ind_date := :ini_date;
    
    l_smp_period_interval := to_timestamp(:end_date, '&C_DT_INPUT_FMT') - to_timestamp(:ini_date, '&C_DT_INPUT_FMT');
    :smp_period := 24*60*extract(day from l_smp_period_interval) + 60*extract(hour from l_smp_period_interval) + extract(minute from l_smp_period_interval);
    -- Corrige o intervalo analisado caso o original seja menor do que &C_MIN_INTERVAL dias
    if mod(:smp_period, 24*60) <> 0 then
        :smp_period := ceil(:smp_period/(24*60))*(24*60);
        if (:smp_period < (24*60)*&C_MIN_INTERVAL) then
            :smp_period := (24*60)*&C_MIN_INTERVAL;
        end if;
        :ini_date := to_char(to_timestamp(:end_date, '&C_DT_INPUT_FMT')-numtodsinterval(:smp_period, 'MINUTE'), '&C_DT_INPUT_FMT');
        l_smp_period_interval := to_timestamp(:end_date, '&C_DT_INPUT_FMT') - to_timestamp(:ini_date, '&C_DT_INPUT_FMT');
    end if;
    
    if :smp_int > :smp_period then
        :smp_int := :smp_period;
        dbms_output.put_line('Sampling Interval - corrected: '||:smp_int);
    end if;
    
    -- Ajusta o horario de inicio caso o intervalo nao seja multiplo do periodo analisado
    if mod(:smp_period, :smp_int) <> 0 then
        :smp_period := ceil(:smp_period/:smp_int) * :smp_int; 
        :ini_date := to_char((to_date(:end_date, '&C_DT_INPUT_FMT') - :smp_period/60/24), '&C_DT_INPUT_FMT');
    end if;
    
    if (:ini_date <> l_orig_ind_date) then
        dbms_output.put_line('Analyzed Period - corrected: '||to_date(:ini_date, '&C_DT_INPUT_FMT')
                        ||' - '||to_date(:end_date, '&C_DT_INPUT_FMT'));
    end if;
    
    select min(sample_time)
    into l_ash_min_time
    from v$active_session_history;
     -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
     -- Ref: http://optimizermagic.blogspot.com.br/2008/06/why-are-some-of-tables-in-my-query.html
    if (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') < l_ash_min_time) then
       :scan_history := 1;
    else
       :scan_history := 2;
    end if;
    :ash_min_time := to_char(l_ash_min_time, '&C_TSTP_FMT');
    
    select value
    into l_cpu_count
    from v$parameter
    where upper(name) = 'CPU_COUNT';
    
    select to_number(replace(version, '.', ''))
    into l_version
    from v$instance;
    
    -- CONNECT BY query or view fails with ORA-600 [kkqcbydrv:1] (Doc ID 749788.1)
    if l_version < 102050 then
        execute immediate 'alter session set "_optimizer_connect_by_cost_based"=false';
    end if;
    
    dbms_output.put_line(chr(10)||'CPU Count: '||l_cpu_count
                       ||chr(10)||'AAS - Average Active Sessions');
    dbms_output.put_line(chr(10)||
                         '###################################'||chr(10)||
                         '# Caption: ');
    dbms_output.put_line('# *****      - Over 95th Percentile'||chr(10)||
                         '# ********** - Over 99th Percentile'||chr(10)||
                         '###################################');
end;
/
set feed on

col day for a&C_DAY_WIDTH justify right
col period for a&C_PER_WIDTH justify right heading "Period"
col aas for &C_AAS_FMT
col pct_50th_sample for &C_PCT_FMT heading "50th-Percentile|(AAS)" justify right
col pct_95th_sample for &C_PCT_FMT heading "95th-Percentile|(AAS)" justify right
col pct_99th_sample for &C_PCT_FMT heading "99th-Percentile|(AAS)" justify right
col avg_aas for &C_PCT_FMT heading "Average|(AAS)" justify right
col stddev_aas for &C_PCT_FMT heading "Standard|Deviation|(AAS)" justify right
col over_threshold for a&C_OVER_THRES_WIDTH heading 'Over|Threshold'

break on period skip page on pct_50th_sample on pct_95th_sample on pct_99th_sample on avg_aas on stddev_aas

-- Observacoes:
-- - O intervalo de amostragem da view v$active_session_history é diferente do intervalo
--   da view dba_hist_active_sess_history.
-- - A inline view t1 eh usada para gerar os intervalos de amostragem
-- - O outer join com a view t1, necessario para mostrar os periodos sem atividade, nao eh feito
--   nas queries internas para nao gerar contagem de eventos nulos
-- - E necessario ajustar manualmente a cardinalidade da inline view t1. 100 eh um valor suficiente
--   para que se evite nested loops no join com a inline view de events
with aas
as
(
    select /*+ MATERIALIZE */
           t1.dt sample,
           nvl(round(sum(cnt)/(60*:smp_int), 2), 0) aas
      from (
                select /*+ OPT_ESTIMATE(TABLE, D, ROWS=100) */
                       to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level, 'minute')*:smp_int dt, 
                       to_timestamp(:end_date, '&C_DT_INPUT_FMT') - numtodsinterval(level-1, 'minute')*:smp_int next_dt
                from dual d
                connect by level <= (:smp_period/:smp_int)
           ) t1 
      left outer join
          (
                select trunc(sample_time, 'MI') sample_time, sum(&C_SMP_INT_ASH) cnt
                from v$active_session_history h
                where (h.sample_time >= to_date(:ini_date, '&C_DT_INPUT_FMT') and h.sample_time < to_date(:end_date, '&C_DT_INPUT_FMT'))
                group by trunc(sample_time, 'MI')
                union all
                select trunc(sample_time, 'MI') sample_time, sum(&C_SMP_INT_ASH_HIST) cnt
                from dba_hist_wr_control c
                join dba_hist_snapshot s on s.dbid = c.dbid
                join dba_hist_active_sess_history d on d.snap_id = s.snap_id and s.dbid = d.dbid and s.instance_number = d.instance_number
                where 1 = :scan_history -- Evita ler a view dba_hist_active_sess_history caso o intervalo seja coberto pela view do ASH
                  and s.end_interval_time > (to_timestamp(:ini_date, '&C_DT_INPUT_FMT') - c.snap_interval)     -- Considera snapshots adjacentes, pois o sample_time
                  and s.begin_interval_time < (to_timestamp(:end_date, '&C_DT_INPUT_FMT') + c.snap_interval)   -- pode ser menor do que o begin_interval_time
                  and (d.sample_time >= to_timestamp(:ini_date, '&C_DT_INPUT_FMT') and d.sample_time < to_timestamp(:end_date, '&C_DT_INPUT_FMT'))
                  and d.sample_time < to_timestamp(:ash_min_time, '&C_TSTP_FMT')
                  and s.instance_number = sys_context('USERENV', 'INSTANCE')
                  and s.dbid = (select dbid from v$database)
                group by trunc(sample_time, 'MI')
           ) e on e.sample_time >= t1.dt and e.sample_time < t1.next_dt
    group by t1.dt
)
select lpad(to_char(sample, 'HH24:MI'), &C_PER_WIDTH, ' ') period,
       pct_50th_sample,
       pct_95th_sample,
       pct_99th_sample,
       avg_aas,
       stddev_aas,
       lpad(to_char(sample, 'DD/MM/RR'), &C_DAY_WIDTH, ' ') day,
       aas,
       case
           when aas > pct_99th_sample then '**********'
           when aas > pct_95th_sample then '*****'
       end over_threshold
from (
    select sample,
           aas,
           percentile_cont(0.50) within group (order by aas) over (partition by to_char(sample, 'HH24:MI')) pct_50th_sample,
           percentile_cont(0.95) within group (order by aas) over (partition by to_char(sample, 'HH24:MI')) pct_95th_sample,
           percentile_cont(0.99) within group (order by aas) over (partition by to_char(sample, 'HH24:MI')) pct_99th_sample,
           avg(aas) over (partition by to_char(sample, 'HH24:MI')) avg_aas,
           stddev(aas) over (partition by to_char(sample, 'HH24:MI')) stddev_aas
    from aas
)
order by period, sample;

undef 1 2 3 4
undef p_smp_int p_ini_date p_end_date p4
undef C_SMP_INT_ASH C_SMP_INT_ASH_HIST C_EVT_WIDTH C_PCT_FMT C_AAS_FMT C_DT_INPUT_FMT C_TSTP_FMT C_DAY_WIDTH C_PER_WIDTH C_OVER_THRES_WIDTH C_MIN_INTERVAL
clear columns
clear breaks

@%temp%\sqlenv
prompt
