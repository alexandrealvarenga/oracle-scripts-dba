------------------------------------------------------------------------------------------------------------------------------
--       Nome : gera_restore.sql
--      Autor : Lucas Pimentel Lellis (lucas.lellis@cgi.com)
-- Finalidade : Gerar script de restore RMAN
--
-- NAO USAR ESTE SCRIPT PARA DUPLICAR BASES EM OMF NO MESMO SERVIDOR, POIS OS REDO LOGS DA BASE DE ORIGEM SERAO CORROMPIDOS.
-- NESTE CASO, DEVE SER USADO O SCRIPT gera_duplicate.sql.
------------------------------------------------------------------------------------------------------------------------------


store set %temp%\sqlenv replace
prompt
prompt

set head off feed off verify off echo off pages 0 trimspool on newpage none define on serveroutput on
set lines 9999 pagesize 0

col dt new_val l_dt noprint
col sep new_val l_sep noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt, regexp_substr(name, '[/\]') sep
from v$datafile
where rownum < 2;

accept p_db_name_dest                               prompt 'DB Name (Destino).....................................: '
accept p_db_name_orig                               prompt 'DB Name (Origem)......................................: '
accept p_dir_base default '##CAMINHO_OMF##'         prompt 'Diret�rio base (OMF)..................................: '
accept p_dt_corte default '##DATA_CORTE##'          prompt 'Data de corte (yyyy-mm-dd hh24:mi:ss).................: '
accept p_oracle_home default '##ORACLE_HOME##'      prompt 'Oracle Home...........................................: '
accept p_host default '127.0.0.1'                   prompt 'Host de destino.......................................: '
accept p_porta default 1521                         prompt 'Porta do listener de destino..........................: '
accept p_senha_sys                                  prompt 'Senha do SYS..........................................: ' hide

accept p_cam_scr default c:\temp\restore_&l_dt..sql prompt 'Caminho do script (c:\temp\restore_&l_dt..sql): '
prompt

spool &p_cam_scr

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 01 - Criar diret�rios'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)
from dual;

select 'mkdir -p &p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.adump &p_dir_base&l_sep.'||upper('&p_db_name_dest')||'&l_sep.archive &p_dir_base&l_sep.'||upper('&p_db_name_dest')||'&l_sep.onlinelog'
from dual;

prompt
prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 02 - Gerar backup do control file na origem e copiar para o destino'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       'alter database backup controlfile to ''##BACKUP_CONTROLFILE##'';'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 03 - Criar init b�sico'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)
from dual;

select 'cat > &p_dir_base/'||upper('&p_db_name_dest')||'/init&p_db_name_dest..ora <<ENDEND'||chr(10)||
       'audit_file_dest=''&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.adump'''||chr(10)||
       'db_name=''&p_db_name_orig'''||chr(10)||
       'db_unique_name=''&p_db_name_dest'''||chr(10)||
       'instance_name=''&p_db_name_dest'''||chr(10)||
       'db_cache_size=1000M'||chr(10)||
       'large_pool_size=256M'||chr(10)||
       'db_files=2000'||chr(10)||
       'filesystemio_options=SETALL'||chr(10)||
       'control_files=''&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.control01.ctl'', ''&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.control02.ctl'''||chr(10)||
       'compatible='''||value||''''||chr(10)||
       'db_create_file_dest=''&p_dir_base'''||chr(10)||
       'db_create_online_log_dest_1=''&p_dir_base'''||chr(10)||
       'db_create_online_log_dest_2=''&p_dir_base'''||chr(10)||
       'log_archive_dest_1=''location=&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.archive'''
from v$parameter
where lower(name) = 'compatible';

declare
    l_cnt pls_integer := 1;
    l_buffer varchar2(32767) := 'log_file_name_convert=';
begin
    for r_cmd in (select distinct ''''||substr(member, 1, instr(member, '&l_sep', -1)-1)||''','''||'&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.onlinelog''' cmd
                  from v$logfile) loop
        if l_cnt > 1 then
            l_buffer := l_buffer||','||r_cmd.cmd;
        else
            l_buffer := l_buffer||r_cmd.cmd;
        end if;
        l_cnt := l_cnt + 1;
    end loop;
    dbms_output.put_line(l_buffer);
    dbms_output.put_line('ENDEND');
end;
/

prompt


prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 04 - Adicionar entrada no tnsnames.ora'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       '&p_db_name_dest=(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = &p_host)(PORT = &p_porta))) (CONNECT_DATA = (SID = &p_db_name_dest) (SERVER = DEDICATED)))'||chr(10)
from dual;


prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 05 - (Opcional) Adicionar registro est�tico no listener'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'
from dual;
select
q'[SID_LIST_LISTENER =
    (SID_LIST =
        (SID_DESC =
            (GLOBAL_DBNAME = &p_db_name_dest)
            (ORACLE_HOME = &p_oracle_home)
            (SID_NAME = &p_db_name_dest)
        )
    )
]' cmd
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 06 - (Opcional) Copiar password file da origem'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 07 - Subir instancia em mount com init criado no passo 3 e control file do passo 1'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       'export ORACLE_SID=&p_db_name_dest'||chr(10)||
       'sqlplus / as sysdba <<ENDEND'||chr(10)||
       'startup nomount pfile=''&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.init&p_db_name_dest..ora'';'||chr(10)||
       'alter database mount;'||chr(10)||
       'exit'||chr(10)||
       'ENDEND'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 08 - (Opcional) Gerar lista de tablespaces ignorados'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'
from dual;
set define off
select q'[
col cmd for a200

-- exemplo: define l_tbsp="'TOOLS','TD_ISA'"
define l_tbsp="##TABLESPACE##"

select tablespace_name
from (
    select tablespace_name, max(rn) rn
    from (
        select tablespace_name, segment_type, rownum rn
        from (
            select distinct ts.tablespace_name, segment_type
            from dba_tablespaces ts,
                 dba_segments sg
            where ts.tablespace_name = sg.tablespace_name(+)
            and (
                -----------------------------------------
                -- INSERIR TABLESPACES A SEREM COPIADOS
                ts.tablespace_name not in (&&l_tbsp) and
                -----------------------------------------
                -----------------------------------------
                ts.tablespace_name not in ('SYSTEM','SYSAUX') and
                ts.tablespace_name not in (select property_value
                                             from database_properties
                                            where property_name like 'DEFAULT%TABLESPACE') and
                ts.contents = 'PERMANENT'
            )
            and (sg.segment_type not in ('ROLLBACK', 'TYPE2 UNDO') or sg.segment_type is null)
            order by segment_type nulls last
        )
    )
    group by tablespace_name
)
order by rn
]' cmd
from dual;
set define on
prompt

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 09 - Igualar n�vel de patch entre origem e destino'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 10 - Executar script do RMAN'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)
from dual;

select 'connect target /'||chr(10)||
       'set echo on'||chr(10)||
       'run {'||chr(10)||
      q'[    set until time "to_date('&p_dt_corte', 'yyyy-mm-dd hh24:mi:ss')";]'
from dual;

select
'    allocate channel ch1 device type ''SBT_TAPE'' parms ''##PARAMETROS_FITA##'''
from dual;

prompt

select
'    set newname for datafile '||to_char(file#, 'fm00000')||' to new;'
from v$datafile
order by file#;

prompt

select
'    set newname for tempfile '||to_char(file#, 'fm00000')||' to new;'
from v$tempfile
order by file#;

prompt

select
'    sql "alter database rename file '||''''''||member||''''''||' to '||''''''||
     '&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.onlinelog&l_sep'||
     substr(member, (instr(member, '&l_sep', -1, 1) + 1), length(member))||''''''||'";'
from v$logfile;

prompt

select
'    restore database;'||chr(10)||chr(10)||
'    switch datafile all;'||chr(10)||
'    switch tempfile all;'||chr(10)
from dual;

select
'    recover database;'||chr(10)||chr(10)||
'    release channel ch1;'||chr(10)||chr(10)||
'}'
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 11 - Abrir base com resetlogs'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       'alter database open resetlogs;'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 12 - Verificar caminhos'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       'col name for a150'||chr(10)||chr(10)||
       'select name from v$datafile;'||chr(10)||chr(10)||
       'select name from v$tempfile;'||chr(10)||chr(10)||
       'select member name from v$logfile;'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 13 - (Opcional) Renomear base'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       '-- Colocar base em mount'||chr(10)||chr(10)||
       'nid target=sys/&p_senha_sys dbname=&p_db_name_dest'||chr(10)||chr(10)||
       '-- Alterar db_name no init'||chr(10)||chr(10)||
       '-- Abrir base com resetlogs'||chr(10)||chr(10)||
       '-- Alterar entrada TNS'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 14 - Adicionar entrada no oratab'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       '&p_db_name_dest:&p_oracle_home:N'||chr(10)
from dual;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- 15 - (Opcional) Criar spfile'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||chr(10)||
       'create spfile from pfile=''&p_dir_base&l_sep'||upper('&p_db_name_dest')||'&l_sep.init&p_db_name_dest..ora'';'||chr(10)
from dual;

spo off;

prompt
select '-----------------------------------------------------------------------------------------------------------------------'||chr(10)||
       '-- ## REVISAR SCRIPT ##'||chr(10)||
       '--'||chr(10)||
       '-- ed &p_cam_scr'||chr(10)||
       '-----------------------------------------------------------------------------------------------------------------------'||chr(10)
from dual;
prompt

@%temp%\sqlenv
prompt
