SET HEADING OFF term on

EXPLAIN PLAN SET STATEMENT_ID = 'c0135418' FOR
select /*+ CARDINALITY(h.ash, 5000000) */ *
from dba_hist_active_sess_history h
/

col dt new_val wdt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

accept p_dest_plan default 'plan_&wdt..html' prompt 'Caminho do arquivo (default: plan_&wdt..html): '

set lines 32767 pages 9999 feed off long 32767
col output for a32767
spool &p_dest_plan
SELECT dbms_xplan.display_plan('PLAN_TABLE','c0135418','ADVANCED -PROJECTION', null, 'ACTIVE') output FROM dual;
spool off
rollback;

-- SELECT LPAD( ' ', 2 * (level-1)) ||
--   operation                                                           ||
--   DECODE( options,      NULL, '', ' (' || options || ') of'         ) ||
--   DECODE( object_owner, NULL, '', ' '  || object_owner || '.'       ) ||
--   DECODE( object_name,  NULL, '',         object_name               ) ||
--   DECODE( object_type,  NULL, '', ' (' || object_type || ')'        ) ||
--   DECODE( cost,         NULL, '', ' cost=' || TO_CHAR( cost)        ) ||
--   DECODE( cardinality,  NULL, '', ' rows=' || TO_CHAR( cardinality) ) q_plan
-- FROM plan_table
-- WHERE statement_id = 'c0135418'
-- CONNECT BY PRIOR id = parent_id
-- AND statement_id = 'c0135418'
-- START WITH id = 1
-- ORDER BY id
-- /
-- ROLLBACK
-- /
SET HEADING ON

