set echo off
--
-- Se informar o Owner serao listados os database links privados do mesmo
-- e os database links publicos. Caso contrario, todos os database links
-- existentes na instance serao listados.
-- Por medida de seguranca as senhas nao foram incluidas na reengenharia.
--
--accept Owner char prompt 'Informe o Owner dos database links ou tecle ENTER para todos: '
--
set linesize 80 pagesize 0 space 0
set termout off feedback off verify off heading off
set long 150000
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000
--
select 'create ' || DECODE(owner, 'PUBLIC', 'PUBLIC') ||
       ' database link ' || DECODE(owner, 'PUBLIC', null, OWNER||'.') ||
       db_link || CHR(10) ||
       DECODE (owner, 'PUBLIC', NULL,'connect to ' || username ||
               ' identified by INCLUIR SENHA' || CHR(10)) ||
       'using ' || '''' || host || ''''|| ';'
FROM dba_db_links
WHERE owner NOT IN ('SYS','SYSTEM')
/
--
undef Owner
set pagesize 20 space 1
set termout on feedback on verify on heading on
