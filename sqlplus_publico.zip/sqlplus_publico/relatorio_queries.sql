-- Autor: Lucas Pimentel Lellis
--  Data: 29/08/2011

col usuario for a15
col query for a200
set long 5000 verify off

accept v_usr prompt 'Usuario: '
accept v_data_ini prompt 'Data de inicio (DDMMYYYY HHMM): '
accept v_data_fim prompt 'Data final (DDMMYYYY HHMM)    : '

SELECT   stats_consolid.parsing_schema_name usuario, stats_consolid.sql_id,
         stats_consolid.sum_exec num_execucoes_total,
         stats_consolid.sum_elap tempo_exec_total,
         (stats_consolid.sum_elap / stats_consolid.sum_exec) tempo_exec_medio, 
         txt.sql_text QUERY
    FROM (SELECT   st.parsing_schema_name, st.sql_id,
                   SUM (st.executions_delta) sum_exec,
                   SUM (st.elapsed_delta_sec) sum_elap
              FROM (SELECT DISTINCT s.parsing_schema_name, s.sql_id,
                                    s.executions_delta,
                                      s.elapsed_time_delta
                                    / 1e6 elapsed_delta_sec
                               FROM SYS.dba_hist_sqlstat s JOIN SYS.dba_hist_sqltext t
                                    ON s.sql_id = t.sql_id
                                    JOIN SYS.dba_hist_snapshot snap
                                    ON s.snap_id = snap.snap_id
                              WHERE (    snap.begin_interval_time >=
                                            TO_DATE ('&v_data_ini',
                                                     'DDMMYYYY HH24MI'
                                                    )
                                     AND snap.end_interval_time <
                                            TO_DATE ('&v_data_fim',
                                                     'DDMMYYYY HH24MI'
                                                    )
                                    )
                                AND s.parsing_schema_name = upper('&v_usr')) st
          GROUP BY st.parsing_schema_name, st.sql_id) stats_consolid
         JOIN
         SYS.dba_hist_sqltext txt ON stats_consolid.sql_id = txt.sql_id
where sum_exec > 0
ORDER BY 5 DESC;

