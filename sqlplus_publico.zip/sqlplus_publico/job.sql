set verify off

accept var_schema prompt 'SCHEMA: '

col SCHEMA_USER format a30
col JOB format 9999999
col BROKEN format a1
col LAST format a19
col NEXT format a19
col F format 9999
col WHAT format a80

SELECT	SCHEMA_USER
,	JOB
,	BROKEN
,	FAILURES F
,	TO_CHAR(LAST_DATE, 'DD/MM/YYYY HH24:MI:SS') LAST
,	TO_CHAR(NEXT_DATE, 'DD/MM/YYYY HH24:MI:SS') NEXT
,	'EXEC '||WHAT WHAT
FROM	DBA_JOBS where SCHEMA_USER like upper('%&var_schema%')
ORDER	BY schema_user, NEXT;

set verify on
