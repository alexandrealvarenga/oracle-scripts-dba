-- ####################################################################################
-- # Script: prepara_dump.sql
-- # Objetivo: Gerar scripts para desabilitar e habilitar as constraints de um owner,
-- # para prepar�-lo para receber um import apenas dos dados
-- ####################################################################################

set verify off
set head off
set pagesize 0
set linesize 500
set feedback off
accept   vo prompt 'Informe o owner das entidades: '
accept   dir prompt 'Diretorio de spool: '
set term off

spool "&dir\01_dis_cons.sql"
prompt spool "&dir\01_dis_cons.log"
prompt  --Disable constraints
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
select 'alter table '||owner||'.'||table_name||' disable constraint '||constraint_name||';'
from dba_constraints where status = 'ENABLED' and owner = upper('&vo') and constraint_type not in ('V','O','P','?')
/
prompt spool off
spool off

spool "&dir\07_en_cons.sql"
prompt spool "&dir\07_en_cons.log"
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
prompt --Enable constraints
select 'alter table '||owner||'.'||table_name||' enable constraint '||constraint_name||';'
from dba_constraints where status = 'ENABLED' and owner = upper('&vo') and constraint_type not in ('V','O','P','?')
/
prompt spool off
spool off

spool "&dir\02_dis_trig.sql"
prompt spool "&dir\02_dis_trig.log"
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
prompt --Disable triggers
select 'alter trigger '||owner||'.'||trigger_name||' disable;'
from dba_triggers where owner = upper('&vo')
/
prompt spool off
spool off

spool "&dir\06_en_trig.sql"
prompt spool "&dir\06_en_trig.log"
prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt
prompt --Enable triggers
select 'alter trigger '||owner||'.'||trigger_name||' enable;'
from dba_triggers where owner = upper('&vo')
/
prompt spool off
spool off

spool "&dir\05_gr_seq.sql"
prompt spool "&dir\05_gr_seq.log"

prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt

prompt
select 'GRANT '||privilege||' ON '||owner||'.'||table_name||' TO '||grantee||';'
from dba_tab_privs
where owner = upper('&vo')
and table_name in (select sequence_name from dba_sequences
                   where sequence_owner=upper('&vo'));
prompt spool off
spool off

spool "&dir\03_drop_seq.sql"
prompt spool "&dir\03_drop_seq.log"

prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt

prompt --Dropa as sequences
select 'drop sequence '||sequence_owner||'.'||sequence_name||';'
from dba_sequences 
where sequence_owner = upper('&vo')
/
prompt spool off
spool off

spool "&dir\04_trunc.sql"
prompt spool "&dir\04_trunc.log"

prompt
prompt set echo off
prompt conn &vo/<PWD>@&_CONNECT_IDENTIFIER
prompt set echo on
prompt

prompt --Truncates
select 'truncate table '||owner||'.'||table_name||';'
from dba_tables
where owner = upper('&vo')
/
prompt spool off
spool off
set term on
prompt
prompt Arquivos gerados sob o diretorio: &dir
undef vo
undef dir
set verify on
set feedback on
set head on

SELECT * FROM v$instance;

