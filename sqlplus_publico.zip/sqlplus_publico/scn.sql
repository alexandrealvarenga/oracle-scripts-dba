set echo off
column current_Scn format 99999999999999999 
	
select current_Scn from v$database;
