
-- --------------------------------------------------------------------------------
--
-- Script:      showplan9.sql
--
-- Author(s):   Adrian Billington
--              www.oracle-developer.net
--
-- Credit:      Original prototype produced by Andy Hobson
--
--
-- Description: Find a SQL statement in V$SQL and show its execution plan from
--              V$SQL_PLAN. This is an alternative to Tom Kyte's method of creating
--              a view over V$SQL_PLAN for those who are not able to have granted
--              the direct SELECT on V_$SQL_PLAN privilege.
--
-- Notes:       This script is for 9i Release 2 only. For 10g, use showplan10.sql.
--
-- --------------------------------------------------------------------------------

set pagesize 100
set linesize 165
set feedback off
set verify off

col plan_table_output format a165
col statement_id format a35
col sql_text format a100

var statement_id varchar2(30)

prompt
accept search_term prompt "Enter SQL search text: "
prompt

SELECT address || '-' || hash_value || '-' || child_number AS statement_id
,      SUBSTR(sql_text,1,100)                              AS sql_text
INTO   :statement_id
FROM   v$sql t
WHERE  LOWER(sql_text) LIKE '%' || LOWER('&search_term') || '%'
AND    LOWER(sql_text) NOT LIKE '%ignore_me%';

prompt
accept statement_id prompt "Choose a statement ID from the above: "
prompt

BEGIN

    :statement_id := '&statement_id';

    DELETE FROM plan_table
    WHERE  statement_id = :statement_id;

    INSERT INTO plan_table ( statement_id
                           , timestamp
                           , operation
                           , options
                           , object_node
                           , object_owner
                           , object_name
                           , optimizer
                           , search_columns
                           , id
                           , parent_id
                           , position
                           , cost
                           , cardinality
                           , bytes
                           , other_tag
                           , partition_start
                           , partition_stop
                           , partition_id
                           , other
                           , distribution
                           , cpu_cost
                           , io_cost
                           , temp_space
                           , access_predicates
                           , filter_predicates
                           )
    SELECT :statement_id  AS statement_id
    ,      SYSDATE        AS timestamp
    ,      operation
    ,      options
    ,      object_node
    ,      object_owner
    ,      object_name
    ,      optimizer
    ,      search_columns
    ,      id
    ,      parent_id
    ,      position
    ,      cost
    ,      cardinality
    ,      bytes
    ,      other_tag
    ,      partition_start
    ,      partition_stop
    ,      partition_id
    ,      other
    ,      distribution
    ,      cpu_cost
    ,      io_cost
    ,      temp_space
    ,      access_predicates
    ,      filter_predicates
    FROM   v$sql_plan
    WHERE  address || '-' || hash_value || '-' || child_number = :statement_id;

    COMMIT;

END;
/

prompt

SELECT plan_table_output
FROM   TABLE( DBMS_XPLAN.DISPLAY('PLAN_TABLE', :statement_id));

prompt

