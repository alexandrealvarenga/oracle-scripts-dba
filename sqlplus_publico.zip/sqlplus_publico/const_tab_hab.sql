store set %temp%\sqlenv replace

set echo off
set feedback off
set heading off
set verify off

accept nome_tab prompt "Tabela: "

column disable_expr format a200

select
	CASE
		WHEN filha.owner IS NOT NULL THEN
			'alter table '||filha.owner||'.'||filha.table_name||' enable constraint '||filha.constraint_name||';'||Chr(10)|| 
			'alter table '||pai.owner||'.'||pai.table_name||' enable constraint '||pai.constraint_name||';'
		ELSE
			'alter table '||pai.owner||'.'||pai.table_name||' enable constraint '||pai.constraint_name||';'
	END disable_expr
from dba_constraints pai,
     dba_constraints filha
where pai.constraint_name = filha.r_constraint_name (+)
  and pai.owner = filha.r_owner (+)
  and pai.table_name = upper('&nome_tab');
 

undef nome_tab

prompt

@%temp%\sqlenv
