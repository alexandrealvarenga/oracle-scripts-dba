set head off 
set feedback off
set verify off

accept var_owner prompt 'Nome do Owner: '
accept var_grantee prompt 'Nome do Grantee: '
accept var_dias prompt 'Dias: '


select 'exec STP_SARBOX_PRIVS_CONTROL(''GRANT'', ''SELECT'','''||OWNER||''','''||OBJECT_NAME||''',''&var_grantee'',&var_dias)'
from dba_objects where 
owner =upper('&var_owner') and
object_type IN ('TABLE','VIEW','SEQUENCE')
order by object_type, object_name
/
select 'exec STP_SARBOX_PRIVS_CONTROL(''GRANT'', ''DELETE'','''||OWNER||''','''||OBJECT_NAME||''',''&var_grantee'',&var_dias)'
from dba_objects where 
owner =upper('&var_owner') and
object_type = 'TABLE'
/
select 'exec STP_SARBOX_PRIVS_CONTROL(''GRANT'', ''INSERT'','''||OWNER||''','''||OBJECT_NAME||''',''&var_grantee'',&var_dias)'
from dba_objects where 
owner =upper('&var_owner') and
object_type  = 'TABLE'
/

select 'exec STP_SARBOX_PRIVS_CONTROL(''GRANT'', ''UPDATE'','''||OWNER||''','''||OBJECT_NAME||''',''&var_grantee'',&var_dias)'
from dba_objects where 
owner =upper('&var_owner') and
object_type  = 'TABLE'
/

select 'exec STP_SARBOX_PRIVS_CONTROL(''GRANT'', ''EXECUTE'','''||OWNER||''','''||OBJECT_NAME||''',''&var_grantee'',&var_dias)'
from dba_objects where 
owner =upper('&var_owner') and
object_type  = 'PROCEDURE'
/

set head on
set feedback on
set verify on

