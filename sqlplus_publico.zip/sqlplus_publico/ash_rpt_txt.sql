/* ASH_RPT_TXT.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Gera um relatorio ASH em formato texto
 * Utilizacao: @ash_rpt_txt dt_inicial dt_final [sid] (intervalo em minutos, data no formato YYYYMMDDHH24MI)
 *             @ash_rpt_txt last periodo_minutos [sid]
 * Obs.:       Parametros entre colchetes sao opcionais
 *
 * Exemplos: @ash_rpt_txt 201406081400 201406081430 238
 *           @ash_rpt_txt last 60
 *
 */

store set setenv replace

set verify off echo off lines 32767 pages 9999 long 32767 feed off newpage none long 2000000000 longchunksize 8192000
set serveroutput on size 1000000 heading off

define C_DT_INPUT_FMT=YYYYMMDDHH24MI    -- Formato de input de data

-- Define o valor default do terceiro parametro, que eh opcional
set feed off term off
col p3 new_value 3
select null p3 from dual where  1=2;
select nvl('&3','') p3 from dual;
set term on


variable ini_date varchar2(20)
variable end_date varchar2(20)

begin
    :ini_date := upper('&1');

    if (:ini_date = 'LAST') then
        :ini_date := to_char((sysdate - &2/60/24), '&C_DT_INPUT_FMT');
        :end_date := to_char(sysdate, '&C_DT_INPUT_FMT');
    else
        :ini_date := '&1';
        :end_date := '&2';
    end if;
end;
/

define p_dest_spool='%TEMP%\&&inst_name._ashrpt_&&1._&&2._&&3..txt'

col output for a32767
spool &&p_dest_spool
select output
from table(
    SYS.DBMS_WORKLOAD_REPOSITORY.ASH_REPORT_TEXT(
        (select dbid from v$database),
        sys_context('USERENV', 'INSTANCE'),
        to_date(:ini_date, '&C_DT_INPUT_FMT'),
        to_date(:end_date, '&C_DT_INPUT_FMT'),
        0,
        0,
        '&3'
    )
);
spool off

prompt
prompt host &p_dest_spool

undef 1 2 3
undef p3 p_dest_spool
undef C_DT_INPUT_FMT
clear columns

@%temp%\sqlenv
prompt