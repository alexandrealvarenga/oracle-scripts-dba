disc
set echo off head on feed on term on
spool off
host color f0
