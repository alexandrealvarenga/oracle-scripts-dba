/* AWR_OBJ_LR.sql
 *
 * Autor:      Lucas Pimentel Lellis (lucas.lellis@cgi.com)
 * Descricao:  Histórico de principais objetos ordenados por logical reads, obtido a partir do AWR
 * Utilizacao: @awr_obj_lr dt_inicial dt_final [owner] [num_objetos - default 10] (data no formato YYYYMMDDHH24MI)
 * Obs.:       Parametros entre colchetes sao opcionais 
 *            
 * Exemplo: @awr_obj_lr 201407280000 201407280430
 *          @awr_obj_lr 201407280000 201407280430 SYSTEM
 *          @awr_obj_lr 201407280000 201407280430 SYSTEM 15
 *          @awr_obj_lr 201407280000 201407280430 % 20
 *
 */


-- Define o valor default do terceiro e quarto parametros (opcionais)
set feed off term off pages 9999
col p3 new_value 3
col p4 new_value 4
select null p3, null p4 from dual where  1=2;
select nvl('&3','%') p3, nvl('&4', 10) p4 from dual;
set feed on term on

define p_owner="&3"
define p_top_objs=&4

col owner for a30
col object_type for a30
col object_name for a30
col obj# for 9999999999
col dataobj# for 9999999999
col logical_reads_delta heading 'Logical|Reads' for 999999999999999
col pct for 990.00

break on begin_interval_time skip page
compute sum of pct on begin_interval_time

select to_char(begin_interval_time, 'DD/MM/YYYY HH24:MI:SS') begin_interval_time, 
       owner, object_type, object_name, obj#, dataobj#, logical_reads_delta, pct
from (
  select /*+ no_merge(sn) no_merge(st) no_merge(o) leading(sn st o) use_hash(sn st o) */
         sn.begin_interval_time, o.owner, o.object_type, o.object_name, o.obj#, o.dataobj#, st.logical_reads_delta,
         ratio_to_report(st.logical_reads_delta) over (partition by st.snap_id) * 100.0 pct,
         row_number() over (partition by st.snap_id order by logical_reads_delta desc) rn
  from sys.dba_hist_snapshot sn,
       SYS.DBA_HIST_SEG_STAT st,
       SYS.DBA_HIST_SEG_STAT_OBJ o
  where sn.dbid = st.dbid
    and sn.instance_number = st.instance_number
    and sn.snap_id = st.snap_id
    and st.dbid = o.dbid
    and st.obj# = o.obj#
    and st.dataobj# = o.dataobj#
    and st.instance_number = sys_context('USERENV','INSTANCE')
    and sn.begin_interval_time >= to_timestamp('&1', 'YYYYMMDDHH24MI')
    and sn.end_interval_time < to_timestamp('&2', 'YYYYMMDDHH24MI') + numtodsinterval(2, 'minute')
    and o.owner like upper('&p_owner')
)
where rn <= &p_top_objs
order by begin_interval_time, logical_reads_delta desc;

undef 1 2 3 4 p_top_objs p_owner
clear columns
clear breaks
clear computes
