set lines 340
col username for a30
COL OPNAME FORMAT A30
COL MESSAGE FORMAT A100
col target for a30 word_wrapped
col "%_complete" format a10
col "Falta" format a10
col "Executado" format a10
col "Total" format a10
col inst_id format 999999
col program for a35
select distinct l.inst_id, l.sid, l.username
,      to_char(trunc((sofar/totalwork)*100, 2), '99D99') "%_complete"
,      opname
,      lpad(trim(to_char(floor((time_remaining)/(3600)), 900)) ||':'|| trim(to_char(floor((((time_remaining)) - (floor(((time_remaining))/(3600))*3600))/60), 900)) ||':'||trim(to_char(mod((((time_remaining)) - (floor(((time_remaining))/(3600))*3600)),60), 900)), 10, ' ') "Falta"
,      lpad(trim(to_char(floor((elapsed_seconds)/(3600)), 900)) ||':'|| trim(to_char(floor((((elapsed_seconds)) - (floor(((elapsed_seconds))/(3600))*3600))/60), 900)) ||':'||trim(to_char(mod((((elapsed_seconds)) - (floor(((elapsed_seconds))/(3600))*3600)),60), 900)), 10, ' ') "Executado"
,      lpad(trim(to_char(floor((time_remaining+elapsed_seconds)/(3600)), 900)) ||':'|| trim(to_char(floor((((time_remaining+elapsed_seconds)) - (floor(((time_remaining+elapsed_seconds))/(3600))*3600))/60), 900)) ||':'||trim(to_char(mod((((time_remaining+elapsed_seconds)) - (floor(((time_remaining+elapsed_seconds))/(3600))*3600)),60), 900)), 10, ' ') "Total"
,      target
,      message
,      program
from   gv$session_longops l
,      gv$session s
where  (sofar/decode(totalwork, 0, 1, totalwork))*100 <> 100
and    totalwork <> 0
and    l.sid = s.sid
and    l.inst_id = s.inst_id
order  by username, opname
/
clear columns
