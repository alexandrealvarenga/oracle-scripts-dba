select sqlid.sql_id, trunc(sqlid.elapsed_time / 1e6, 2) elapsed_time_sec, sqlid.parsing_schema_name, txt.sql_text
from
(
    select sql_id, parsing_schema_name, elapsed_time
    from 
    (
        select stat.sql_id, stat.parsing_schema_name, sum(stat.elapsed_time_delta) elapsed_time
        from dba_hist_sqlstat stat
        join dba_hist_snapshot snap on (stat.snap_id = snap.snap_id and stat.instance_number = snap.instance_number)
        where stat.parsing_schema_name not in ('BDTRACE', 'BKPACN','DBSNMP','PCSOX','SYS')
        and (snap.BEGIN_INTERVAL_TIME >= sysdate - 1 and snap.END_INTERVAL_TIME <= sysdate)
        group by stat.sql_id, stat.parsing_schema_name
        order by elapsed_time desc
    )
    where rownum <= 10
) sqlid
join dba_hist_sqltext txt on sqlid.sql_id=txt.sql_id
order by elapsed_time desc;