set long 999999999

set verify off
set echo off
set linesize 500

column codigo_fonte format a200 word_wrapped

accept obj prompt "Objeto: "
accept owner prompt "Owner: "
accept tipo prompt "Tipo: "

select dbms_metadata.get_ddl(upper('&tipo'), upper('&obj'), upper('&owner')) codigo_fonte
from dual;

set verify on
