@swg "select sid from v$session"
