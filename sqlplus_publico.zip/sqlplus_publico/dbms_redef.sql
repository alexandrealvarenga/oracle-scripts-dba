-------------------------------------------------------------------------------
--       Nome : dbms_redef.sql
--      Autor : Lucas Pimentel Lellis (lucas.lellis@dxc.com)
-- Finalidade : Gerar script de dbms_redefinition para uma tabela
-------------------------------------------------------------------------------

store set %temp%\sqlenv replace

set term on echo off feedback off verify off linesize 9999 serveroutput on size unlimited

accept P_DIR prompt 'Diretorio dos scripts: '
accept P_OWNER prompt 'OWNER: '
accept P_TABELA prompt 'TABELA: '
accept P_TBSP_TAB prompt 'Tablespace de dados (deixe em branco para manter o atual): '
accept P_TBSP_IND prompt 'Tablespace de indices (deixe em branco para manter o atual): '

var G_OWNER varchar2(30)
var G_TABELA varchar2(30)
var G_TAB_TEMP varchar2(30)
var G_TBSP_TAB varchar2(30)
var G_TBSP_IND varchar2(30)
var G_PAR_DEG number
var G_OBJ_ID number

col dt new_val l_dt noprint
select to_char(sysdate, 'yyyymmddhh24miss') dt from dual;

declare
    l_sufixo varchar2(30);
begin
    :G_OWNER := trim(upper('&P_OWNER'));
    :G_TABELA := trim(upper('&P_TABELA'));
    :G_TBSP_TAB := trim(upper('&P_TBSP_TAB'));
    :G_TBSP_IND := trim(upper('&P_TBSP_IND'));

    select ceil(to_number(value)/2) valor
    into :G_PAR_DEG
    from v$parameter
    where lower(name) = 'cpu_count';

    select object_id
    into :G_OBJ_ID
    from dba_objects
    where owner = :G_OWNER and object_name = :G_TABELA and object_type = 'TABLE';

    l_sufixo := '_'||:G_OBJ_ID;
    :G_TAB_TEMP := substr(:G_TABELA, 1, 30 - length(l_sufixo))||l_sufixo;
end;
/

spool &P_DIR.\&P_OWNER._&P_TABELA._&l_dt..sql
prompt spool &P_DIR.\&P_OWNER._&P_TABELA._&l_dt..log
prompt
prompt set term on echo on feedback on verify off linesize 9999 serveroutput on

prompt
begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 00: Verificar se a tabela pode ser redefinida');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

begin
    dbms_output.put_line('-- Verificando se tabela pode ser redefinida...');
    dbms_redefinition.can_redef_table(:G_OWNER, :G_TABELA);
    dbms_output.put_line('-- Nao foram encontrados erros que impecam a redefinicao.');
exception
    when others then
        dbms_output.put_line('--Nao se deve continuar com a redefinicao:'||chr(10)||
                             SQLERRM||chr(10)||
                             dbms_utility.format_error_backtrace);
end;
/

prompt
prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 01: Criar a tabela intermediaria');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

declare
    l_tab_ddl clob;
    l_hnd number; -- handle do dbms_metadata
    l_trnsf_hnd number; -- handle da transformation do dbms_metadata
    l_tbsp_atual dba_tables.tablespace_name%type;
begin
    l_hnd := dbms_metadata.open('TABLE');
    dbms_metadata.set_filter(l_hnd, 'SCHEMA', :G_OWNER);
    dbms_metadata.set_filter(l_hnd, 'NAME', :G_TABELA);

    select tablespace_name
    into l_tbsp_atual
    from dba_tables
    where owner = :G_OWNER and table_name = :G_TABELA;

    l_trnsf_hnd := dbms_metadata.add_transform(l_hnd, 'MODIFY');
    dbms_metadata.set_remap_param(l_trnsf_hnd,'REMAP_NAME', :G_TABELA, :G_TAB_TEMP);
    if :G_TBSP_TAB is not null then
        dbms_metadata.set_remap_param(l_trnsf_hnd,'REMAP_TABLESPACE', l_tbsp_atual, :G_TBSP_TAB);
    end if;

    l_trnsf_hnd := dbms_metadata.add_transform(l_hnd, 'DDL');

    dbms_metadata.set_transform_param(l_trnsf_hnd, 'SQLTERMINATOR', true);
    dbms_metadata.set_transform_param(l_trnsf_hnd, 'STORAGE', false);
    dbms_metadata.set_transform_param(l_trnsf_hnd, 'CONSTRAINTS', false);
    dbms_metadata.set_transform_param(l_trnsf_hnd, 'REF_CONSTRAINTS', false);
    l_tab_ddl := dbms_metadata.fetch_clob(l_hnd);
    dbms_metadata.close(l_hnd);

    dbms_output.put_line(l_tab_ddl);
end;
/

prompt
begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 02: Iniciar redefinicao');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

declare
    l_cmd varchar2(4000);
begin
    l_cmd := 'ALTER SESSION FORCE PARALLEL DML PARALLEL '||:G_PAR_DEG||';'||chr(10)||
             'ALTER SESSION FORCE PARALLEL DDL PARALLEL '||:G_PAR_DEG||';'||chr(10)||
             'ALTER SESSION FORCE PARALLEL QUERY PARALLEL '||:G_PAR_DEG||';'||chr(10)||chr(10)||
             'EXEC DBMS_REDEFINITION.START_REDEF_TABLE(uname=>'''||:G_OWNER||''',orig_table=>'''||
                :G_TABELA||''',int_table=>'''||:G_TAB_TEMP||''');';
    dbms_output.put_line(l_cmd);
    l_cmd := chr(10)||'ALTER TABLE "'||:G_OWNER||'"."'||:G_TAB_TEMP||'" PARALLEL '||:G_PAR_DEG||';';
    dbms_output.put_line(l_cmd);
end;
/
prompt


prompt
begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 03: Copiar indices');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt
declare
    l_ind_ddl clob;
    l_hnd number; -- handle do dbms_metadata
    l_trnsf_hnd number; -- handle da transformation do dbms_metadata
    l_cnt pls_integer := 1;
    l_ind_name varchar2(30);
    l_logging varchar2(30);
    l_deg number;
    l_ind_pk pls_integer;
begin
    for r_index in (select i.owner, i.index_name, i.logging, i.degree, i.tablespace_name
                      from dba_indexes i
                      where i.table_owner = :G_OWNER
                      and i.table_name = :G_TABELA
                      and i.index_type <> 'LOB'
                    ) loop

        l_hnd := dbms_metadata.open('INDEX');
        dbms_metadata.set_filter(l_hnd, 'SCHEMA', r_index.owner);
        dbms_metadata.set_filter(l_hnd, 'NAME', r_index.index_name);

        l_ind_name := 'TMP$$_'||substr(r_index.index_name, 1, 20)||'_'||to_char(l_cnt, 'fm000');

        l_trnsf_hnd := dbms_metadata.add_transform(l_hnd, 'MODIFY');
        dbms_metadata.set_remap_param(l_trnsf_hnd,'REMAP_NAME', r_index.index_name, l_ind_name);
        if :G_TBSP_IND is not null then
            dbms_metadata.set_remap_param(l_trnsf_hnd,'REMAP_TABLESPACE', r_index.tablespace_name, :G_TBSP_IND);
        end if;

        l_trnsf_hnd := dbms_metadata.add_transform(l_hnd, 'DDL');
        dbms_metadata.set_transform_param(l_trnsf_hnd, 'STORAGE', false);
        dbms_metadata.set_transform_param(l_trnsf_hnd, 'SQLTERMINATOR', true);

        l_ind_ddl := dbms_metadata.fetch_clob(l_hnd);

        l_deg := to_number(r_index.degree);
        if l_deg = 1 or l_deg is null then
            l_ind_ddl := replace(l_ind_ddl, 'NOPARALLEL', '');
        else
            l_ind_ddl := regexp_replace(l_ind_ddl, 'PARALLEL[ \n\r\t]+[[:digit:]]+', '');
        end if;

        dbms_metadata.close(l_hnd);

        l_ind_ddl := replace(l_ind_ddl, '"'||:G_TABELA||'"', '"'||:G_TAB_TEMP||'"');
        dbms_output.put_line(l_ind_ddl);

        dbms_output.put_line(chr(10)||'alter index "'||r_index.owner||'"."'||l_ind_name||'" PARALLEL '||r_index.degree||';');

        dbms_output.put_line(chr(10)||
            'begin'                                                                                           ||chr(10)||
            '   dbms_redefinition.register_dependent_object(uname            => '''||:G_OWNER||''','          ||chr(10)||
            '                                               orig_table       => '''||:G_TABELA||''','         ||chr(10)||
            '                                               int_table        => '''||:G_TAB_TEMP||''','       ||chr(10)||
            '                                               dep_type         => dbms_redefinition.CONS_INDEX,'||chr(10)||
            '                                               dep_owner        => '''||:G_OWNER||''','          ||chr(10)||
            '                                               dep_orig_name    => '''||r_index.index_name||''','||chr(10)||
            '                                               dep_int_name     => '''||l_ind_name||''');'       ||chr(10)||
            'end;'                                                                                             ||chr(10)||
            '/');

        dbms_output.put_line(chr(10)||'EXEC DBMS_REDEFINITION.SYNC_INTERIM_TABLE(uname=>'''||:G_OWNER||
            ''',orig_table=>'''||:G_TABELA||''',int_table=>'''||:G_TAB_TEMP||''');');

        l_cnt := l_cnt + 1;
    end loop;
end;
/
prompt

prompt
begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 04: Copiar constraints');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt
declare
    l_const_ddl clob;
    l_hnd number; -- handle do dbms_metadata
    l_trnsf_hnd number; -- handle da transformation do dbms_metadata
    l_const_name dba_constraints.constraint_name%type;
    l_ddl_registro_const clob;
    l_cnt pls_integer;
    l_logging varchar2(30);
    l_deg number;
begin
    l_cnt := 0;
    for r_const in (select c.constraint_name, c.constraint_type, c.index_owner, c.index_name,
                           c.generated
                      from dba_constraints c
                     where c.owner = :G_OWNER and c.table_name = :G_TABELA) loop
        if r_const.constraint_type = 'R' then
            l_hnd := dbms_metadata.open('REF_CONSTRAINT');
        else
            l_hnd := dbms_metadata.open('CONSTRAINT');
        end if;

        dbms_metadata.set_filter(l_hnd, 'SCHEMA', :G_OWNER);
        dbms_metadata.set_filter(l_hnd, 'NAME', r_const.constraint_name);

        if r_const.generated = 'USER NAME' then
            l_const_name := 'TMP$$_'||substr(r_const.constraint_name, 1, 20)||'_'||to_char(l_cnt, 'fm000');
            l_trnsf_hnd := dbms_metadata.add_transform(l_hnd, 'MODIFY');
            dbms_metadata.set_remap_param(l_trnsf_hnd,'REMAP_NAME', r_const.constraint_name, l_const_name);

            l_ddl_registro_const :=
                'begin'                                                                                                 ||chr(10)||
                '   dbms_redefinition.register_dependent_object(uname            => '''||:G_OWNER||''','                ||chr(10)||
                '                                               orig_table       => '''||:G_TABELA||''','               ||chr(10)||
                '                                               int_table        => '''||:G_TAB_TEMP||''','             ||chr(10)||
                '                                               dep_type         => dbms_redefinition.CONS_CONSTRAINT,' ||chr(10)||
                '                                               dep_owner        => '''||:G_OWNER||''','                ||chr(10)||
                '                                               dep_orig_name    => '''||r_const.constraint_name||''',' ||chr(10)||
                '                                               dep_int_name     => '''||l_const_name||''');'           ||chr(10)||
                'end;'                                                                                                  ||chr(10)||
                '/';
            l_cnt := l_cnt + 1;
        end if;

        l_trnsf_hnd := dbms_metadata.add_transform(l_hnd, 'DDL');
        if r_const.constraint_type in ('P', 'U') then
            dbms_metadata.set_transform_param(l_trnsf_hnd, 'STORAGE', false);
        end if;
        dbms_metadata.set_transform_param(l_trnsf_hnd, 'SQLTERMINATOR', true);

        l_const_ddl := dbms_metadata.fetch_clob(l_hnd);

        if instr(l_const_ddl, 'ENABLE') > 0 then
            l_const_ddl := replace(l_const_ddl, 'ENABLE', 'DISABLE');
        end if;
        l_const_ddl := replace(l_const_ddl, '"'||:G_TABELA||'"', '"'||:G_TAB_TEMP||'"');

        dbms_metadata.close(l_hnd);

        dbms_output.put_line(l_const_ddl||chr(10));
        if l_ddl_registro_const is not null then
            dbms_output.put_line(l_ddl_registro_const);
        end if;
        l_ddl_registro_const := null;
    end loop;
end;
/
prompt


begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 05: Copiar dependencias');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt
declare
    l_cmd varchar2(4000);
begin
    l_cmd :=
        'declare'                                                                               ||chr(10)||
        '   l_num_err pls_integer;'                                                             ||chr(10)||
        'begin'                                                                                 ||chr(10)||
        '   dbms_redefinition.copy_table_dependents (uname            => '''||:G_OWNER||''','   ||chr(10)||
        '                                            orig_table       => '''||:G_TABELA||''','  ||chr(10)||
        '                                            int_table        => '''||:G_TAB_TEMP||''','||chr(10)||
        '                                            copy_indexes     => 0,'                    ||chr(10)||
        '                                            copy_constraints => true,'                 ||chr(10)||
        '                                            copy_triggers    => true,'                 ||chr(10)||
        '                                            copy_privileges  => true,'                 ||chr(10)||
        '                                            copy_statistics  => true,'                 ||chr(10)||
        '                                            copy_mvlog       => true,'                 ||chr(10)||
        '                                            num_errors       => l_num_err,'            ||chr(10)||
        '                                            ignore_errors    => false);'               ||chr(10)||
        '   dbms_output.put_line(chr(10)||''----------------------------'');'                   ||chr(10)||
        '   dbms_output.put_line(''Erros encontrados: ''||l_num_err);'                          ||chr(10)||
        '   dbms_output.put_line(''----------------------------''||chr(10));'                   ||chr(10)||
        'end;'                                                                                  ||chr(10)||
        '/';
    dbms_output.put_line(l_cmd);
end;
/
prompt
prompt -- #############################################################################
prompt -- Caso o comando acima retorne erros apenas referentes a constraints NOT NULL,
prompt -- favor executa-lo novamente alterando a linha
prompt -- ignore_errors => false
prompt -- para
prompt -- ignore_errors => true
prompt -- #############################################################################
prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 06: Sincronizar tabelas (opcional)');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

declare
    l_cmd varchar2(4000);
begin
    l_cmd := 'EXEC DBMS_REDEFINITION.SYNC_INTERIM_TABLE(uname=>'''||:G_OWNER||''',orig_table=>'''||
                :G_TABELA||''',int_table=>'''||:G_TAB_TEMP||''');';
    dbms_output.put_line(l_cmd);
end;
/

prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 07: Habilitar e validar constraints');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

-- O enable e o validate sao feitos em passos separados para que a validacao ocorra em parallel

declare
    l_cmd varchar2(4000);
begin
    l_cmd :=
        'begin'                                                                                                       ||chr(10)||
        '    for r_const in (select constraint_name'                                                                  ||chr(10)||
        '                      from dba_constraints'                                                                  ||chr(10)||
        '                     where owner = '''||:G_OWNER||''' and table_name = '''||:G_TAB_TEMP||''''                ||chr(10)||
        '                       and (status <> ''ENABLED'' or validated <> ''VALIDATED'')'                            ||chr(10)||
        '                   ) loop'                                                                                   ||chr(10)||
        '        execute immediate ''alter table "'||:G_OWNER||'"."'||:G_TAB_TEMP||'" enable novalidate constraint "''||r_const.constraint_name||''"'';'||chr(10)||
        '    end loop;'                                                                                               ||chr(10)||
        'end;'                                                                                                        ||chr(10)||
        '/';
    dbms_output.put_line(l_cmd);
end;
/

prompt

declare
    l_cmd varchar2(4000);
begin
    l_cmd :=
        'begin'                                                                                                       ||chr(10)||
        '    for r_const in (select constraint_name'                                                                  ||chr(10)||
        '                      from dba_constraints'                                                                  ||chr(10)||
        '                     where owner = '''||:G_OWNER||''' and table_name = '''||:G_TAB_TEMP||''''                ||chr(10)||
        '                       and validated <> ''VALIDATED'''                                                       ||chr(10)||
        '                   ) loop'                                                                                   ||chr(10)||
        '        execute immediate ''alter table "'||:G_OWNER||'"."'||:G_TAB_TEMP||'" modify constraint "''||r_const.constraint_name||''" validate'';'||chr(10)||
        '    end loop;'                                                                                               ||chr(10)||
        'end;'                                                                                                        ||chr(10)||
        '/';
    dbms_output.put_line(l_cmd);
end;
/

declare
    l_cmd varchar2(4000);
begin
    l_cmd := chr(10)||'ALTER TABLE "'||:G_OWNER||'"."'||:G_TAB_TEMP||'" NOPARALLEL;';
    dbms_output.put_line(l_cmd);
end;
/

prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 08: Inverter tabelas');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

declare
    l_cmd varchar2(4000);
begin
    l_cmd := 'EXEC DBMS_REDEFINITION.FINISH_REDEF_TABLE(uname=>'''||:G_OWNER||''',orig_table=>'''||
                :G_TABELA||''',int_table=>'''||:G_TAB_TEMP||''');';
    dbms_output.put_line(l_cmd);
end;
/

prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 09: Verificacao');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

declare
    l_cmd varchar2(4000);
begin
    l_cmd :=
        'col table_name for a30'                                         ||chr(10)||
        'col constraint_type for a15'                                    ||chr(10);
    dbms_output.put_line(l_cmd);

    l_cmd :=
        'select table_name, count(*)'                                    ||chr(10)||
        'from dba_indexes'                                               ||chr(10)||
        'where table_name in ('''||:G_TABELA||''','''||:G_TAB_TEMP||''')'||chr(10)||
        '  and owner = '''||:G_OWNER||''''                               ||chr(10)||
        'group by table_name'                                            ||chr(10)||
        'order by table_name;'                                           ||chr(10);
    dbms_output.put_line(l_cmd);

    l_cmd :=
        'select constraint_type, status, table_name, count(*)'           ||chr(10)||
        'from dba_constraints'                                           ||chr(10)||
        'where table_name in ('''||:G_TABELA||''','''||:G_TAB_TEMP||''')'||chr(10)||
        '  and owner = '''||:G_OWNER||''''                               ||chr(10)||
        'group by constraint_type, table_name, status'                   ||chr(10)||
        'order by constraint_type, table_name, status;'                  ||chr(10);
    dbms_output.put_line(l_cmd);

    l_cmd :=
        'select table_name, count(*)'                                    ||chr(10)||
        'from dba_tab_privs'                                             ||chr(10)||
        'where table_name in ('''||:G_TABELA||''','''||:G_TAB_TEMP||''')'||chr(10)||
        '  and owner = '''||:G_OWNER||''''                               ||chr(10)||
        'group by table_name'                                            ||chr(10)||
        'order by table_name;'                                           ||chr(10);
    dbms_output.put_line(l_cmd);

    l_cmd :=
        'select owner, table_name, constraint_name, search_condition'        ||chr(10)||
        'from dba_constraints c1'                                            ||chr(10)||
        'where r_constraint_name in ('                                       ||chr(10)||
        '    select constraint_name'                                         ||chr(10)||
        '    from dba_constraints c2'                                        ||chr(10)||
        '    where table_name in ('''||:G_TABELA||''','''||:G_TAB_TEMP||''')'||chr(10)||
        '      and owner = '''||:G_OWNER||''''                               ||chr(10)||
        '    and constraint_type = ''P'''                                    ||chr(10)||
        ')'                                                                  ||chr(10)||
        'and c1.constraint_type = ''R'''                                     ||chr(10)||
        'order by owner, table_name, constraint_name;'                       ||chr(10);
    dbms_output.put_line(l_cmd);

end;
/

prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 10: Remover tabela intermediaria');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

begin
    dbms_output.put_line('DROP TABLE "'||:G_OWNER||'"."'||:G_TAB_TEMP||'" cascade constraints purge;');
end;
/

prompt

prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- PASSO 11: Atualizar estatisticas');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt

begin
    dbms_output.put_line('exec dbms_stats.gather_table_stats(ownname => '''||:G_OWNER||''', tabname => '''||
        :G_TABELA||''', cascade => true, estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE, '||
        'method_opt=>''FOR ALL COLUMNS SIZE REPEAT'', '||
        'degree => '||:G_PAR_DEG||', no_invalidate => false)');
end;
/

prompt

begin
    dbms_output.put_line('------------------------------------------------------------------------------------------');
    dbms_output.put_line('-- APENDICE: Abortar redefinicao');
    dbms_output.put_line('------------------------------------------------------------------------------------------');
end;
/

prompt
declare
    l_cmd varchar2(4000);
begin
    l_cmd := 'EXEC DBMS_REDEFINITION.ABORT_REDEF_TABLE(uname=>'''||:G_OWNER||''',orig_table=>'''||:G_TABELA||''',int_table=>'''||:G_TAB_TEMP||''');';
    dbms_output.put_line(l_cmd);
    dbms_output.put_line(chr(10)||'DROP TABLE "'||:G_OWNER||'"."'||:G_TAB_TEMP||'" purge;'||chr(10));
    dbms_output.put_line('col object_type for a12'           ||chr(10)||
                         'col object_owner for a30'          ||chr(10)||
                         'col object_name for a30'           ||chr(10)||
                         'col base_object_owner for a30'     ||chr(10)||
                         'col base_object_name for a30'      ||chr(10)||
                         'col interim_object_owner for a30'  ||chr(10)||
                         'col interim_object_name for a30'   ||chr(10)||
                         'col edition_name for a30'          ||chr(10)||
                         'select * from dba_redefinition_objects where object_owner = '''||:G_OWNER||''' and object_name = '''||:G_TABELA||''';');
end;
/
prompt


------------------------------------------------------------------------------------------
-- Finalizacao
------------------------------------------------------------------------------------------

prompt spool off
spool off

@%temp%\sqlenv.sql
prompt

prompt host &P_DIR.\&P_OWNER._&P_TABELA._&l_dt..sql
prompt

undef P_DIR P_OWNER P_TABELA P_TBSP_TAB P_TBSP_IND