set echo off
set linesize 80 pagesize 0 space 0
set termout off feedback off verify off heading off
set long 150000
set trims on
set serveroutput off
set serveroutput on size 1000000
set linesize 5000

--
SELECT 'create role ' || role ||
       decode(PASSWORD_REQUIRED, 'NO', ' ',
              ' identified by INCLUIR SENHA') || ';'
FROM dba_roles
WHERE role NOT IN ('DBA','CONNECT','RESOURCE', 'EXP_FULL_DATABASE',
                   'IMP_FULL_DATABASE', 'TKPROFER')
/
--
set pagesize 20 space 1
set termout on feedback on verify on heading on
