select c.capture_name,
      p.name parameter, 
      p.value, 
      p.user_changed_flag, 
      p.internal_flag 
 from sys.streams$_process_params  p, 
      sys.streams$_capture_process c 
where p.process# = c.capture# 
order by c.capture_name, parameter; 